<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get doctor_id from the request, supporting both POST and GET
$doctor_id = isset($_REQUEST['doctor_id']) ? $_REQUEST['doctor_id'] : null;

if ($doctor_id === null) {
    die("Doctor ID is required");
}

// Use prepared statement to avoid SQL injection
$stmt = $conn->prepare("SELECT firstname, lastname, pat_id, severity, image FROM patients WHERE doctor_id = ? AND surgerydate >= DATE_SUB(NOW(), INTERVAL 183 DAY)ORDER BY severity DESC");

$stmt->bind_param("i", $doctor_id);
$stmt->execute();

$result = $stmt->get_result();

if (!$result) {
    die("Query failed: " . $conn->error);
}

$patients = array();

while ($row = $result->fetch_assoc()) {
    $row['name'] = $row['firstname'] . ' ' . $row['lastname'];
    unset($row['firstname']);
    unset($row['lastname']);
    $patients[] = $row;
}

echo json_encode($patients);

$stmt->close();
$conn->close();
?>