<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Assuming your DbConnect class has a proper implementation
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $dbConnect = new DbConnect();
        $conn = $dbConnect->connect();

        $id = $_POST['id'];
        //$status = $_POST['status'];

        $sql = "UPDATE appointments SET status = 'Accepted' WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $response['error'] = false;
            $response['message'] = "Status updated successfully!";
        } else {
            $response['error'] = true;
            $response['message'] = "Error updating status";
        }

        $stmt->close();
        $conn->close();
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
