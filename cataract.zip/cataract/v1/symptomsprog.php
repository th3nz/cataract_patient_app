<?php

// Include your database connection file
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Check if pat_id is provided through POST method
$pat_id = isset($_POST['pat_id']) ? intval($_POST['pat_id']) : null;

// Check if pat_id is provided
if ($pat_id === null) {
    http_response_code(400); // Bad Request
    exit(json_encode(array("error" => "pat_id is missing")));
}

// Initialize val variable
$val = 0;

// Connect to the database
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check for database connection errors
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    exit(json_encode(array("error" => "Connection failed: " . $conn->connect_error)));
}

// Get today's date
$todayDate = date('Y-m-d');

// Prepare and execute the SQL query
$sql = "SELECT * FROM symptoms WHERE pat_id = ? AND entry_date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $pat_id, $todayDate);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Fetch the row
    $row = $result->fetch_assoc();

    // Check each symptom and update val accordingly
    if ($row['headache'] == 1) {
        $val += 1;
    }
    if ($row['redness'] == 1) {
        $val += 1;
    }
    if ($row['eye_discharge'] == 1) {
        $val += 1;
    }
    if ($row['floaters'] == 1) {
        $val += 1;
    }
    if ($row['flashes'] == 1) {
        $val += 1;
    }
    if ($row['nausea'] == 1) {
        $val += 1;
    }
    if ($row['watering'] == 1) {
        $val += 1;
    } else {
        if ($row['isSelected'] == 1) {
            if ($val == 0) {
                $val  = 10;
            }
        }
        if ($row['isSelected'] == 0) {
            if ($val == 0) {
                $val  = 0;
            }
        }
    }
}

// Close the database connection
$stmt->close();
$conn->close();

// Return the calculated val to the app in JSON format with val inside a data class
echo json_encode(array("data" => array("val" => $val)));

?>
