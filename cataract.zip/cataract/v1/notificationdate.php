<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect pat_id from user
$pat_id = $_POST['pat_id']; // Assuming pat_id is sent via POST request

// Get current date
$currentDate = date("Y-m-d");

// Update start_date with current date
$sql = "UPDATE reminder SET start_date='$currentDate'";
if ($conn->query($sql) === TRUE) {
    echo "Start date updated successfully.";
} else {
    echo "Error updating start date: " . $conn->error;
}

// Delete rows where current date is greater than end date
$sql = "DELETE FROM reminder WHERE '$currentDate' > end_date";
if ($conn->query($sql) === TRUE) {
    echo "Rows deleted successfully where current date is greater than end date.";
} else {
    echo "Error deleting rows: " . $conn->error;
}

// Check if the entry already exists for the given pat_id and today's date
$sql_check = "SELECT * FROM drugs WHERE pat_id='$pat_id' AND Date='$currentDate'";
$result_check = $conn->query($sql_check);

if ($result_check->num_rows == 0) {
    // Insert a new row with today's date and pat_id
    $sql_insert = "INSERT INTO drugs (Date, pat_id) VALUES ('$currentDate', '$pat_id')";
    if ($conn->query($sql_insert) === TRUE) {
        echo "New row inserted successfully in drugs table.";
    } else {
        echo "Error inserting new row in drugs table: " . $conn->error;
    }
} else {
    echo "Entry already exists for the given pat_id and today's date.";
}

// Close connection
$conn->close();
?>
