<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the necessary fields are present in the form data
    $targetDirectory = "images/";
    $imagePaths = uploadImages("image");

    if (
        isset($_POST['doc_id']) &&
        isset($_POST['username']) &&
        isset($_POST['email']) &&
        isset($_POST['password']) &&
        isset($_POST['gender']) &&
        isset($_POST['speciality']) &&
        isset($_POST['qualification'])
    ) {
        // Extract form data
        $doc_id = intval($_POST['doc_id']); // Convert doctor_id to integer
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $speciality = $_POST['speciality'];
        $qualification = $_POST['qualification'];

        // Check if a new image is uploaded
        if (!empty($imagePaths)) { // Check if $imagePaths is not empty
            $image = implode(",", $imagePaths);

            // Update both image and other fields
            $stmt = $conn->prepare("UPDATE doctor SET username=?, password=?, email=?, gender=?, speciality=?, qualification=?, image=? WHERE doc_id=?");
            $stmt->bind_param("sssssssi", $username, $password, $email, $gender, $speciality, $qualification, $image, $doc_id);
        } else {
            // Update only other fields, without updating the image
            $stmt = $conn->prepare("UPDATE doctor SET username=?, password=?, email=?, gender=?, speciality=?, qualification=? WHERE doc_id=?");
            $stmt->bind_param("ssssssi", $username, $password, $email, $gender, $speciality, $qualification, $doc_id);
        }

        // Execute the update query
        if ($stmt->execute()) {
            $response['error'] = false;
            $response['message'] = "Doctor record updated successfully";
        } else {
            $response['error'] = true;
            $response['message'] = "Some error occurred while updating doctor record";
        }
        $stmt->close();
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}


// Close connection
$conn->close();

// Output JSON response


function uploadImages($fieldName) {
    global $targetDirectory;
    $result = [];

    // Check if the field name exists and if it's an array
    if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
        foreach ($_FILES[$fieldName]["name"] as $key => $value) {
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
    } elseif (isset($_FILES[$fieldName])) {
        // If there's only one file, treat it as an array
        $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
        if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}
header('Content-Type: application/json');
echo json_encode($response);
?>
 