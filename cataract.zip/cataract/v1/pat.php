<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if pat_id is provided, indicating a request for a single patient's data
$pat_id = isset($_REQUEST['pat_id']) ? $_REQUEST['pat_id'] : null;

if ($pat_id !== null) {
    // Fetch data for a single patient
    $stmt = $conn->prepare("SELECT firstname ,lastname FROM patients WHERE pat_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $pat_id);
    $stmt->execute();

    $result = $stmt->get_result();

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $patientData = $result->fetch_assoc();

    echo json_encode($patientData);

    $stmt->close();
} else {
    // Get doctor_id from the request, supporting both POST and GET
    $doctor_id = isset($_REQUEST['doctor_id']) ? $_REQUEST['doctor_id'] : null;

    if ($doctor_id === null) {
        die("Doctor ID is required");
    }

    // Retrieve a list of patients for a given doctor_id
    $stmt = $conn->prepare("SELECT firstname, lastname, pat_id, image FROM patients WHERE doctor_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();

    $result = $stmt->get_result();

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $patients = array();

    while ($row = $result->fetch_assoc()) {
        $row['name'] = $row['firstname'] . ' ' . $row['lastname'];
        unset($row['firstname']);
        unset($row['lastname']);
        $patients[] = $row;
    }

    echo json_encode($patients);

    $stmt->close();
}

$conn->close();
?>
