<?php

require_once '../includes/dboperations.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Array to store missing fields
    $missing_fields = array();

    // Check for each required field
    if (!isset($_POST['pat_id'])) {
        $missing_fields[] = "pat_id";
    }
    if (!isset($_POST['medication_name'])) {
        $missing_fields[] = "medication_name";
    }
    if (!isset($_POST['interval_minutes'])) {
        $missing_fields[] = "interval_minutes";
    }
    if (!isset($_POST['number_of_days'])) {
        $missing_fields[] = "number_of_days";
    }
    if (!isset($_POST['eye'])) {
        $missing_fields[] = "eye";
    }
    if (!isset($_POST['type'])) {
        $missing_fields[] = "type";
    }
    if (!isset($_POST['days'])) {
        $missing_fields[] = "days";
    }
    if (!isset($_POST['intervals'])) {
        $missing_fields[] = "intervals";
    }
    if (!isset($_POST['total'])) {
        $missing_fields[] = "total";
    }

    // If there are missing fields, respond with error
    if (!empty($missing_fields)) {
        $response['error'] = true;
        $response['message'] = "Required field(s) missing: " . implode(", ", $missing_fields);
    } else {
        // All required fields are present, proceed with the operation
        $db = new DbOperation();

        $pat_id = $_POST['pat_id'];
        $medication_name = $_POST['medication_name'];
        $start_date = date('Y-m-d');
        $interval_minutes = $_POST['interval_minutes'];
        $number_of_days = $_POST['number_of_days']; 
        $end_date = date('Y-m-d', strtotime($start_date . ' + ' . $number_of_days . ' days'));
        $eye = $_POST['eye'];
        $type = $_POST['type'];
        $days = $_POST['days'];
        $intervals = $_POST['intervals'];
        $total = $_POST['total'];

        // Calculate total
 
        $eight = isset($_POST['eight']) ? $_POST['eight'] : 0;
        $nine = isset($_POST['nine']) ? $_POST['nine'] : 0;
        $ten = isset($_POST['ten']) ? $_POST['ten'] : 0;
        $eleven = isset($_POST['eleven']) ? $_POST['eleven'] : 0;
        $twelve = isset($_POST['twelve']) ? $_POST['twelve'] : 0;
        $thirteen = isset($_POST['thirteen']) ? $_POST['thirteen'] : 0;
        $fourteen = isset($_POST['fourteen']) ? $_POST['fourteen'] : 0;
        $fifteen = isset($_POST['fifteen']) ? $_POST['fifteen'] : 0;
        $sixteen = isset($_POST['sixteen']) ? $_POST['sixteen'] : 0;
        $seventeen = isset($_POST['seventeen']) ? $_POST['seventeen'] : 0;
        $eighteen = isset($_POST['eighteen']) ? $_POST['eighteen'] : 0;
        $nineteen = isset($_POST['nineteen']) ? $_POST['nineteen'] : 0;
        $twenty = isset($_POST['twenty']) ? $_POST['twenty'] : 0;

        // Call the reminder function and pass $response variable
        $result = $db->reminder($pat_id, $medication_name, $start_date, $end_date, $interval_minutes, $eye, $type, $days, $intervals, $eight, $nine, $ten, $eleven, $twelve, $thirteen, $fourteen, $fifteen, $sixteen, $seventeen, $eighteen, $nineteen, $twenty , $total);

        if ($result === true) {
            $response['error'] = false;
            $response['message'] = "Medication reminder scheduled successfully!";
        } else {
            $response['error'] = true;
            $response['message'] = "Error scheduling the medication reminder: " . $result;
        }
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?> 
