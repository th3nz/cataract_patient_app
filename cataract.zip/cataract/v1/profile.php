<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch patients from the database
$result = $conn->query("SELECT firstname, lastname, image FROM po");

$patients = array();

while ($row = $result->fetch_assoc()) {
    // Join first name and last name with a space
    $row['name'] = $row['firstname'] . ' ' . $row['lastname'];

    // Remove separate first name and last name fields if not needed
    unset($row['firstname']);
    unset($row['lastname']);

    $patients[] = $row;
}

echo json_encode($patients);

$conn->close();
?>
