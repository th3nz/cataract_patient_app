<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get pat_id and date from the request
$pat_id = isset($_REQUEST['pat_id']) ? $_REQUEST['pat_id'] : null;
$date = isset($_REQUEST['date']) ? $_REQUEST['date'] : null;
#$date = date('Y-m-d', strtotime($selectedDate));

if ($pat_id === null || $date === null) {
    die("Patient Id and Date are required");
}

// Insert the reminder into the database
$stmt = $conn->prepare("INSERT INTO reviews (pat_id, date) VALUES (?, ?)");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("is", $pat_id, $date);

if ($stmt->execute()) {
    echo "Reminder saved successfully";
} else {
    echo "Error saving reminder: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
