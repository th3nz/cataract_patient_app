<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get pat_id from the request, supporting both POST and GET
$pat_id = isset($_REQUEST['pat_id']) ? $_REQUEST['pat_id'] : null;

if ($pat_id === null) {
    die("Patient Id is required");
}

// Fetch dates from the database
$stmt = $conn->prepare("SELECT status FROM appointments WHERE pat_id = ?");
$stmt->bind_param("i", $pat_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $improvements = array();

    while ($row = $result->fetch_assoc()) {
        $status[] = $row['status'];
    }

    // Output JSON for easy consumption in Swift without escaping slashes
    echo json_encode($status, JSON_UNESCAPED_SLASHES);
} else {
    echo "0 results";
}

$stmt->close();
$conn->close();
?>
