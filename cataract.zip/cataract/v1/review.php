<?php
require_once '../includes/dboperations.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['doctor_id']) && isset($_POST['patient_id']) && isset($_POST['review_date']) && isset($_POST['attended']) && isset($_POST['missed']) && isset($_POST['improvement'])) {
        $db = new DbOperation();

        $doctor_id = $_POST['doctor_id'];
        $patient_id = $_POST['patient_id'];
        $review_date = $_POST['review_date'];
        $attended = $_POST['attended'];
        $missed = $_POST['missed'];
        $improvement = $_POST['improvement'];

        if ($db->createReview($doctor_id, $patient_id, $review_date, $attended, $missed, $improvement)) {
            $response['error'] = false;
            $response['message'] = "Patient review created successfully!";
        } else {
            $response['error'] = true;
            $response['message'] = "Error creating the patient review";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
