<?php
// Database connection
require_once dirname(__FILE__) . '/../includes/dbconnect.php';
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check if the connection is successful
if ($conn === false) {
    $response = array("success" => false, "message" => "Connection failed");
    echo json_encode($response);
    exit();
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Assign the pat_id from the POST data
    $pat_id = isset($_POST['pat_id']) ? $_POST['pat_id'] : null;

    if ($pat_id === null) {
        $response = array("success" => false, "message" => "pat_id is required");
        echo json_encode($response);
        exit();
    }

    // Prepare and execute the SQL query to fetch data
    $stmt = $conn->prepare("SELECT * FROM progress WHERE pat_id = ?");
    $stmt->bind_param("i", $pat_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the data into an associative array
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Close the statement
    $stmt->close();

    // Check if any data was found
    if (empty($data)) {
        $response = array("success" => false, "message" => "No data found for pat_id: $pat_id");
        echo json_encode($response);
    } else {
        // Return the data as JSON
        echo json_encode($data);
    }
} else {
    // If the request method is not POST, show an error message
    $response = array("success" => false, "message" => "Error: Invalid request method");
    echo json_encode($response);
}

// Close the connection
$conn->close();
?>
