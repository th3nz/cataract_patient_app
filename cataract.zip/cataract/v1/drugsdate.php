<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pat_id from the request parameters (POST method)
$pat_id = $_POST['pat_id'];

// Get today's date in the format 'YYYY-MM-DD'
$today_date = date("Y-m-d");

// Check if today's date already exists for the given pat_id
$sql_check_date = "SELECT * FROM drugs WHERE pat_id = '$pat_id' AND Date = '$today_date'";
$result_check_date = $conn->query($sql_check_date);

if ($result_check_date->num_rows == 0) {
    // If today's date does not exist for the given pat_id, insert it into the drugs table
    $sql_insert_date = "INSERT INTO drugs (pat_id, Date) VALUES ('$pat_id', '$today_date')";
    if ($conn->query($sql_insert_date) === TRUE) {
        $response = array(
            "status" => "success",
            "message" => "Today's date added successfully for pat_id: $pat_id."
        );
    } else {
        $response = array(
            "status" => "error",
            "message" => "Error: " . $conn->error
        );
    }
} else {
    $response = array(
        "status" => "success",
        "message" => "Today's date already exists for pat_id: $pat_id."
    );
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
