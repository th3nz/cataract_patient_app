<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get doc_id from the request, supporting both POST and GET
$doc_id = isset($_REQUEST['doc_id']) ? $_REQUEST['doc_id'] : null;

if ($doc_id === null) {
    die("Patient Id is required");  
}

// Fetch dates from the database
$stmt = $conn->prepare("SELECT name FROM appointments WHERE doc_id = ? AND status='Accepted' ");
$stmt->bind_param("i", $doc_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $improvements = array();

    while ($row = $result->fetch_assoc()) {
        $name[] = $row['name'];
    }

    // Output JSON for easy consumption in Swift without escaping slashes
    echo json_encode($name, JSON_UNESCAPED_SLASHES);
} else {
    echo "0 results";
}

$stmt->close();
$conn->close();
?>
