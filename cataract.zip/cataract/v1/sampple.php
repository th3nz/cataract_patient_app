<?php
require_once '../includes/dboperations.php';
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the necessary fields are present in the form data
    if (
        isset($_POST['doctor_id']) &&
        isset($_POST['firstname']) &&
        isset($_POST['lastname']) &&
        isset($_POST['email']) &&
        isset($_POST['password']) &&
        isset($_POST['gender']) &&
        isset($_POST['age']) &&
        isset($_POST['surgerydate'])
    ) {
        $db = new DbOperation();

        // Extract form data
        $doctor_id = intval($_POST['doctor_id']); // Convert doctor_id to integer
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $surgerydate = $_POST['surgerydate'];
        $age = $_POST['age'];

        // Call the addpatient function with extracted data
        if ($db->addpatient($doctor_id, $firstname, $lastname, $password, $email, $gender, $surgerydate, $age)) {
            $response['error'] = false;
            $response['message'] = "User registered successfully";
        } else {
            $response['error'] = true;
            $response['message'] = "Some error occurred, please try again";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
