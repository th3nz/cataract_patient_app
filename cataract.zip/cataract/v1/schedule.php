<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();



// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the current date
$currentDate = date('Y-m-d');

// Check if there is an existing record for the current date
$sqlCheck = "SELECT COUNT(*) FROM symptoms WHERE entry_date = '$currentDate'";
$resultCheck = $conn->query($sqlCheck);

if ($resultCheck->fetch_assoc()['COUNT(*)'] == 0) {
    echo "No symptoms recorded for today. Please enter your symptoms.";
} else {
    echo "Symptoms for today already recorded.";
}

// Close the database connection
$conn->close();

?>
c