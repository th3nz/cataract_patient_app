<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Include the file with DbConnect class definition
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check if the database connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if pat_id and url are provided in the request
if (!isset($_POST['pat_id']) || !isset($_POST['url'])) {
    echo json_encode(array('status' => 'error', 'message' => 'pat_id or url parameter is missing.'));
    exit;
}

$pat_id = $_POST['pat_id'];
$url = $_POST['url'];

// Fetch images for the provided pat_id
$sql = "SELECT * FROM gallery WHERE pat_id = '$pat_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $images = array();
    while ($row = $result->fetch_assoc()) {
        // Concatenate URL prefix with each image path
        $images[] = $url . $row['images'];
    }
    echo json_encode(array('status' => 'success', 'images' => $images));
} else {
    echo json_encode(array('status' => 'error', 'message' => 'No images found for the provided pat_id.'));
}

// Close the database connection
$conn->close();
?>