<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pat_id and medication values from the request parameters (POST method)
$pat_id = $_POST['pat_id'];
$Predforte_eyedrops = isset($_POST['Predforte-eyedrops']) ? $_POST['Predforte-eyedrops'] : 0;
$Vigamox_eyedrops = isset($_POST['Vigamox-eyedrops']) ? $_POST['Vigamox-eyedrops'] : 0;
$Hypersol_eyedrops = isset($_POST['Hypersol-eyedrops']) ? $_POST['Hypersol-eyedrops'] : 0;
$Hypersol_ointment = isset($_POST['Hypersol-ointment']) ? $_POST['Hypersol-ointment'] : 0;
$Nevenac_eyedrops = isset($_POST['Nevenac-eyedrops']) ? $_POST['Nevenac-eyedrops'] : 0;
$Pan_40Mg = isset($_POST['Pan-40Mg']) ? $_POST['Pan-40Mg'] : 0;
$Diamox_250Mg = isset($_POST['Diamox-250Mg']) ? $_POST['Diamox-250Mg'] : 0;
$Cipro_500Mg = isset($_POST['Cipro-500Mg']) ? $_POST['Cipro-500Mg'] : 0;
$Para_500Mg = isset($_POST['Para-500Mg']) ? $_POST['Para-500Mg'] : 0;

// Get today's date
$today_date = date("Y-m-d");

// Update the existing values in the drugs table for the given pat_id and today's date
$sql_update = "UPDATE drugs 
               SET `Predforte-eyedrops` = `Predforte-eyedrops` + $Predforte_eyedrops,
                   `Vigamox-eyedrops` = `Vigamox-eyedrops` + $Vigamox_eyedrops,
                   `Hypersol-eyedrops` = `Hypersol-eyedrops` + $Hypersol_eyedrops,
                   `Hypersol-ointment` = `Hypersol-ointment` + $Hypersol_ointment,
                   `Nevenac-eyedrops` = `Nevenac-eyedrops` + $Nevenac_eyedrops,
                   `Pan-40Mg` = `Pan-40Mg` + $Pan_40Mg,
                   `Diamox-250Mg` = `Diamox-250Mg` + $Diamox_250Mg,
                   `Cipro-500Mg` = `Cipro-500Mg` + $Cipro_500Mg,
                   `Para-500Mg` = `Para-500Mg` + $Para_500Mg
               WHERE pat_id = '$pat_id' AND Date = '$today_date'";

// Execute the update query
if ($conn->query($sql_update) === TRUE) {
    $response = array(
        "status" => "success",
        "message" => "Data updated successfully for pat_id: $pat_id and today's date."
    );
} else {
    $response = array(
        "status" => "error",
        "message" => "Error: " . $conn->error
    );
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
