<?php
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Assign values from $_POST to variables
    $pat_id = isset($_POST['pat_id']) ? $_POST['pat_id'] : 1;
    $Predforte_eyedrops = isset($_POST['Predforte_eyedrops']) ? $_POST['Predforte_eyedrops'] : 0;
    $Vigamox_eyedrops = isset($_POST['Vigamox_eyedrops']) ? $_POST['Vigamox_eyedrops'] : 0;
    $Hypersol_eyedrops = isset($_POST['Hypersol_eyedrops']) ? $_POST['Hypersol_eyedrops'] : 0;
    $Hypersol_ointment = isset($_POST['Hypersol_ointment']) ? $_POST['Hypersol_ointment'] : 0;
    $Nevenac_eyedrops = isset($_POST['Nevenac_eyedrops']) ? $_POST['Nevenac_eyedrops'] : 0;
    $Pan_40Mg = isset($_POST['Pan_40Mg']) ? $_POST['Pan_40Mg'] : 0;
    $Diamox_250Mg = isset($_POST['Diamox_250Mg']) ? $_POST['Diamox_250Mg'] : 0;
    $Cipro_500Mg = isset($_POST['Cipro_500Mg']) ? $_POST['Cipro_500Mg'] : 0;
    $Para_500Mg = isset($_POST['Para_500Mg']) ? $_POST['Para_500Mg'] : 0;
    $Date = date("Y-m-d"); // Today's date

    // Database connection
    require_once dirname(__FILE__) . '/../includes/dbconnect.php';
    $dbConnect = new DbConnect();
    $conn = $dbConnect->connect();

    // Check if the connection is successful
    if ($conn === false) {
        $response = array("success" => false, "message" => "Connection failed");
        echo json_encode($response);
        exit();
    }

    // Check if a record with the same date exists
    $checkStmt = $conn->prepare("SELECT id FROM progress WHERE Date = ?");
    $checkStmt->bind_param("s", $Date);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Update the existing record
        $updateStmt = $conn->prepare("UPDATE progress SET pat_id=?, `Predforte-eyedrops`=?, `Vigamox-eyedrops`=?, `Hypersol-eyedrops`=?, `Hypersol-ointment`=?, `Nevenac-eyedrops`=?, `Pan-40Mg`=?, `Diamox-250Mg`=?, `Cipro-500Mg`=?, `Para-500Mg`=? WHERE Date=?");
        $updateStmt->bind_param("iiiiiiiiiis", $pat_id, $Predforte_eyedrops, $Vigamox_eyedrops, $Hypersol_eyedrops, $Hypersol_ointment, $Nevenac_eyedrops, $Pan_40Mg, $Diamox_250Mg, $Cipro_500Mg, $Para_500Mg, $Date);
        if ($updateStmt->execute() === TRUE) {
            $response = array("success" => true, "message" => "Record updated successfully");
            echo json_encode($response);
        } else {
            $response = array("success" => false, "message" => "Error updating record: " . $updateStmt->error);
            echo json_encode($response);
        }
        $updateStmt->close();
    } else {
        // Insert a new record
        $insertStmt = $conn->prepare("INSERT INTO progress (pat_id, `Predforte-eyedrops`, `Vigamox-eyedrops`, `Hypersol-eyedrops`, `Hypersol-ointment`, `Nevenac-eyedrops`, `Pan-40Mg`, `Diamox-250Mg`, `Cipro-500Mg`, `Para-500Mg`, `Date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insertStmt->bind_param("iiiiiiiiiis", $pat_id, $Predforte_eyedrops, $Vigamox_eyedrops, $Hypersol_eyedrops, $Hypersol_ointment, $Nevenac_eyedrops, $Pan_40Mg, $Diamox_250Mg, $Cipro_500Mg, $Para_500Mg, $Date);
        if ($insertStmt->execute() === TRUE) {
            $response = array("success" => true, "message" => "New record inserted successfully");
            echo json_encode($response);
        } else {
            $response = array("success" => false, "message" => "Error inserting record: " . $insertStmt->error);
            echo json_encode($response);
        }
        $insertStmt->close();
    }

    // Close the connection
    $checkStmt->close();
    $conn->close();
} else {
    // If the request method is not POST, show an error message
    $response = array("success" => false, "message" => "Error: Invalid request method");
    echo json_encode($response);
}
?>
