<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch pat_id from the request parameters
$pat_id = $_POST['pat_id'];

// Fetch reminders based on pat_id from the database
$sql = "SELECT * FROM reminder WHERE pat_id = '$pat_id'";
$result = $conn->query($sql);

// Prepare an array to store the fetched data
$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>