<?php
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Check if 'pat_id' is set in the $_POST array
if(isset($_POST['pat_id'])) {
    $pat_id = $_POST['pat_id'];

    $dbConnect = new DbConnect();
    $con = $dbConnect->connect();

    // Use prepared statement to avoid SQL injection
    $loginqry = "SELECT pat_id, doctor_id, firstname, lastname, password, email, gender, surgerydate, age, eye, sx_details, sx_details1, sx_details2, sx_details3, sx_details4, sx_details5, contact1, contact2 FROM patients WHERE pat_id=?";
    $stmt = mysqli_prepare($con, $loginqry);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, "i", $pat_id);

    // Execute the query
    mysqli_stmt_execute($stmt);

    // Get the result
    $result = mysqli_stmt_get_result($stmt);

    $response = array();

    if (mysqli_num_rows($result) > 0) {
        $userObj = mysqli_fetch_assoc($result);
        $response['status'] = true;
        $response['message'] = "Patient found";
        $response['data'] = $userObj;
    } else {
        $response['status'] = false;
        $response['message'] = "Patient not found";
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle the case when 'pat_id' is not set in $_POST
    $response = array('status' => false, 'message' => 'pat_id not provided');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>