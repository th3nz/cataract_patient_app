<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get pat_id from the request, supporting both POST and GET
$pat_id = isset($_REQUEST['pat_id']) ? $_REQUEST['pat_id'] : null;

if ($pat_id === null) {
    die("Patient Id is required");
}

// Fetch data from the database using a prepared statement
$stmt = $conn->prepare("SELECT * FROM reminder WHERE pat_id = ?");
$stmt->bind_param("i", $pat_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $topicals = array();
    $tablets = array();

    // Fetch data and organize it into the reminders array
    while ($row = $result->fetch_assoc()) {
        $reminder = array(
            'eye' => $row['eye'],
            'intervals' => $row['intervals'],
            'days' => $row['days'],
            'medicationName' => $row['medication_name'],
            'type' => $row['type']
        );

        // Separate reminders into topicals and tablets
        if ($reminder['type'] == 'topicals') {
            $topicals[] = $reminder;
        } elseif ($reminder['type'] == 'tablets') {
            $tablets[] = $reminder;
        }
    }

    // Output JSON for easy consumption in Swift
    echo json_encode(array('topicals' => $topicals, 'tablets' => $tablets));
} else {
    echo "0 results";
}

$stmt->close();
$conn->close();
?>
