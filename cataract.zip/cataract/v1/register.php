<?php
require_once '../includes/dboperations.php';
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (
        isset($_POST['username']) &&
        isset($_POST['email']) &&
        isset($_POST['password'])
    ) {
        $db = new DbOperation();

        if ($db->createUser(
            $_POST['username'],
            $_POST['password'],
            $_POST['email']
        )) {
            $response['error'] = false;
            $response['message'] = "User registered successfully";
        } else {
            $response['error'] = true;
            $response['message'] = "Some error occurred, please try again";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
