<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Check if 'email' and 'password' are set in the $_POST array
if(isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $user_password = $_POST['password'];

    $dbConnect = new DbConnect();
    $con = $dbConnect->connect();

    // Use prepared statement to avoid SQL injection
    $loginqry = "SELECT * FROM doctor WHERE email = ? AND password = ?";
    $stmt = mysqli_prepare($con, $loginqry);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ss", $email, $user_password);

    // Execute the query
    mysqli_stmt_execute($stmt);

    // Get the result
    $result = mysqli_stmt_get_result($stmt);

    $response = array();

    if (mysqli_num_rows($result) > 0) {    
        $userObj = mysqli_fetch_assoc($result);
        $response['status'] = true;
        $response['message'] = "Login Successfully";
        $response['data'] = $userObj;
    } else {
        $response['status'] = false;
        $response['message'] = "Login Failed";
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle the case when 'email' or 'password' is not set in $_POST
    $response = array('status' => false, 'message' => 'Email or password not provided');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>
