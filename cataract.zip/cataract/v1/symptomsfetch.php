<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch symptoms from the latest row for a given pat_id
$pat_id = $_POST['pat_id']; // Assuming you're passing pat_id via POST method

$sql = "SELECT * FROM symptoms WHERE pat_id = $pat_id ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $symptoms = array();

    if ($row['headache'] == 1) {
        $symptoms[] = "Headache";
    }
    if ($row['redness'] == 1) {
        $symptoms[] = "Redness";
    }
    if ($row['eye_discharge'] == 1) {
        $symptoms[] = "Eye Discharge";
    }
    if ($row['floaters'] == 1) {
        $symptoms[] = "Floaters";
    }
    if ($row['flashes'] == 1) {
        $symptoms[] = "Flashes";
    }
    if ($row['nausea'] == 1) {
        $symptoms[] = "Nausea";
    }
    if ($row['watering'] == 1) {
        $symptoms[] = "Watering";
    }

    // Concatenate symptoms into a single string separated by spaces
    $symptomsString = implode(" ", $symptoms);

    // Add symptoms string to response array
    $response['symptoms'] = $symptomsString;
} else {
    // Add error message to response array if no symptoms found
    $response['error'] = "No symptoms found for the given pat_id";
}

// Close database connection
$conn->close();

// Encode response array to JSON and output
echo json_encode($response);

?>