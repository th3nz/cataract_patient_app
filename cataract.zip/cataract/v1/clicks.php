<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pat_id from the request parameters (POST method)
$pat_id = $_POST['pat_id'];

// Fetch total clicks from the patients table
$sql_clicks = "SELECT click FROM patients WHERE pat_id = '$pat_id'";
$result_clicks = $conn->query($sql_clicks);
$total_clicks = $result_clicks->fetch_assoc()['click'];

// Fetch the largest 'total' value from the reminder table
$sql_total = "SELECT MAX(total) AS max_total FROM reminder WHERE pat_id = '$pat_id'";
$result_total = $conn->query($sql_total);
$max_total = $result_total->fetch_assoc()['max_total'];

// Calculate the ratio of clicks to the largest 'total' value
$ratio = $max_total > 0 ? $total_clicks / $max_total : 0;

// Close the connection
$conn->close();

// Prepare the response data
$response_data = array(
    'total_clicks' => $total_clicks,
    'max_total' => $max_total,
    'clicks_to_max_total_ratio' => $ratio
);

// Return the data as JSON
echo json_encode($response_data);
?>
