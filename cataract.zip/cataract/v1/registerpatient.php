<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Upload images
    $targetDirectory = "images/";
    $imagePaths = uploadImages("image");

    // Check if the necessary fields are present in the form data
    if (
        isset($_POST['doctor_id']) &&
        isset($_POST['firstname']) &&
        isset($_POST['lastname']) &&
        isset($_POST['email']) &&
        isset($_POST['password']) &&
        isset($_POST['gender']) &&
        isset($_POST['age']) &&
        isset($_POST['surgerydate']) &&
        isset($_POST['eye']) &&
        isset($_POST['sx_details']) &&
        isset($_POST['sx_details1'])&&
        isset($_POST['sx_details2'])&&
        isset($_FILES['image'])
    ) {
        // Extract form data
        $doctor_id = intval($_POST['doctor_id']); // Convert doctor_id to integer
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $surgerydate = $_POST['surgerydate'];
        $age = $_POST['age'];
        $eye = $_POST['eye'];
        $sx_details = $_POST['sx_details'];
        $sx_details1 = $_POST['sx_details1'];
        $sx_details2 = $_POST['sx_details2'];

        try {
            // Prepare and bind parameters
            $stmt = $conn->prepare("INSERT INTO patients (doctor_id, firstname, lastname, password, email, gender, surgerydate, age, eye, sx_details, sx_details1, sx_details2, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ? , ?)");
            $stmt->bind_param("issssssssssss", $doctor_id, $firstname, $lastname, $password, $email, $gender, $surgerydate, $age, $eye, $sx_details, $sx_details1, $sx_details2, $image);

            // Concatenate image paths into a single string
            $image = implode(",", $imagePaths);

            // Execute the query
            if ($stmt->execute()) {
                $response['error'] = false;
                $response['message'] = "User registered successfully";
            } else {
                $response['error'] = true;
                $response['message'] = "Some error occurred, please try again";
            }

            // Close statement
            $stmt->close();
        } catch (mysqli_sql_exception $exception) {
            // Check if the exception is due to duplicate entry
            if ($exception->getCode() == 1062) {
                $response['error'] = true;
                $response['message'] = "Email already exists";
            } else {
                // Other database error
                $response['error'] = true;
                $response['message'] = "Database error: " . $exception->getMessage();
            }
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

// Close connection
$conn->close();

function uploadImages($fieldName) {
    global $targetDirectory;
    $result = [];

    // Check if the field name exists and if it's an array
    if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
        foreach ($_FILES[$fieldName]["name"] as $key => $value) {
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
    } elseif (isset($_FILES[$fieldName])) {
        // If there's only one file, treat it as an array
        $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
        if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>