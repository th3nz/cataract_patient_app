<?php
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$currentDate = date('Y-m-d');
$patId = isset($_POST['pat_id']) ? $_POST['pat_id'] : 0;

$sqlCheckPatient = "SELECT COUNT(*) FROM patients WHERE pat_id = $patId";
$resultCheckPatient = $conn->query($sqlCheckPatient);

if ($resultCheckPatient->fetch_assoc()['COUNT(*)'] > 0) {
    $sqlCheck = "SELECT COUNT(*) FROM symptoms WHERE pat_id = $patId AND entry_date = '$currentDate'";
    $resultCheck = $conn->query($sqlCheck);

    if ($resultCheck->fetch_assoc()['COUNT(*)'] == 0) {
        $headache = isset($_POST['headache']) ? $_POST['headache'] : 0;
        $redness = isset($_POST['redness']) ? $_POST['redness'] : 0;
        $eyeDischarge = isset($_POST['eye_discharge']) ? $_POST['eye_discharge'] : 0;
        $floaters = isset($_POST['floaters']) ? $_POST['floaters'] : 0;
        $flashes = isset($_POST['flashes']) ? $_POST['flashes'] : 0;
        $nausea = isset($_POST['nausea']) ? $_POST['nausea'] : 0;
        $watering = isset($_POST['watering']) ? $_POST['watering'] : 0;

        // Calculate severity
        $severity = $headache + $redness + $eyeDischarge + $floaters + $flashes + $nausea + $watering;

        $sqlInsert = "INSERT INTO symptoms (pat_id, Headache, Redness, Eye_Discharge, Floaters, Flashes, Nausea, Watering, isSelected, entry_date)
                      VALUES ($patId, $headache, $redness, $eyeDischarge, $floaters, $flashes, $nausea, $watering, 1, '$currentDate')";

        if ($conn->query($sqlInsert) === TRUE) {
            // Update severity in patients table
            $sqlUpdateSeverity = "UPDATE patients SET severity = $severity WHERE pat_id = $patId";
            $conn->query($sqlUpdateSeverity);

            echo json_encode(["message" => "Data inserted successfully", "error" => false]);
        } else {
            echo json_encode(["message" => "Error: " . $sqlInsert . "<br>" . $conn->error, "error" => true]);
        }
    } else {
        echo json_encode(["message" => "Data for today already exists.", "error" => true]);
    }
} else {
    echo json_encode(["message" => "Error: Patient with pat_id $patId does not exist.", "error" => true]);
}

$conn->close();
?>
