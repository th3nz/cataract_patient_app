<?php
require_once dirname(__FILE__) . '/../includes/dbconnect.php';

$pat_id = $_POST['pat_id'];


$dbConnect = new DbConnect();
$con = $dbConnect->connect();

// Use prepared statement to avoid SQL injection
$loginqry = "SELECT * FROM patients WHERE pat_id = ? ";
$stmt = mysqli_prepare($con, $loginqry);

// Bind parameters
mysqli_stmt_bind_param($stmt, "i", $pat_id);

// Execute the query
mysqli_stmt_execute($stmt);

// Get the result
$result = mysqli_stmt_get_result($stmt);

$response = array();

if (mysqli_num_rows($result) > 0) {    
    $userObj = mysqli_fetch_assoc($result);
    $response['status'] = true;
    $response['message'] = "Login Successfully";
    $response['data'] = $userObj;
} else {
    $response['status'] = false;
    $response['message'] = "Login Failed";
}

// Close the prepared statement
mysqli_stmt_close($stmt);

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>