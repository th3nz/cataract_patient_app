<?php
require_once '../includes/dboperations.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['pat_id']) && isset($_POST['doc_id']) && isset($_POST['times']) && isset($_POST['dateselected'])) {
        $db = new DbOperation();

        $pat_id = $_POST['pat_id'];
        $doc_id = $_POST['doc_id'];
        $times = $_POST['times'];
        $dateselected = $_POST['dateselected'];

        // Add a variable for the current date and times
        $currentDate = date('Y-m-d');

        if ($db->appointment($pat_id, $doc_id, $times, $dateselected, $currentDate)) {
            $response['error'] = false;
            $response['message'] = "Medication reminder scheduled successfully!";
        } else {
            $response['error'] = true;
            $response['message'] = "Error scheduling the medication reminder";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
