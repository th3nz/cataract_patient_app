<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

$response = array();

if ($conn->connect_error) {
    $response['status'] = 'error';
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    // Get the pat_id from the request parameters
    $pat_id = $_POST['pat_id'];

    // Fetch the highest total for each drug for the given pat_id
    $Predforte_eyedrops_total = 1;
    $Vigamox_eyedrops_total = 1;
    $Hypersol_eyedrops_total = 1;
    $Hypersol_ointment_total = 1;
    $Nevenac_eyedrops_total = 1;
    $Pan_40Mg_total = 1;
    $Diamox_250Mg_total = 1;
    $Cipro_500Mg_total = 1;
    $Para_500Mg_total = 1;

    // Fetch total for Predforte-eyedrops
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Predforte-eyedrops' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Predforte_eyedrops_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Vigamox-eyedrops
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Vigamox-eyedrops' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Vigamox_eyedrops_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Hypersol-eyedrops
    // Repeat the process for each drug...
    
    // Fetch total for Hypersol-eyedrops
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Hypersol-eyedrops' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Hypersol_eyedrops_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Hypersol-ointment
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Hypersol-ointment' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Hypersol_ointment_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Nevenac-eyedrops
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Nevenac-eyedrops' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Nevenac_eyedrops_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Pan-40Mg
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Pan-40Mg' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Pan_40Mg_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Diamox-250Mg
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Diamox-250Mg' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Diamox_250Mg_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Cipro-500Mg
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Cipro-500Mg' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Cipro_500Mg_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    // Fetch total for Para-500Mg
    $sql = "SELECT MAX(total) AS highest_total FROM reminder WHERE medication_name = 'Para-500Mg' AND pat_id = '$pat_id'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $Para_500Mg_total = $row['highest_total'] !== null ? intval($row['highest_total']) : 1000;
    }

    $response['status'] = 'success';
    $response['Predforte_eyedrops_total'] = $Predforte_eyedrops_total;
    $response['Vigamox_eyedrops_total'] = $Vigamox_eyedrops_total;
    $response['Hypersol_eyedrops_total'] = $Hypersol_eyedrops_total;
    $response['Hypersol_ointment_total'] = $Hypersol_ointment_total;
    $response['Nevenac_eyedrops_total'] = $Nevenac_eyedrops_total;
    $response['Pan_40Mg_total'] = $Pan_40Mg_total;
    $response['Diamox_250Mg_total'] = $Diamox_250Mg_total;
    $response['Cipro_500Mg_total'] = $Cipro_500Mg_total;
    $response['Para_500Mg_total'] = $Para_500Mg_total;

    $conn->close();
}

echo json_encode($response);
?>
