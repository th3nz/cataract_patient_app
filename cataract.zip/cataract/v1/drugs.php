<?php
require_once '../includes/dboperations.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['doctor_id']) && isset($_POST['patient_id']) && isset($_POST['review_date']) && isset($_POST['drugs']) && isset($_POST['no_of_days']) && isset($_POST['interval'])) {
        $db = new DbOperation();

        $doctor_id = $_POST['doctor_id'];
        $patient_id = $_POST['patient_id'];
        $drugs = $_POST['drugs'];
        $no_of_days = $_POST['no_of_days'];
        $interval = $_POST['interval'];


        if ($db->drugs($doctor_id, $patient_id, $review_date, $drugs, $no_of_days  )) {
            $response['error'] = false;
            $response['message'] = "Patient review created successfully!";
        } else {
            $response['error'] = true;
            $response['message'] = "Error creating the patient review";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
