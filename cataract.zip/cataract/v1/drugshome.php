<?php
header('Content-Type: application/json');   
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get today's date in the format 'YYYY-MM-DD'
$today_date = date("Y-m-d");

// Fetch all data from the drugs table for today's date
$sql = "SELECT * FROM drugs WHERE Date = '$today_date'";
$result = $conn->query($sql);

// Prepare an array to store the fetched data
$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Convert numeric values to integers
        foreach ($row as $key => $value) {
            if (is_numeric($value)) {
                $row[$key] = (int)$value;
            }
        }
        $data[] = $row;
    }
}

// Close the connection
$conn->close();

// Return the data as JSON
echo json_encode($data);
?>
