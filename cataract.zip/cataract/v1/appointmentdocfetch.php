<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the doc_id from the app (modify this part based on how you receive it)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $doc_id = isset($_POST['doc_id']) ? $_POST['doc_id'] : null;

    // Fetch symptoms from the database for the specific doc_id
    $sql = "SELECT id, name, dateselected, currentDate, times FROM appointments WHERE status = 'Pending' AND doc_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $doc_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();          

        if ($result->num_rows > 0) {
            $symptoms = array();

            while ($row = $result->fetch_assoc()) {
                $symptoms[] = $row;
            }

            echo json_encode($symptoms);
        } else {
            echo "0 results";
        }
    } else {
        echo "Error executing query: " . $stmt->error;
    }   

    $stmt->close();
} else {
    echo "Invalid Request";
}

$conn->close();
?>