<?php

require_once '../includes/dboperations.php';

$response = array();
$db = new DbOperation();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['selectedDate'])) {
        $selectedDate = $_POST['selectedDate'];

        // Format the selected date
        $formatted_date = date('Y-m-d', strtotime($selectedDate));

        // Insert the formatted date into the database
        if ($db->insertSelectedDate($formatted_date)) {
            $response['error'] = false;
            $response['message'] = "Date inserted successfully";
        } else {
            $response['error'] = true;
            $response['message'] = "Failed to insert date into the database";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid Request";
}

// Retrieve the latest selected date from the database
$response['latestSelectedDate'] = $db->getLatestSelectedDate();

header('Content-Type: application/json');
echo json_encode($response);
?>
