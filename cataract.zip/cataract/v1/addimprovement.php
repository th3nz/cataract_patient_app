<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get parameters from the request
$pat_id = $_POST['pat_id'];
$date = $_POST['date'];
$improvement = $_POST['improvement'];

// Update the improvement data in the database
$sql = "UPDATE reviews SET improvement = ? WHERE pat_id = ? AND date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $improvement, $pat_id, $date);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    // Success
    $response = array('status' => 'success', 'message' => 'Improvement data updated successfully');
} else {
    // Error
    $response = array('status' => 'error', 'message' => 'Failed to update improvement data');
}

$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
