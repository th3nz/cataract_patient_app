<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

require_once dirname(__FILE__) . '/../includes/dbconnect.php';

// Assuming your DbConnect class has a proper implementation
$dbConnect = new DbConnect();
$conn = $dbConnect->connect();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check for required fields
    if (!isset($_POST['pat_id']) || empty($_POST['pat_id']) || !isset($_FILES['images'])) {
        $response = array('status' => 'error', 'message' => 'All fields are mandatory.');
        echo json_encode($response);
        exit;
    }

    // Get input data from the application
    $pat_id = $_POST['pat_id'];

    // Upload images
    $targetDirectory = "images/";
    $imagePaths = uploadImages("images");

    // Insert data into the gallery table
    $sql = "INSERT INTO gallery (pat_id, images) VALUES ('$pat_id', '" . implode(",", $imagePaths) . "')";

    if ($conn->query($sql) === TRUE) {
        // Successful insertion
        $response = array('status' => 'success', 'message' => 'User registration successful.');
        echo json_encode($response);
    } else {
        // Error in database insertion
        $response = array('status' => 'error', 'message' => 'Error: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();

function uploadImages($fieldName) {
    global $targetDirectory;
    $result = [];

    // Check if the field name exists and if it's an array
    if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
        foreach ($_FILES[$fieldName]["name"] as $key => $value) {
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
    } elseif (isset($_FILES[$fieldName])) {
        // If there's only one file, treat it as an array
        $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
        if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}
?>