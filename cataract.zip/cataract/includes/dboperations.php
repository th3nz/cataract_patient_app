<?php
class DbOperation {
    private $con;

    function __construct() {
        require_once dirname(__FILE__) . '/dbconnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();
    }

    /* CRUD -> C > CREATE */
    function createUser($username, $password, $email) {
        $stmt = $this->con->prepare("INSERT INTO `doctor` (`id`, `username`, `password`, `email`) VALUES (NULL, ?, ?, ?);");
    
        if (!$stmt) {
            // Handle the SQL error
            $response['error'] = true;
            $response['message'] = "SQL Error: " . $this->con->error;
            return false;
        }
    
        $stmt->bind_param("sss", $username, $password, $email);
    
        if ($stmt->execute()) {
            return true;
        } else {
            // Handle the execution error
            $response['error'] = true;
            $response['message'] = "Execution Error: " . $stmt->error;
            return false;
        }
    }   
    public function addpatient($doctor_id, $firstname, $lastname, $password, $email, $gender, $surgerydate, $age , $eye,$sx_details,$sx_details1) {
        // Ensure proper SQL query with parameters
        $sql = "INSERT INTO patients (doctor_id, firstname, lastname, password, email, gender, surgerydate, age , eye, sx_details, sx_details1) VALUES (?, ?, ?, ?, ?, ?, ?, ? , ?,?,?)";

        // Use prepared statement to avoid SQL injection
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("issssssisss", $doctor_id, $firstname, $lastname, $password, $email, $gender, $surgerydate, $age , $eye,$sx_details,$sx_details1);

        // Execute the statement
        if ($stmt->execute()) {
            return true;  // Success
        } else {
            return false; // Error
        }
    }
    
    function userLogin($username, $password) {
        $stmt = $this->con->prepare("SELECT * FROM `doctor` WHERE `username` = ? AND `password` = ?");

        if (!$stmt) {
            // Handle the SQL error
            $response['error'] = true;
            $response['message'] = "SQL Error: " . $this->con->error;
            return false;
        }

        $stmt->bind_param("ss", $username, $password);

        if ($stmt->execute()) {
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $stmt->close();
                return true;
            } else {
                $stmt->close();
                return false;
            }
        } else {
            // Handle the execution error
            $response['error'] = true;
            $response['message'] = "Execution Error: " . $stmt->error;
            return false;
        }
    }
    function reminder($pat_id, $medication_name, $start_date, $end_date, $interval_minutes, $eye, $type, $days, $intervals, $eight = 0 , $nine = 0 , $ten = 0 ,$eleven = 0 ,$twelve = 0 ,$thirteen = 0 ,$fourteen = 0 ,$fifteen = 0 ,$sixteen = 0 ,$seventeen = 0 ,$eighteen = 0 ,$nineteen = 0 ,$twenty = 0 ,$total = 0) {
        $stmt = $this->con->prepare("INSERT INTO reminder (pat_id, medication_name, start_date, end_date, interval_minutes, eye, type, days, intervals, status, eight, nine , ten , eleven , twelve , thirteen, fourteen , fifteen , sixteen , seventeen, eighteen , nineteen , twenty , total) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ? , ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?)");
    
        if (!$stmt) {
            // Handle the SQL error
            $response['error'] = true;
            $response['message'] = "SQL Error: " . $this->con->error;
            return false;
        }
    
        $stmt->bind_param("isssissisiiiiiiiiiiiiii", $pat_id, $medication_name, $start_date, $end_date, $interval_minutes, $eye, $type, $days, $intervals, $eight ,$nine , $ten ,$eleven ,$twelve ,$thirteen ,$fourteen ,$fifteen ,$sixteen ,$seventeen ,$eighteen ,$nineteen,$twenty , $total);
    
        if ($stmt->execute()) {
            return true;
        } else {
            // Handle the execution error
            $response['error'] = true;
            $response['message'] = "Execution Error: " . $stmt->error;
            return  $stmt->error;
        }
    }
    
    
    function appointment($pat_id,$doc_id , $times, $dateselected , $currentDate) {
        $stmt = $this->con->prepare("INSERT INTO appointments    ( pat_id,doc_id , times, dateselected ,  status,  currentDate)
                                    VALUES ( ? , ? , ?, ? ,  'Pending', ?)");
        if (!$stmt) {
            // Handle the SQL error
            $response['error'] = true;
            $response['message'] = "SQL Error: " . $this->con->error;
            return false;
        }
    
        $stmt->bind_param("iisss",$pat_id,$doc_id , $times, $dateselected , $currentDate );
    
        if ($stmt->execute()) {
            $this->updateAppointmentName($pat_id);
            return true;
        } else {
            // Handle the execution error
            $response['error'] = true;
            $response['message'] = "Execution Error: " . $stmt->error;
            return false;
        }
    } 
    function updateAppointmentName($pat_id)
    {
        $stmt = $this->con->prepare("UPDATE appointments AS a
                                     JOIN patients AS p ON a.pat_id = p.pat_id
                                     SET a.name = CONCAT(p.firstname, ' ', p.lastname)
                                     WHERE a.pat_id = ?");
        $stmt->bind_param("i", $pat_id);

        return $stmt->execute();
    }
    function createAppointment($doctor_id, $patient_id, $appointment_datetime) {
        $stmt = $this->con->prepare("INSERT INTO appointments (doctor_id, patient_id, appointment_datetime)
                                    VALUES (?, ?, ?)");

        if (!$stmt) {
            return false; // Handle the SQL error as needed
        }

        $stmt->bind_param("iis", $doctor_id, $patient_id, $appointment_datetime);

        if ($stmt->execute()) {
            return true; // Successfully created the appointment
        } else {
            return false; // Handle the execution error as needed
        }
    }
    function createReview($doctor_id, $patient_id, $review_date, $attended, $missed, $improvement) {
        $stmt = $this->con->prepare("INSERT INTO reviews (doctor_id, patient_id, review_date, attended, missed, improvement)
                                    VALUES (?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            return false; // Handle the SQL error as needed
        }

        $stmt->bind_param("iissii", $doctor_id, $patient_id, $review_date, $attended, $missed, $improvement);

        if ($stmt->execute()) {
            return true; // Successfully created the patient review
        } else {
            return false; // Handle the execution error as needed
        }
    }
    function drugs($doctor_id, $patient_id, $review_date, $attended, $missed, $improvement) {
        $stmt = $this->con->prepare("INSERT INTO reviews (doctor_id, patient_id, review_date, attended, missed, improvement)
                                    VALUES (?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            return false; // Handle the SQL error as needed
        }

        $stmt->bind_param("iissii", $doctor_id, $patient_id, $review_date, $attended, $missed, $improvement);

        if ($stmt->execute()) {
            return true; // Successfully created the patient review
        } else {
            return false; // Handle the execution error as needed
        }
    }
    function insertSelectedDate($selectedDate) {
        $stmt = $this->con->prepare("INSERT INTO selected_dates (date) VALUES (?)");

        if (!$stmt) {
            // Handle the SQL error
            $response['error'] = true;
            $response['message'] = "SQL Error: " . $this->con->error;
            return false;
        }

        $stmt->bind_param("s", $selectedDate);

        if ($stmt->execute()) {
            return true;
        } else {
            // Handle the execution error
            $response['error'] = true;
            $response['message'] = "Execution Error: " . $stmt->error;
            return false;
        }
    }

    function getLatestSelectedDate() {
        $sql = "SELECT * FROM selected_dates ORDER BY id DESC LIMIT 1";
        $result = $this->con->query($sql);
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $date_from_sql = $row['date'];
            $formatted_date = date('d-m-Y', strtotime($date_from_sql));
            return $formatted_date;
        } else {
            return "No date selected yet.";
        }
    }
    public function getPatientData($pat_id)
    {
        $stmt = $this->con->prepare("SELECT eye, email, surgerydate FROM patients WHERE pat_id = ?");
        $stmt->bind_param("i", $pat_id);

        if ($stmt->execute()) {
            $stmt->bind_result($eye, $email, $surgerydate);

            if ($stmt->fetch()) {
                $patientData = array(
                    'eye' => $eye,
                    'email' => $email,
                    'surgerydate' => $surgerydate,
                    // Add other fields as needed
                );

                $stmt->close();
                return $patientData;
            }
        }

        $stmt->close();
        return null;
    }

}
?>
