//
//  Constant.swift
//  WeatherApp
//
//  Created by Haris Madhavan on 06/09/23.
//
//
//import Foundation
//import UIKit
//
//public class Constants {
//    var user_id : String? {
//        return UserDefaultsManager.shared.getUserName()
//    }
// 
//    enum serviceType: String {
//        
//        case loginAPI = "http://192.168.140.190/cataract/v1/login.php?"
//        
//        
//        static var ProfileAPI : String {
//            if let user_id = Constants().user_id {
//                return "http://172.20.10.5//manohar/profile.php?user_id=\(user_id)"
//            }
//            else {
//                return ""
//            }
//        }
//    }
//}
