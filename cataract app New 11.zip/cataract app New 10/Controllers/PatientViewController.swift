//
//  PatientViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 14/10/23.
//


import UIKit
import Charts

class PatientViewController: UIViewController, ChartViewDelegate {
    var doc_id = 0
    var pat_id = 0
    var score = 0
    var ph = ""
    var val = 10
    
    
    
    var pat_namev = ""
    var pat_imagev = ""
    var prog1: CGFloat = 0.0
    var prog2: CGFloat = 0.0
    var color : UIColor  = UIColor.cyan

    // Declare prog2 as a Float
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var view5: UIView!
    
    @IBOutlet weak var view7: UIView!
    
    @IBOutlet weak var view6: UIView!
    
    @IBOutlet weak var view8: UIView!
    
    @IBOutlet weak var view9: UIView!
    
    @IBOutlet weak var view10: UIView!
    
    @IBOutlet weak var view12: UIView!
    @IBOutlet weak var view11: UIView!
    
    @IBOutlet weak var view13: UIView!
    
    @IBOutlet weak var view14: UIView!
    
    @IBOutlet weak var view15: UIView!
    
    @IBOutlet weak var pat_image: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var doc_photo: UIImageView!
    
    @IBOutlet weak var pat_name: UILabel!
    @IBOutlet weak var chart1: UIView!
    @IBOutlet weak var progressView2: UIView!
    @IBOutlet weak var progressView: UIView!
    var reminderViewController: ReminderViewController?
    
    var Predforte_eyedropsc = 0
    var Vigamox_eyedropsc = 0
    var Hypersol_eyedropsc = 0
    var Hypersol_ointmentc = 0
    var Nevenac_eyedropsc = 0
    var Pan_40Mgc = 0
    var Diamox_250Mgc = 0
    var Cipro_500Mgc = 0
    var Para_500Mgc = 0
 
   
    var Predforte_eyedrops = 0
    var Vigamox_eyedrops = 0
    var Hypersol_eyedrops = 0
    var Hypersol_ointment = 0
    var Nevenac_eyedrops = 0
    var Pan_40Mg = 0
    var Diamox_250Mg = 0
    var Cipro_500Mg = 0
    var Para_500Mg = 0
 
    var Predforte_eyedrops_total = 1
    var Vigamox_eyedrops_total = 1
    var Hypersol_eyedrops_total = 1
    var Hypersol_ointment_total = 1
    var Nevenac_eyedrops_total = 1
    var Pan_40Mg_total = 1
    var Diamox_250Mg_total = 1
    var Cipro_500Mg_total = 1
    var Para_500Mg_total = 1
 
    @IBOutlet weak var predforteprog: UIProgressView!
    @IBOutlet weak var vigamoxprog: UIProgressView!
    
    @IBOutlet weak var hypersolprog: UIProgressView!
    @IBOutlet weak var hypersolointprog: UIProgressView!
    
    @IBOutlet weak var nevanacprog: UIProgressView!
    
    @IBOutlet weak var panprog: UIProgressView!
    
    @IBOutlet weak var diamoxprog: UIProgressView!
    @IBOutlet weak var ciproprog: UIProgressView!
    @IBOutlet weak var Paraprog: UIProgressView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(pat_id ,"janajnaans ")
        setupShadow(for: view1)
        setupShadow(for: view2)
        setupShadow(for: view3)
        setupShadow(for: view5)
        setupShadow(for: view6)
        setupShadow(for: view7)
        setupShadow(for: view8)
        setupShadow(for: view9)
        setupShadow(for: view10)
        setupShadow(for: view11)
        setupShadow(for: view12)
        setupShadow(for: view13)
        setupShadow(for: view14)
        setupShadow(for: view15)
        
        

        setupShadowbtn(for: btn1)

        
    }
    func setupShadowimg(for view: UIImageView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadow(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowbtn(for btn: UIButton ) {
        btn.layer.shadowColor = UIColor.black.cgColor
        btn.layer.shadowOpacity = 0.5
        btn.layer.shadowOffset = CGSize(width: 0, height: 2)
        btn.layer.shadowRadius = 4
        btn.layer.masksToBounds = false
    }
    let obj = ReminderViewController()
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Change "Main" to your storyboard name
              reminderViewController = storyboard.instantiateViewController(withIdentifier: "ReminderViewController") as? ReminderViewController
        fetchDataFromBackend()
        fetchval()
        date()
        DataManager.shared.patientId = pat_id
        updateUI2()

        self.navigationController?.setNavigationBarHidden(true, animated: false)
        fetchDataForPatID(patID: "\(pat_id)") { drugsTotal in
            // Handle completion
            // You can optionally use the 'drugsTotal' value if needed
            self.fetchDatatotalForPatID(patID: "\(self.pat_id)") { drugsTotal in
                self.updateProgressBars()
            }
        }
    }
    
    func updateProgressBars() {
        DispatchQueue.main.async {
            // Ensure total counts are greater than zero to avoid division by zero
//            self.Predforte_eyedrops_total = 10
//            self.Vigamox_eyedrops_total = 10
//            self.Hypersol_eyedrops_total = 10
//            self.Hypersol_ointment_total = 10
            guard self.Predforte_eyedrops_total > 0 && self.Vigamox_eyedrops_total > 0 && self.Hypersol_eyedrops_total > 0 && self.Hypersol_ointment_total > 0 else {
                print("Total counts should be greater than zero")
                return
            }

            // Calculate progress for Predforte
            let predforteProgress = Float(self.Predforte_eyedropsc) / Float(self.Predforte_eyedrops_total)

            if !predforteProgress.isNaN {
                self.predforteprog.progress = predforteProgress
                print(self.Predforte_eyedropsc , "hhuh")
                print(self.Predforte_eyedrops_total)
                print(predforteProgress ,   "hiijsjs")
            } else {
                print("Invalid progress value for Predforte")
            }

            // Calculate progress for Vigamox
            let vigamoxProgress = Float(self.Vigamox_eyedropsc) / Float(self.Vigamox_eyedrops_total)
            if !vigamoxProgress.isNaN {
                self.vigamoxprog.progress = vigamoxProgress
            } else {
                print("Invalid progress value for Vigamox")
            }

            // Calculate progress for Hypersol
            let hypersolProgress = Float(self.Hypersol_eyedropsc) / Float(self.Hypersol_eyedrops_total)
            if !hypersolProgress.isNaN {
                self.hypersolprog.progress = hypersolProgress
            } else {
                print("Invalid progress value for Hypersol")
            }

            // Calculate progress for Hypersol Ointment
            let hypersolOintProgress = Float(self.Hypersol_ointmentc) / Float(self.Hypersol_ointment_total)
            if !hypersolOintProgress.isNaN {
                self.hypersolointprog.progress = hypersolOintProgress
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            let NevenacProgress = Float(self.Nevenac_eyedropsc) / Float(self.Nevenac_eyedrops_total)
            if !NevenacProgress.isNaN {
                self.nevanacprog.progress = NevenacProgress
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            let Pan = Float(self.Pan_40Mgc) / Float(self.Pan_40Mg_total)
            if !Pan.isNaN {
                self.panprog.progress = Pan
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            let Dia = Float(self.Diamox_250Mgc) / Float(self.Diamox_250Mg_total)
            if !Dia.isNaN {
                self.diamoxprog.progress = Dia
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            let Cipro = Float(self.Cipro_500Mgc) / Float(self.Cipro_500Mg_total)
            if !Cipro.isNaN {
                self.ciproprog.progress = Cipro
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            let para = Float(self.Para_500Mgc) / Float(self.Para_500Mg_total)
            if !para.isNaN {
                self.Paraprog.progress = para
            } else {
                print("Invalid progress value for Hypersol Ointment")
            }
            self.insertProgressData(predforteProgress: predforteProgress,
                                      vigamoxProgress: vigamoxProgress,
                                      hypersolProgress: hypersolProgress,
                                      hypersolOintProgress: hypersolOintProgress,
                                      nevenacProgress: NevenacProgress,
                                      panProgress: Pan,
                                      diamoxProgress: Dia,
                                      ciproProgress: Cipro,
                                      paraProgress: para)
        }
    }
    func insertProgressData(predforteProgress: Float, vigamoxProgress: Float, hypersolProgress: Float, hypersolOintProgress: Float, nevenacProgress: Float, panProgress: Float, diamoxProgress: Float, ciproProgress: Float, paraProgress: Float) {
        // Prepare the request body
        let formData: [String: String] = [
            "pat_id": String(pat_id),
            "Predforte_eyedrops": String(predforteProgress * 100),
            "Vigamox_eyedrops": String(vigamoxProgress * 100),
            "Hypersol_eyedrops": String(hypersolProgress * 100),
            "Hypersol_ointment": String(hypersolOintProgress * 100),
            "Nevenac_eyedrops": String(nevenacProgress * 100),
            "Pan_40Mg": String(panProgress * 100),
            "Diamox_250Mg": String(diamoxProgress * 100),
            "Cipro_500Mg": String(ciproProgress * 100),
            "Para_500Mg": String(paraProgress * 100),
            "Date": DateFormatter().string(from: Date()) // Format date as needed
        ]
        
        // Call APIHandler to insert progress data
        APIHandler().postAPIValues(type: Progress.self, apiUrl: ServiceAPI.progress, method: "POST", formData: formData) { result in
            switch result {
            case .success:
                print("Progress data inserted successfully")
            case .failure(let error):
                print("Error inserting progress data: \(error)")
            }
        }
    }






    // Update the fetchDataForPatID function to decode an array of DrugshomeElement
    func fetchDataForPatID(patID: String, completion: @escaping ([DrugshomeElement]?) -> Void) {
        let formData = [
            "pat_id": patID
        ]
        
        APIHandler().postAPIValues(type: [DrugshomeElement].self, apiUrl: ServiceAPI.drugshome, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if let firstElement = data.first {
                        self.Predforte_eyedropsc = firstElement.predforteEyedrops
                        
                        print(self.Predforte_eyedropsc  , "dldudjn ")
                        self.Vigamox_eyedropsc = firstElement.vigamoxEyedrops
                        self.Hypersol_eyedropsc = firstElement.hypersolEyedrops
                        self.Hypersol_ointmentc = firstElement.hypersolOintment
                        self.Nevenac_eyedropsc = firstElement.nevenacEyedrops
                        self.Pan_40Mgc = firstElement.pan40Mg
                        self.Diamox_250Mgc = firstElement.diamox250Mg
                        self.Cipro_500Mgc = firstElement.cipro500Mg
                        self.Para_500Mgc = firstElement.para500Mg
                        // Assign other variables accordingly
                        self.fetchDatatotalForPatID(patID: patID) { drugsTotal in
                            // Handle completion
                            // You can optionally use the 'drugsTotal' value if needed
                            self.updateProgressBars()
                        }
                    }
                    
                }
                completion(data)
                
            case .failure(let error):
                print("Failed to fetch data:", error.localizedDescription)
                completion(nil)
            }
        }
        

    }



    // Modify the fetchDatatotalForPatID function
    // Modify the fetchDatatotalForPatID function
    // Modify the fetchDatatotalForPatID function
    // Modify the fetchDatatotalForPatID function
    func fetchDatatotalForPatID(patID: String, completion: @escaping (Drugstotal?) -> Void) {
        let formData = [
            "pat_id": "\(self.pat_id)"
        ]
        
        APIHandler().postAPIValues(type: Drugstotal.self, apiUrl: ServiceAPI.drugstotal, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Predforte_eyedrops_total = data.predforteEyedropsTotal
                    print(self.Predforte_eyedrops_total  , "dldud")
                    
                    
                    self.Vigamox_eyedrops_total = data.vigamoxEyedropsTotal
                    
                    self.Hypersol_eyedrops_total = data.hypersolEyedropsTotal
                    self.Hypersol_ointment_total = data.hypersolOintmentTotal
                    self.Nevenac_eyedrops_total = data.nevenacEyedropsTotal
                    self.Pan_40Mg_total = data.pan40MgTotal
                   
                    self.Diamox_250Mg_total = data.diamox250MgTotal
                    self.Cipro_500Mg_total = data.cipro500MgTotal
                    self.Para_500Mg_total = data.para500MgTotal
                    if self.Predforte_eyedrops_total ==  1000 {
                        self.Predforte_eyedropsc = 0
                    }
                    if self.Vigamox_eyedrops_total ==  1000 {
                        self.Vigamox_eyedropsc = 0
                    }
                    if self.Hypersol_eyedrops_total ==  1000 {
                        self.Hypersol_eyedropsc = 0
                    }
                    
                    if self.Hypersol_ointment_total ==  1000 {
                        self.Hypersol_ointmentc = 0
                    }
                    if self.Nevenac_eyedrops_total ==  1000{
                        self.Nevenac_eyedropsc = 0
                    }
                    if self.Pan_40Mg_total ==  1000 {
                        self.Pan_40Mgc = 0
                    }
                    if self.Diamox_250Mg_total ==  1000 {
                        self.Diamox_250Mgc = 0
                    }
                    if self.Cipro_500Mg_total ==  1000 {
                        
                        self.Cipro_500Mgc = 0
                    }
                    if self.Para_500Mg_total == 1000 {
                        self.Para_500Mgc = 0
                    }
                    // Assign other variables accordingly
                }
                completion(data)
                
            case .failure(let error):
                print(error.localizedDescription)
                completion(nil)
            }
        }
     
    }





    func setupProgressViewWithPieChart() {
        // Ensure the container is clear
        progressView.subviews.forEach { $0.removeFromSuperview() }

        // Initialize the pie chart view
        let pieChart = PieChartView()
        progressView.addSubview(pieChart)
        
        // Optionally, disable the legend and entry labels
        pieChart.legend.enabled = false
        pieChart.drawEntryLabelsEnabled = false

        // Setup Pie Chart with 12 equal segments
        let entries = (1...12).map { _ in PieChartDataEntry(value: 1) }
        let dataSet = PieChartDataSet(entries: entries)
        dataSet.colors = ChartColorTemplates.vordiplom() // Customize colors as needed
        dataSet.drawValuesEnabled = false // Hide values on slices
        
        let data = PieChartData(dataSet: dataSet)
        pieChart.data = data
        
        // Custom Progress Bar (a simple UIView for demonstration)
        let progressBar = UIView()
        progressBar.backgroundColor = .clear // Make the background transparent
        progressView.addSubview(progressBar)
        
        // Circular Progress Bar Layer
       
        
        // Layout
        pieChart.translatesAutoresizingMaskIntoConstraints = false
        progressBar.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            pieChart.topAnchor.constraint(equalTo: progressView.topAnchor),
            pieChart.bottomAnchor.constraint(equalTo: progressView.bottomAnchor),
            pieChart.leadingAnchor.constraint(equalTo: progressView.leadingAnchor),
            pieChart.trailingAnchor.constraint(equalTo: progressView.trailingAnchor),
            
            progressBar.topAnchor.constraint(equalTo: progressView.topAnchor),
            progressBar.bottomAnchor.constraint(equalTo: progressView.bottomAnchor),
            progressBar.leadingAnchor.constraint(equalTo: progressView.leadingAnchor),
            progressBar.trailingAnchor.constraint(equalTo: progressView.trailingAnchor),
        ])
        
        // After layout is done, configure the circle path
        
    }

//    func setupProgressAndPieChart() {
//        // Clean up any existing subviews
//        progressView2.subviews.forEach { $0.removeFromSuperview() }
//
//        // Set up tap gesture if needed
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
//        progressView2.addGestureRecognizer(tapGesture)
//        progressView2.isUserInteractionEnabled = true
//        DataManager.shared.patientId = pat_id
//        DataManager.shared.doc_id =  doc_id
//        // Initialize and configure the pie chart
//        let pieChart = PieChartView()
//        pieChart.delegate = self
//        pieChart.drawEntryLabelsEnabled = false
//        pieChart.legend.enabled = false
//        // Add pieChart to progressView
//        progressView2.addSubview(pieChart)
//
//        // Configure the pie chart data
//        var entries = [ChartDataEntry]()
//        let equalValue = 1.0 // Equal value for equal segments
//        for x in 0..<12 {
//            entries.append(ChartDataEntry(x: Double(x), y: equalValue))
//        }
//        let dataSet = PieChartDataSet(entries: entries)
//        dataSet.colors = ChartColorTemplates.colorful() // Or any other color configuration
//        dataSet.drawValuesEnabled = false // Hide values on pie chart
//        let data = PieChartData(dataSet: dataSet)
//        pieChart.data = data
//
//        // Layout pie chart to fit within the progress bar
//        pieChart.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            pieChart.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
//            pieChart.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
//            // Adjust the size of the pie chart to be slightly smaller than the progress bar
//            pieChart.widthAnchor.constraint(equalTo: progressView2.widthAnchor, multiplier: 0.8),
//            pieChart.heightAnchor.constraint(equalTo: progressView2.heightAnchor, multiplier: 0.8),
//        ])
//
//        // Initialize, configure, and add the progress bar
//        let progressBarView2 = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//        progressView2.addSubview(progressBarView2)
//
//        // Customize progressBarView
//        progressBarView2.progressBarColor = color
//
//        // Set the percentage and custom text
//        progressBarView2.setPercentage(self.prog1, customText: "Medication")
//
//        // Position progressBarView within progressView
//        progressBarView2.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            progressBarView2.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
//            progressBarView2.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
//            progressBarView2.widthAnchor.constraint(equalToConstant: 100),
//            progressBarView2.heightAnchor.constraint(equalToConstant: 100)
//        ])
//    }
//
//
//
//
//
//
//    // Ensure to implement the delegate methods for PieChartView if you're using any
//
//    func progressbars(){
//        progressView.subviews.forEach { $0.removeFromSuperview() }
//            progressView2.subviews.forEach { $0.removeFromSuperview() }
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
//        progressView.addGestureRecognizer(tapGesture)
//        progressView.isUserInteractionEnabled = true
//        print(doc_id)
//        print(pat_id)
//        DataManager.shared.patientId = pat_id
//        DataManager.shared.doc_id =  doc_id
//        // Create an instance of PercentageProgressBarView
//        let progressBarView = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//
//                
//        // Customize progressBarView if needed
//        progressBarView.progressBarColor = color
//        
//        // Set the percentage and custom text
//        progressBarView.setPercentage(self.prog1, customText: "Symptoms")
//
// 
//
//        // Add progressBarView as a subview to yourContainerView
//        progressView.addSubview(progressBarView)
//
//
//        // Set constraints to position progressBarView within yourContainerView if needed
//        progressBarView.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            progressBarView.centerXAnchor.constraint(equalTo: progressView.centerXAnchor),
//            progressBarView.centerYAnchor.constraint(equalTo: progressView.centerYAnchor),
//            progressBarView.widthAnchor.constraint(equalToConstant: 100),
//            progressBarView.heightAnchor.constraint(equalToConstant: 100)
//        ])
//        
//
//    }
    func fetchDataFromBackend() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.doc_profile_fetch
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let docIDFormData = "doc_id=\(doc_id)"
        formData.append(docIDFormData.data(using: .utf8)!)
        
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                let docModel = try decoder.decode(docloginmodel.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.updateUI(with: docModel.data)
                }
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
   
    }
    func drugscount(predforteEyedrops: Int , Viga :Int , Hyper :Int , Hyperoin :Int , Nev :Int , pan:Int , dia :Int , cipro :Int , para :Int ) {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.drugscount

        // Prepare form data
        // Prepare form data
        let formData = ["pat_id": "\(self.pat_id)", "Predforte-eyedrops": "\(predforteEyedrops)","Vigamox-eyedrops" : "\(Viga)" , "Hypersol-eyedrops": "\(Hyper)","Hypersol-ointment" : "\(Hyperoin)" , "Nevenac-eyedrops": "\(Nev)","Pan-40Mg" : "\(pan)" , "Diamox-250Mg": "\(dia)","Cipro-500Mg" : "\(cipro)" , "Para-500Mg": "\(para)" ]

        print(Predforte_eyedrops , "hahll")
        // Call APIHandler's postAPIValues method
        APIHandler().postAPIValues(type: Drugscount.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                // Handle success response and parsing if needed
                
                
                print("Success:", data)
                self.fetchDataForPatID(patID: "\(self.pat_id)") { drugsTotal in
                    // Handle completion
                    // You can optionally use the 'drugsTotal' value if needed
                    self.fetchDatatotalForPatID(patID: "\(self.pat_id)") { drugsTotal in
                        self.updateProgressBars()
                    }
                }
            case .failure(let error):
                print("Error:", error)
            }
        }
    }

    func date() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.notificationdate
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let pat_id = "pat_id=\(pat_id)"
        formData.append(pat_id.data(using: .utf8)!)
      
      
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
    }
    

    func updateUI(with data: DataClass) {
        // Update labels with fetched data
        name.text = "Dr."+data.username
        ph = data.qualification
        
        
        // Fetch image from URL
//        if let imageURL = URL(string: ServiceAPI.doc_profile_fetch_image + data.image) {
//            print(imageURL)
//            URLSession.shared.dataTask(with: imageURL) { data, response, error in
//                    guard let data = data, error == nil else { return }
//                    DispatchQueue.main.async() {
//                        self.doc_photo.image = UIImage(data: data)
//                    }
//                }.resume()
//            }
        }
    
    func updateUI2() {
        // Update labels with fetched data
        pat_name.text = "Hi, " + pat_namev
        
        
        
        // Fetch image from URL
        if let imageURL = URL(string: pat_imagev) {
            print(imageURL)
            URLSession.shared.dataTask(with: imageURL) { data, response, error in
                    guard let data = data, error == nil else { return }
                    DispatchQueue.main.async() {
                        self.pat_image.image = UIImage(data: data)
                    }
                }.resume()
            }
        }
    
    
    
    
    
    @IBAction func prefortep(_ sender: Any) {
          Predforte_eyedrops = 0
          Vigamox_eyedrops = 0
          Hypersol_eyedrops = 0
          Hypersol_ointment = 0
          Nevenac_eyedrops = 0
          Pan_40Mg = 0
          Diamox_250Mg = 0
          Cipro_500Mg = 0
         Para_500Mg = 0
     
        print(Predforte_eyedropsc , "juji")
        if Predforte_eyedropsc < Predforte_eyedrops_total{
            Predforte_eyedrops += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
        
    }
    @IBAction func predfortem(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
       Para_500Mg = 0
        print(Predforte_eyedropsc , "juji")
        if Predforte_eyedropsc > 0{
            Predforte_eyedrops -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )        }
    }
    
    @IBAction func vigamoxp(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
       Para_500Mg = 0
      
        if Vigamox_eyedropsc < Vigamox_eyedrops_total{
            Vigamox_eyedrops += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func vigamoxm(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
       Para_500Mg = 0
      
        if Vigamox_eyedropsc > 0{
            Vigamox_eyedrops -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func hypersolp(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Hypersol_eyedropsc < Hypersol_eyedrops_total{
            Hypersol_eyedrops += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    
    @IBAction func hypersolm(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
       Para_500Mg = 0
      
        if Hypersol_eyedropsc > 0{
            Hypersol_eyedrops -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func hyperoinp(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Hypersol_ointmentc < Hypersol_ointment_total{
            Hypersol_ointment += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    
    @IBAction func hyperoinm(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
       Para_500Mg = 0
      
        if Hypersol_ointmentc > 0{
            Hypersol_ointment -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func nevenacp(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Nevenac_eyedropsc < Nevenac_eyedrops_total{
            Nevenac_eyedrops += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func nevenacm(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Nevenac_eyedropsc > 0{
            Nevenac_eyedrops -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    
    @IBAction func panm(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Pan_40Mgc < Pan_40Mg_total{
            Pan_40Mg += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func panp(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Pan_40Mgc > 0{
            Pan_40Mg -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func diap(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Diamox_250Mgc < Diamox_250Mg_total{
            Diamox_250Mg += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    
    @IBAction func diam(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Diamox_250Mgc > 0{
            Diamox_250Mg -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
        
    }
    
    @IBAction func ciprop(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Cipro_500Mgc < Cipro_500Mg_total{
            Cipro_500Mg += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func ciprom(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Cipro_500Mgc > 0{
            Cipro_500Mg -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
        
    }
    
    @IBAction func parap(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Para_500Mgc < Para_500Mg_total{
            Para_500Mg += 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
    }
    @IBAction func param(_ sender: Any) {
        Predforte_eyedrops = 0
        Vigamox_eyedrops = 0
        Hypersol_eyedrops = 0
        Hypersol_ointment = 0
        Nevenac_eyedrops = 0
        Pan_40Mg = 0
        Diamox_250Mg = 0
        Cipro_500Mg = 0
        Para_500Mg = 0
        if Para_500Mgc > 0{
            Para_500Mg -= 1
            
            drugscount(predforteEyedrops: Predforte_eyedrops ,Viga: Vigamox_eyedrops , Hyper: Hypersol_eyedrops, Hyperoin: Hypersol_ointment , Nev: Nevenac_eyedrops, pan: Pan_40Mg , dia: Diamox_250Mg , cipro: Cipro_500Mg, para: Para_500Mg )
        }
        
    }
    
    
    
    
    @IBAction func logout(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)

    }
    @IBAction func appointment(_ sender: UIButton) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "appointmentviewViewController") as! appointmentviewViewController
        destinationVC.doc_id = doc_id
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    @objc func viewTapped() {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "NewsymptomsVc") as! NewsymptomsVc
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    @IBAction func video(_ sender: Any) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "videoViewController") as! videoViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    @IBAction func profile(_ sender: Any) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "PatProfileViewViewController") as! PatProfileViewViewController
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    @IBAction func symptomsprog(_ sender: UIButton) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "NewsymptomsVc") as! NewsymptomsVc
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    func fetchval() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.symptomsprog
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let docIDFormData = "pat_id=\(pat_id)"
        formData.append(docIDFormData.data(using: .utf8)!)
        
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                let docModel = try decoder.decode(Symptomsprog.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.updateUI1(with: docModel.data)
                }
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
    }

    func updateUI1(with data: DataClass4) {
        print(data.val, "hi")
        val = data.val
        if (data.val != 10){
            prog1 = (CGFloat(data.val) / 7.0) * 100.0
        }
        print(prog1)
        
        // Update the progress bar with the new value of prog2
        if data.val == 10  {
           
            color = UIColor.cyan
            prog1 =  5
        }
        else if data.val == 7  {
           
            color = UIColor.red
            
        }
        else if data.val > 5 {
           
            color =  UIColor.red
        }
        else if data.val > 2{
            color =  UIColor.orange
            
        }
        else if data.val > 1 {
            color = UIColor.yellow
        }
        else if data.val > 0 {
            color = UIColor.green
        
        }

        else {
            prog1 = 100
            color = UIColor.black
        }
//        progressbars()
//        setupProgressAndPieChart()
//        setupProgressViewWithPieChart()
    }
    func updateUI2(with data: Clicks) {
        prog2 = CGFloat(data.clicksToMaxTotalRatio)
        prog2 = prog2*100
        
        // Update the progress bar with the new value of prog2
        if prog2 > 100  {
           
            color = UIColor.green
           
        }
        else if prog2 > 70  {
           
            color = UIColor.cyan
            
        }
        else if prog2 > 50 {
           
            color =  UIColor.yellow
        }
        else if prog2 > 20{
            color =  UIColor.orange
            
        }
        else if prog2 > 10 {
            color = UIColor.orange
        }
        else if prog2 > 0 {
            color = UIColor.red
        
        }

        else {
            prog1 = 100
            color = UIColor.black
        }
//        progressbars()
//        setupProgressAndPieChart()
//        setupProgressViewWithPieChart()
    }
    
    @IBAction func whatsp(_ sender: UIButton) {
        let phoneNumber = ph
        
        if let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(phoneNumber)") {
            if UIApplication.shared.canOpenURL(whatsappURL) {
                UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
            } else {
                let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
            }
        }
    }
}
