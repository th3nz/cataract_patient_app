import UIKit

class CaseSheetViewController: UIViewController {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var sx_details2: UILabel!
    @IBOutlet weak var sx_details5: UILabel!
    @IBOutlet weak var sx_details: UILabel!
    @IBOutlet weak var sx_details3: UILabel!
    @IBOutlet weak var eye: UILabel!
    @IBOutlet weak var contact1: UILabel!
    @IBOutlet weak var contact2: UILabel!
    
    @IBOutlet weak var view1: UIView!
    var pat_id = 11
    
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchDataFromBackend()
        setupShadow(for: view1)
    }
    func setupShadow(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func fetchDataFromBackend() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.casesheet
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let docIDFormData = "pat_id=\(pat_id)"
        formData.append(docIDFormData.data(using: .utf8)!)
        
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                let docModel = try decoder.decode(Casesheet.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.updateUI(with: docModel.data)
                }
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
    }

    func updateUI(with data: Casesheet1) {
        // Update labels with fetched data
        name.text = data.firstname + " " + data.lastname
        gender.text = data.gender
        age.text = "\(data.age)"
        sx_details2.text = data.sxDetails2
        sx_details5.text = data.sxDetails5
        sx_details.text = data.sxDetails
        sx_details3.text = data.sxDetails3
        eye.text = data.eye
        contact1.text = "\(data.contact1)"
        contact2.text = "\(data.contact2)"
        // Fetch image from URL
    }
    

}
