import UIKit

class DrugsAddViewController: UIViewController, DropdownViewDelegate {

    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn5: UIButton!
    @IBOutlet weak var btn6: UIButton!

    @IBOutlet weak var BD: UIButton!
    @IBOutlet weak var TID: UIButton!
    @IBOutlet weak var QID: UIButton!
    @IBOutlet weak var Six: UIButton!
    @IBOutlet weak var Eight: UIButton!
    @IBOutlet weak var Hourly: UIButton!

    @IBOutlet weak var Save: UIButton!

    @IBOutlet weak var L: UIButton!
    @IBOutlet weak var R: UIButton!

    @IBOutlet weak var dropdownTextField: UITextField!
    private var dropdownView: DropdownView!

    var t : Float  = 12
    var selectedRadioButton: UIButton?
    var selectedRadioButtonplus: UIButton?
    var pat_id = 0
    var doc_id = 0
    var dropdownvalue: String = ""
    var interval: String = ""
    var interval_minutes: Float = 0 // Added variable to hold calculated interval_minutes
    var interval_minutesint : Int  = 0
    var total = 0
    var eight = 0
    var nine =  0
    var ten = 0
    var eleven = 0
    var twelve = 0
    var thirteen = 0
    var fourteen = 0
    var fifteen = 0
    var sixteen = 0
    var seventeen = 0
    var eighteen = 0
    var nineteen = 0
    var twenty = 0
    
    var number_of_days: Int = 0
    
    var eye: String = ""
    var types : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Sample data for the dropdown
        let dropdownData = [" ", "Predforte-eyedrops", "Vigamox-eyedrops", "Hypersol-eyedrops","Hypersol-ointment", "Nevanac-eyedrops", "Pan-40Mg", "Diamox-250Mg", "Cipro-500Mg", "Para-500Mg"]

        // Create an instance of DropdownView
        dropdownView = DropdownView(data: dropdownData)
        dropdownView.dropdownDelegate = self

        // Set the input view of the text field to the dropdown view
        dropdownTextField.inputView = dropdownView

        // Set up radio buttons
        setupRadioButtons()
        setupRadioButtonsplus()
    }

    func setupRadioButtons() {
        let radioButtons = [btn1, btn2, btn3, btn4, btn5, btn6]

        for radioButton in radioButtons {
            radioButton?.setImage(UIImage(named: "square"), for: .normal)
            radioButton?.setImage(UIImage(named: "check_16"), for: .selected)
            radioButton?.adjustsImageWhenHighlighted = false
            radioButton?.addTarget(self, action: #selector(radioButtonTapped), for: .touchUpInside)
        }
    }

    func setupRadioButtonsplus() {
        let radioButtons = [BD, TID, QID, Six, Eight, Hourly]

        for radioButton in radioButtons {
            radioButton?.setImage(UIImage(named: "square"), for: .normal)
            radioButton?.setImage(UIImage(named: "check_16"), for: .selected)
            radioButton?.adjustsImageWhenHighlighted = false
            radioButton?.addTarget(self, action: #selector(radioButtonTappedplus), for: .touchUpInside)
        }
    }

    @objc func radioButtonTapped(sender: UIButton) {
        selectedRadioButton?.isSelected = false
        sender.isSelected = !sender.isSelected
        selectedRadioButton = sender

        // Call the function to post data to the database
        
    }

    @objc func radioButtonTappedplus(sender: UIButton) {
        selectedRadioButtonplus?.isSelected = false
        sender.isSelected = !sender.isSelected
        selectedRadioButtonplus = sender

        // Calculate interval_minutes when a button is selected
        
        if sender.isSelected {
            switch sender {
              
            case BD:
                interval = "BD"
                interval_minutes = Float(t * 60)
                  eight =  1
    
         

                  twenty =  1
                total = 2
            case TID:
                interval = "TID"
                interval_minutes = Float(t / 3 * 60)
                eight =  1
                
                fourteen =  1
                
                twenty =  1
                total = 3
            case QID:
                interval = "QID"
                interval_minutes = Float(t / 4 * 60)
                eight =  1

                twelve =  1
   
                sixteen =  1
  
                twenty =  1
                total = 4
            case Six:
                interval = "Six Times"
                interval_minutes = Float(t / 6 * 60)
                eight =  1
            
                ten =  1
              
                twelve =  1
     
                fourteen =  1
         
                sixteen =  1
              
                eighteen =  1
              
                total = 6
            case Eight:
                interval = "Eight Times"
                interval_minutes = Float(t / 8 * 60)
                eight =  1
             
                ten =  1
         
                twelve =  1
     
                fourteen =  1
     
                sixteen =  1
          
                eighteen =  1
                
                twenty =  1
                total = 6
            case Hourly:
                interval = "Hourly"
                interval_minutes = Float(t / 12 * 60)
                eight =  1
                nine =   1
                ten =  1
                eleven =  1
                twelve =  1
                thirteen =  1
                fourteen =  1
                fifteen =  1
                sixteen =  1
                seventeen =  1
                eighteen =  1
                nineteen =  1
                twenty =  1
                total = 13
            default:
                break
            }
        }

        // Call the function to post data to the database
        print(interval_minutes)
        print(interval)
       
    }

    @IBAction func L(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            R.isSelected = false
        } else {
            sender.isSelected = true
            R.isSelected = false
        }

        // Call the function to post data to the database
       
    }

    @IBAction func R(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            L.isSelected = false
        } else {
            sender.isSelected = true
            L.isSelected = false
        }

        // Call the function to post data to the database
      
    }

    // MARK: - DropdownViewDelegate

    func didSelectItem(_ item: String) {
        // Handle the selected item
        dropdownTextField.text = item
        dropdownvalue = item
        dropdownTextField.resignFirstResponder()
        // Dismiss the dropdown
        if dropdownvalue == "Predforte-eyedrops" || dropdownvalue == "Vigamox-eyedrops" || dropdownvalue == "Hypersol-eyedrops" ||
            dropdownvalue == "Nevanac-eyedrops" || dropdownvalue == "Hypersol-ointment"{
            types = "topicals"
        }
        else{
            types = "tablets"
        }
    }

    @IBAction func save(_ sender: Any) {
                calculate()
                if interval_minutesint == 0 ||  dropdownvalue == "" || number_of_days == 0 || eye == ""  {
                // Handle case when any field is empty
                
                    let alert = UIAlertController(title: "Error", message: "all fields are required", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                
            } else {
                
                adddrugs()
            }
        }
    
    func calculate() {
        // Continue with the registration process
    
        if btn1.isSelected {
            number_of_days = 1
        } else if btn2.isSelected {
            number_of_days = 3
        } else if btn3.isSelected {
            number_of_days = 5
        } else if btn4.isSelected {
            number_of_days = 7
        } else if btn5.isSelected {
            number_of_days = 10
        } else if btn6.isSelected {
            number_of_days = 14
        } else {
            number_of_days = 0 // Default value or handle accordingly
        }

        self.eye = L.isSelected ? "LE" : "RE"
        self.interval_minutesint =  Int(interval_minutes)
        
        }
    func adddrugs() {
        let formData: [String: String] = [
            "pat_id": "\(pat_id)",
            "number_of_days": "\(number_of_days)",
            "days": "\(number_of_days)",
            "interval_minutes": "\(interval_minutesint)",
            "medication_name": dropdownvalue,
            "eye": eye ,
            "type": types ,
            "intervals": interval ,
            "eight" : "\(eight)",
            "nine" : "\(nine)",
            "ten" : "\(ten)",
            "eleven" : "\(eleven)",
            "twelve" : "\(twelve)",
            "thirteen" : "\(thirteen)",
            "fourteen" : "\(fourteen)",
            "fifteen" : "\(fifteen)",
            "sixteen" : "\(sixteen)",
            "seventeen" : "\(seventeen)",
            "eighteen" : "\(eighteen)",
            "nineteen" : "\(nineteen)",
            "twenty" : "\(twenty)",
            "total" : "\(total)"
            
           
        ]
        print(eight, "lololo")
        APIHandler().postAPIValues(type: adddrugsmodel.self, apiUrl: ServiceAPI.reminder, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.error)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    if response.error {
                        // Error occurred, display error message
                        
                        let alert = UIAlertController(title: "Error", message: response.message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        // Success, navigate to the next view controller
                        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DrugsViewController") as! DrugsViewController
                        nextVC.pat_id = self.pat_id
                        
                        self.navigationController?.pushViewController(nextVC, animated: true)
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                DispatchQueue.main.async {
                    // Display a generic error message in case of a failure
                    let alert = UIAlertController(title: "Error", message: "An error occurred. Please try again later.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                }
            }
        }
    }
}
