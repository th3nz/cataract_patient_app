//
//  DocProfileViewController.swift
//  cataract app
//
//  Created by SAIL on 15/02/24.
//

import UIKit

class DocProfileViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var gender: UITextField!
    
    @IBOutlet weak var qualification: UITextField!
    
    @IBOutlet weak var speciality: UITextField!
    
    
    @IBOutlet weak var doc_photo: UIImageView!
    
    
    var doc_id = 0
    var selectedImages: [UIImage] = []
    var body = Data()
    let imagePicker = UIImagePickerController()
    @IBOutlet weak var scan: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        // Do any additional setup after loading the view.
    }
    @IBAction func register(_ sender: Any) {
        registerUser()
    }
    @IBAction func scanButtonTapped(_ sender: UIButton) {
        showImagePicker()
    }
    func showImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    // MARK: - UIImagePickerControllerDelegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
              selectedImages.append(pickedImage)
              
              // Update the UIImageView with the selected image
              doc_photo.image = pickedImage
          }
          
          picker.dismiss(animated: true, completion: nil)
      }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func registerUser() {
        guard
            let name = name.text, !name.isEmpty,
            let email = email.text, !email.isEmpty,
            let password = password.text, !password.isEmpty,
            let gender = gender.text, !gender.isEmpty,
            let speciality = speciality.text, !speciality.isEmpty,
            let qualification = qualification.text, !qualification.isEmpty
            else {
                
              
                DispatchQueue.main.async {
                    self.showAlert(message: "All fields are mandatory.")
                }
                return
        }
        
        let apiURL = ServiceAPI.doc_profile
        print("API URL:", apiURL)
        
        // Generate a boundary identifier
        let boundary = UUID().uuidString
        
        // Create the request
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        // Create the form data
        var body = Data()
        
        // Add text fields to the form data
        let formData: [String: String] = [
            "doc_id": "\(doc_id)",
            "username": name,
            "email": email,
            "password": password,
            "gender": gender,
            "speciality": speciality,
            "qualification": qualification
        ]
        
        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
            print(value )
        }
        
        // Add images to the form data
        for (index, image) in selectedImages.enumerated() {
                  
                   let fieldName = "image"
                    let fileName = "image\(index).jpg"
                    let imageData = image.jpegData(compressionQuality: 0.8)!
                    print("hi",imageData)
                    body.append("--\(boundary)\r\n".data(using: .utf8)!)
                    body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
                  body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                    body.append(imageData)
                    body.append("\r\n".data(using: .utf8)!)
                }
        
             
             let fieldNames = ["image"]

             for (index, image) in selectedImages.enumerated() {
                 let fieldName = fieldNames[index]
                 
                 let imageData = image.jpegData(compressionQuality: 0.8)!
                 body.append(contentsOf: "--\(boundary)\r\n".utf8)
                 body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
                 body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
                 body.append(contentsOf: imageData)
                 body.append(contentsOf: "\r\n".utf8)
             
                print(image	)
             }
            
        // Add closing boundary
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        // Set the request body
        request.httpBody = body
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Handle the response
            if let data = data {
                // Parse the response data if needed
                print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                
                // You can perform further processing here
                if let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) {
                                // Registration successful
                                DispatchQueue.main.async {
                                    self.navigateToNextPage()
                                }
                            } else {
                                // Registration failed, show an alert with the error message
                                if let errorMessage = String(data: data, encoding: .utf8) {
                                    DispatchQueue.main.async {
                                        self.showAlert(message: errorMessage)
                                    }
                                }
                            }
            }
            
        }
        task.resume()
    }

    func navigateToNextPage() {
//        // Instantiate the view controller you want to navigate to
//        let nextViewController = NextViewController() // Replace NextViewController with your actual view controller
//
        // Push the new view controller onto the navigation stack
        self.navigationController?.popViewController(animated: true)
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

}
