import UIKit

class pendingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var table1: UITableView!
    let cellSpacingHeight: CGFloat = 10
//    static var doc_id = 0
    var appointments: [AppointmentElement] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        table1.delegate = self
        table1.dataSource = self
        fetchDataFromBackend()
    }

    func fetchDataFromBackend() {
        appointments.removeAll()
        print(AppointmentDatadoc.doc_id )
        guard let url = URL(string: ServiceAPI.appointmentdocfetch) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "doc_id=\(AppointmentDatadoc.doc_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                
                print("Error in URLSession data task: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received from the server.")
                return
            }

//            if let dataString = String(data: data, encoding: .utf8) {
//                print("Raw JSON response: \(dataString)")
//            }

            do {
                let decoder = JSONDecoder()
                self.appointments = try decoder.decode([AppointmentElement].self, from: data)

                DispatchQueue.main.async {
                    self.table1.reloadData()
                }
            } catch {
                DispatchQueue.main.async {
                    self.table1.reloadData()
                }
                print("Error decoding JSON: \(error)")
            }
        }.resume()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appointments.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table1.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! pendingTableViewCell
        let appointment = appointments[indexPath.row]

       cell.bookon.text = appointment.currentDate
        cell.bookfor.text = appointment.dateselected
        cell.label.text = appointment.name
        cell.time.text = appointment.times

        // Assume checkboxBtn is a UIButton in your cell
        cell.checkboxBtn.isSelected = false // Set the initial state

        cell.checkboxAction = { [weak self] in
            guard let self = self else { return }
            // Handle checkbox action here
            print("Checkbox tapped for appointment \(appointment.name)")
            self.updateStatusForSelectedAppointment(appointment)
        }

        cell.selectionStyle = .none

        return cell
    }

    // Function to update the status to "accepted" for the selected appointment
    func updateStatusForSelectedAppointment(_ appointment: AppointmentElement){
        guard let url = URL(string: ServiceAPI.updatestatus) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "id=\(appointment.id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching patients: \(error.localizedDescription)")
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                print("Unexpected response status code")
                return
            }

            
        }.resume()
    }
//    {
//            // Call your backend API to update the status to "accepted" for the selected appointment
//            // Use appointment.id or other unique identifier to identify the appointment
//
//            // Placeholder: Replace the following with your actual backend API call
//        print(appointment.name)
//        guard let updateURL = URL(string: ServiceAPI.updatestatus) else {
//                return
//            }
//
//            var request = URLRequest(url: updateURL)
//            request.httpMethod = "POST"
//            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//            print(appointment.id)
//        let id = appointment.id
//            let updateData: [String: String] = ["id": "\(id)"]
//
//            do {
//                request.httpBody = try JSONSerialization.data(withJSONObject: updateData)
//            } catch {
//                print("Error encoding JSON: \(error)")
//                return
//            }
//
//            URLSession.shared.dataTask(with: request) { data, response, error in
//                if let error = error {
//                            print("Error updating status: \(error)")
//                        } else if let data = data {
//                            do {
//                                let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
//                                if let message = jsonResponse?["message"] as? String {
//                                    print("Server response: \(message)")
//                                }
//                            } catch {
//                                print("Error decoding JSON response: \(error)")
//                            }
//                        }
//            }.resume()
//        }

    // ... other UITableViewDataSource and UITableViewDelegate methods
}
