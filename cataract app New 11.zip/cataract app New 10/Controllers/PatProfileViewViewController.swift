//
//  PatProfileViewViewController.swift
//  cataract app
//
//  Created by SAIL on 13/03/24.
//

import UIKit

class PatProfileViewViewController: UIViewController {
    var pat_id = 0
    
    
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var pat_photo: UIImageView!
    @IBOutlet weak var contact2: UILabel!
    @IBOutlet weak var contact1: UILabel!
  
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var email: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        fetchDataFromBackend()
       
        
    }
    
    
    func fetchDataFromBackend() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.pat_profile_fetch
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let docIDFormData = "pat_id=\(pat_id)"
        formData.append(docIDFormData.data(using: .utf8)!)
        
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                let docModel = try decoder.decode(Patprofile.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.updateUI(with: docModel.data)
                }
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
    }

    func updateUI(with data: DataClassthree) {
        // Update labels with fetched data
        name.text = data.firstname + data.lastname
        email.text = data.email
        gender.text = data.gender
        contact1.text = "\(data .contact1)"
        contact2.text =  "\(data .contact2)"
        
        // Fetch image from URL
        if let imageURL = URL(string: ServiceAPI.doc_profile_fetch_image + data.image) {
            print(imageURL)
            URLSession.shared.dataTask(with: imageURL) { data, response, error in
                    guard let data = data, error == nil else { return }
                    DispatchQueue.main.async() {
                        self.pat_photo.image = UIImage(data: data)
                    }
                }.resume()
            }
        }
    
    @IBAction func edit(_ sender: Any) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "PatProfileViewController") as! PatProfileViewController
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)

    }
    
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
