import UIKit

class patient1: UIViewController {

    @IBOutlet weak var btn5: UIButton!
    @IBOutlet weak var BTN4: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var pagedesign1: UIView!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var pagedesign: UIView!

    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var symptom: UILabel!
    
    var symptoms = ""
    var name = ""
    var images = ""
    var pat_id = 0
    var patientprofile: Patientprofile?
    

    override func viewDidLoad() {
          super.viewDidLoad()
          
          let imagess = ServiceAPI.galleryurl + images
          label.text = name
          print(imagess) // Print the image URL for debugging
          
          guard let imageURL = URL(string: imagess) else {
              print("Invalid image URL: \(imagess)")
              return
          }
          
          // Fetch image data from the URL
          URLSession.shared.dataTask(with: imageURL) { [weak self] (data, response, error) in
              guard let self = self, let data = data, error == nil else {
                  print("Error fetching image: \(error?.localizedDescription ?? "Unknown error")")
                  return
              }
              
              // Update UI on the main thread
              DispatchQueue.main.async {
                  if let downloadedImage = UIImage(data: data) {
                      self.image.image = downloadedImage
                  } else {
                      print("Failed to create UIImage from image data.")
                  }
              }
          }.resume()

          // Fetch patient profile data from the API using pat_id
          fetchDataFromAPI()
        fetchSymptomsFromAPI()
        setupShadow(for: pagedesign1)
        setupShadowbtn(for: button1)
        setupShadowbtn(for: button2)
        setupShadowbtn(for: button3)
        setupShadowbtn(for: BTN4)
        setupShadowbtn(for: btn5)
        setupShadow(for: pagedesign )
      }
    func setupShadowimg(for view: UIImageView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadow(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowbtn(for btn: UIButton ) {
        btn.layer.shadowColor = UIColor.black.cgColor
        btn.layer.shadowOpacity = 0.5
        btn.layer.shadowOffset = CGSize(width: 0, height: 2)
        btn.layer.shadowRadius = 4
        btn.layer.masksToBounds = false
    }
    func fetchSymptomsFromAPI() {
        // URL for the PHP script to fetch symptoms
        let phpURL = ServiceAPI.symptomsfetch
        
        // Create URLRequest
        var request = URLRequest(url: URL(string: phpURL)!)
        request.httpMethod = "POST"
        
        // Construct the HTTP body
        let postData = "pat_id=\(pat_id)".data(using: .utf8)
        request.httpBody = postData
        
        // Perform URLSession data task
        URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
            guard let self = self, let data = data else { return }
            
            do {
                // Decode JSON response
                let decoder = JSONDecoder()
                let symptomsData = try decoder.decode(Symptoms.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    // Set symptoms string to a label or use it as needed
                    self.symptom.text = symptomsData.symptoms
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }.resume()
    }

      func fetchDataFromAPI() {
          // Replace this URL with your actual API endpoint
          guard let url = URL(string: ServiceAPI.patientprofile) else { return }
          var request = URLRequest(url: url)
          request.httpMethod = "POST"
          request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

          // Append the pat_id to the URL
          let postString = "pat_id=\(pat_id)"
          request.httpBody = postString.data(using: .utf8)

          URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
              guard let self = self, let data = data else { return }

              do {
                  let decoder = JSONDecoder()
                  self.patientprofile = try decoder.decode(Patientprofile.self, from: data)

                  // Update UI on the main thread
                  DispatchQueue.main.async {
                      self.updateUI()
                  }

              } catch {
                  print("Error decoding JSON: \(error)")
              }
          }.resume()
      }

      func updateUI() {
          // Check if patientprofile is not nil and contains the required information
          if let patientProfile = patientprofile {
              label1.text = patientProfile.eye
              label2.text = patientProfile.email
              label3.text = patientProfile.surgerydate
          } else {
              // Handle the case where patientprofile is nil or doesn't contain the expected information
              print("Patient profile data not available.")
          }
      }
      
    @IBAction func progress(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "progressViewController") as! progressViewController
        vc.pat_id = pat_id
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func review(_ sender: Any) {
          let vc = self.storyboard?.instantiateViewController(withIdentifier: "ReviewViewController") as! ReviewViewController
          vc.pat_id = pat_id
          self.navigationController?.pushViewController(vc, animated: true)
      }
      
    @IBAction func casesheet(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CaseSheetViewController") as! CaseSheetViewController
        vc.pat_id = pat_id
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func gallery(_ sender: Any) {
          let vc = self.storyboard?.instantiateViewController(withIdentifier: "GalleryViewController") as! GalleryViewController
          vc.pat_id = pat_id
          self.navigationController?.pushViewController(vc, animated: true)
      }
      
      @IBAction func drugs(_ sender: UIButton) {
          let vc = self.storyboard?.instantiateViewController(withIdentifier: "DrugsViewController") as! DrugsViewController
          vc.pat_id = pat_id
          self.navigationController?.pushViewController(vc, animated: true)
      }
  }
