
import UIKit

class ReviewViewController: UIViewController {
    var pat_id = 0
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var saveimprovement: UIButton!
    @IBOutlet weak var datepicker: UIDatePicker!
    var dates: [String] = []
    var fetchImprovements: [String] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setupDatePicker()
        fetchimprovements()
        fetchDatesFromBackend()// Fetch data when the view loads
        setupShadowbtn(for: save)
        setupShadowbtn(for: saveimprovement)
        setupShadowdate(for: datepicker)
        setupShadowtable(for: tableview)
    }
    func setupShadowimg(for view: UIImageView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowtable(for view: UITableView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowdate(for view: UIDatePicker ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadow(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowbtn(for btn: UIButton ) {
        btn.layer.shadowColor = UIColor.black.cgColor
        btn.layer.shadowOpacity = 0.5
        btn.layer.shadowOffset = CGSize(width: 0, height: 2)
        btn.layer.shadowRadius = 4
        btn.layer.masksToBounds = false
    }

    func setupDatePicker() {
        datepicker.minimumDate = Date()
        datepicker.datePickerMode = .date
        datepicker.timeZone = .current
    }

    @IBAction func saveButtonTapped(_ sender: UIButton) {
        let selectedDate = datepicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.string(from: selectedDate)

        sendDataToBackend(selectedDate: formattedDate) { [weak self] in
            // Fetch data from the backend after saving is completed
            self?.fetchDatesFromBackend()
        }
    }

    @IBAction func saveImprovementButtonTapped(_ sender: UIButton) {
        // Get the selected improvement value from the cell
        guard let selectedIndexPath = tableview.indexPathForSelectedRow else {
            let emptyFieldsAlert = UIAlertController(title: "Error", message: "Click on the Specific Date.", preferredStyle: .alert)
            emptyFieldsAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(emptyFieldsAlert, animated: true)
            return
        }

        let selectedDate = dates[selectedIndexPath.row]

        // Get the selected improvement value from the cell
        guard let selectedImprovement = (tableview.cellForRow(at: selectedIndexPath) as? ReviewTableViewCell)?.improvement.text else {
            print("No improvement value selected.")
            return
        }

        // Send the selected improvement value and date to the backend
        sendImprovementToBackend(selectedDate: selectedDate, improvement: selectedImprovement)
    }

    func sendDataToBackend(selectedDate: String, completion: @escaping () -> Void) {
        guard let url = URL(string: ServiceAPI.addreview) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)&date=\(selectedDate)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error sending data to backend: \(error)")
                return
            }
            

            print("Data sent successfully to backend")
            // You may handle the response from the PHP backend if needed

            // Call the completion block to fetch data after saving
            completion()

        }.resume()
    }
    func fetchDatesFromBackend() {
        guard let url = URL(string: ServiceAPI.fetchdates) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.dates = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched dates count: \(self.dates.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

    
    func fetchimprovements() {
        guard let url = URL(string: ServiceAPI.fetchimprovement) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching improvement data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.fetchImprovements = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched improvements count: \(self.fetchImprovements.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    
    }
    func sendImprovementToBackend(selectedDate: String, improvement: String) {
        guard let url = URL(string: ServiceAPI.addimprovement) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)&date=\(selectedDate)&improvement=\(improvement)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error sending improvement to backend: \(error)")
                return
            }
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Success", message: "Data inserted successfully.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                    // Pop the view controller when OK button is clicked
                    self.navigationController?.popViewController(animated: true)
                })
                self.present(alert, animated: true, completion: nil)
            }
            print("Improvement sent successfully to backend")
            // You may handle the response from the PHP backend if needed

        }.resume()
    }
}

extension ReviewViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return max(dates.count,fetchImprovements.count)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 50.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ReviewTableViewCell

            // Configure the cell with the fetched date
            if indexPath.row < dates.count {
                let date = dates[indexPath.row]
                cell.dates.text = date
            } else {
                cell.dates.text = "Date not available"
            }

            // Configure the cell with the fetched improvement
            if indexPath.row < fetchImprovements.count {
                let improvement = fetchImprovements[indexPath.row]
                cell.selectedimprovement.text = improvement
            } else {
                cell.selectedimprovement.text = "Improvement data not available"
            }

            return cell
        }
}


