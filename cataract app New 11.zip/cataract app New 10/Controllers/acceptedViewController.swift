//
//  acceptedViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 29/12/23.
//

import UIKit

class acceptedViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
//    static var doc_id = 0
//    var pat_id = 11
    
    var dates: [String] = []
    var fetchImprovements: [String] = []
    var names: [String] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDatesFromBackend()
        fetchimprovements()
        fetchNamesFromBackend()
    }
    func fetchNamesFromBackend() {
        guard let url = URL(string: ServiceAPI.appointmentacceptednames) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "doc_id=\(AppointmentDatadoc.doc_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching improvement data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.names = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched improvements count: \(self.names.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

    func fetchDatesFromBackend() {
        dates.removeAll()
        guard let url = URL(string: ServiceAPI.appointmentaccepteddates) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
      
        print("hi",AppointmentDatadoc.doc_id)
        let postString = "doc_id=\(AppointmentDatadoc.doc_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.dates = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched dates count: \(self.dates.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

    
    func fetchimprovements() {
        guard let url = URL(string: ServiceAPI.appointmentacceptedstatus) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "doc_id=\(AppointmentDatadoc.doc_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching improvement data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.fetchImprovements = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched improvements count: \(self.fetchImprovements.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }


}

extension acceptedViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return max(dates.count, fetchImprovements.count,
                   names.count)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! acceptedTableViewCell

        // Configure the cell with the fetched date
        if indexPath.row < dates.count {
            let date = dates[indexPath.row]
            cell.dates.text = date
        } else {
            cell.dates.text = "Date not available"
        }

        // Configure the cell with the fetched improvement
        if indexPath.row < fetchImprovements.count {
            let improvement = fetchImprovements[indexPath.row]
            cell.status.text = improvement
        } else {
            cell.status.text = "Accepted"
        }
        if indexPath.row < names.count {
            let name = names[indexPath.row]
            cell.names.text = name
        } else {
            cell.names.text = "No Name"
        }

        return cell
    }
}

