//
//  appointmentviewViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 22/12/23.
//

import UIKit

class appointmentviewViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    var doc_id = 0
    var pat_id = 0
    var dates: [String] = []
    var fetchImprovements1: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        fetchDatesFromBackend()
        fetchImprovements()
        print(pat_id ,"aaja an")
        print(doc_id)
        
    }

    func fetchDatesFromBackend() {
        guard let url = URL(string: ServiceAPI.fetchdateselected) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.dates = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched dates count: \(self.dates.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

    func fetchImprovements() {
        guard let url = URL(string: ServiceAPI.fetchstatus) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching improvement data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.fetchImprovements1 = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched improvements count: \(self.fetchImprovements1.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }
    
    @IBAction func Book(_ sender: UIButton) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "appointmentaddViewController") as! appointmentaddViewController
        destinationVC.doc_id = doc_id
        destinationVC.pat_id = pat_id
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }

}

extension appointmentviewViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return max(dates.count, fetchImprovements1.count)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! appointmentviewTableViewCell

        // Configure the cell with the fetched date
        if indexPath.row < dates.count {
            let date = dates[indexPath.row]
            cell.dates.text = date
        } else {
            cell.dates.text = "Date not available"
        }

        // Configure the cell with the fetched improvement
        if indexPath.row < fetchImprovements1.count {
            let improvement = fetchImprovements1[indexPath.row]
            cell.status.text = improvement
        } else {
            cell.status.text = "no status"
        }

        return cell
    }
}
