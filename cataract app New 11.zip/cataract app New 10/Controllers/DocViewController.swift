import UIKit

class DocViewController: BasicViewController {
    


    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    var apiURL = String()
        var logInDetails : docloginmodel!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Remove unnecessary commented-out code
             self.email.addBottomBorderWithColor(color: .gray, width: 0.5)
             self.password.addBottomBorderWithColor(color: .gray, width: 0.5)
        }
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
     
            self.navigationController?.setNavigationBarHidden(false, animated: false)
        }

        @IBAction func onlogin(_ sender: Any) {
            apiURL = "\(ServiceAPI.loginURL)?username=\(email.text  ?? "")&password=\(password.text ?? "")"
            
            if email.text == "" && password.text == "" {
                let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                present(alert, animated: true)
            } else {
                getLoginAPI()
            }
            loadData()
        }
    
     func loadData() {
          // Show the loading indicator
          LoadingIndicator.shared.showLoading(on: view)

          // Simulate data loading with a delay
          DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
              // Hide the loading indicator when data is loaded
              LoadingIndicator.shared.hideLoading()

              // Now you can proceed with displaying your data or updating the UI
              // Example: self.displayData()
          }
      }

        


        func getLoginAPI() {
            
         
            let formData = [
                      "email": email.text ?? "",
                      "password": password.text ?? ""
                  ]
            APIHandler().postAPIValues(type: docloginmodel.self, apiUrl: apiURL, method: "POST", formData:formData) { result in
                switch result {
                case .success(let data):
                    self.logInDetails = data
                    print(self.logInDetails.data )
                    DispatchQueue.main.async {
                        if self.email.text != self.logInDetails.data.email && self.password.text != self.logInDetails.data.password {
    //                        let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: UIAlertController.Style.alert)
    //                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
    //
    //                        self.present(alert, animated: true)
    //
                            let alert = UIAlertController(title: "OOPS", message: "Incorrect User ID & password", preferredStyle: .alert)
                                                alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                                                    print("Incorrect User ID & password")
                                                })
                            
                        }
                        else {
//                            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
//
//                            let vc = storyboard.instantiateViewController(withIdentifier: "PatientList") as!PatientViewController
//                            self.navigationController?.pushViewController(vc, animated: true)
//
//                            if let tabBarController = self.view.window?.rootViewController as? UITabBarController,
                         let doctor_id = self.logInDetails.data.docID
//                            let doc_name = self.logInDetails.data.username

                                                // Pass userID to the next view controller
                            
                            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                            let vc = storyboard.instantiateViewController(withIdentifier: "PatientList") as! PatientList
                            vc.doctor_id = doctor_id
                            
                            print(doctor_id)
//                            vc.doc_name = doc_name
                            self.navigationController?.pushViewController(vc, animated: true)
                            //{
//
//                                  // Perform the navigation
//                                  tabBarController.selectedViewController = destinationVC
//                              }
                        }
                    }
                case .failure(let error):
                            print(error.localizedDescription) // Print the error for debugging
                            DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                    self.present(alert, animated: true)
                                }
                }
            }
        
        }
    
    
    
    @IBAction func backBuutonTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    }






    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


