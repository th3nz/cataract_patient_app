import UIKit

class SymptomsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  

    @IBOutlet weak var table1: UITableView!
    
    
    
    let cellSpacingHeight: CGFloat = 10
    
    
    
    
    var symptoms: [Symptom] = [
        Symptom(name: "Headache", image: "360_F_282129985_4pPu8qWD4C5eSeQNdrPVQAT4df9ZPGeJ-removebg-preview", isSelected: false),
        Symptom(name: "Redness", image: "cartoon-child-with-pink-eye-removebg-preview", isSelected: false),
        	
        Symptom(name: "Eye Duscharge", image: "illustration-of-watery-and-itchy-red-dry-eye-2BK74JE-transformed-removebg-preview", isSelected: false),
        Symptom(name: "Floaters", image: "png-transparent-human-eye-floater-iritis-uveitis-eye-people-symptom-human-eye-removebg-preview", isSelected: false),
        Symptom(name: "Flashes", image: "eyefloaterFlash-17-HHB-3519-770x553-removebg-preview", isSelected: false),
        Symptom(name: "Nausea", image: "images__3_-removebg-preview", isSelected: false),
        Symptom(name: "Watering", image: "126263271-guy-in-tears-symptom-of-flu-or-cold-male-character-with-watery-eyes-sad-man-flat-vector-removebg-preview", isSelected: false)
    ]

    // ... other properties

    struct Symptom {
        var name: String
        var image: String
        var isSelected: Bool
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        table1.delegate = self
        table1.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return symptoms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table1.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SymptomsTableViewCell
        let symptom = symptoms[indexPath.row]

        cell.profileImahe.image = UIImage(named: symptom.image)
        cell.label.text = symptom.name
        cell.checkboxBtn.isSelected = symptom.isSelected
        cell.selectionStyle = .none

        cell.checkboxAction = { [weak self] in
            guard let self = self else { return }
            self.symptoms[indexPath.row].isSelected.toggle()
            tableView.reloadData()
            // You can add code here to handle the selection change
        }

        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    @IBAction func done(_ sender: UIButton) {
        
        self.navigationController?.popViewController( animated: true)
    }
}
