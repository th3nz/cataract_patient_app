//
//  ViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 05/10/23.
//

/*import UIKit
class ViewController: UIViewController , UICalendarSelectionMultiDateDelegate {

    override func viewDidLoad() {
    super.viewDidLoad()
    let calendarView = UICalendarView (frame: UIScreen.main.bounds)
    let greCalendar = Calendar (identifier: .gregorian)
    let selection = UICalendarSelectionMultiDate (delegate: self)
    calendarView.selectionBehavior = selection
    calendarView.calendar = greCAlendar
    calendarView.tintColor = .red
    self.view.addSubview (calendarView)
    // Do any additional setup after loading the view.
}
func multiDateSelection (_ election: UICalendarSelectionMultiDate, did Select Date
dateComponents: DateComponents) {
print (dateComponents)
}
func multiDateSelection (_ selection: UICalendarSelection MultiDate, didDeselect Date
dateComponents: DateComponents) {
print (dateComponents)
}
*/
