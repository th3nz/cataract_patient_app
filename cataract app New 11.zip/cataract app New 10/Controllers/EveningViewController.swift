//
//  EveningViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 22/12/23.
//

import UIKit

class EveningViewController: UIViewController {
    static var doc_id = 0
    static var pat_id = 0
    static var dateselected: Date?

    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn5: UIButton!
    @IBOutlet weak var btn6: UIButton!

    var selectedRadioButton: UIButton?
    var times = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        setupRadioButtons()
        setupShadowbtn(for: btn1)
        setupShadowbtn(for: btn2)
        setupShadowbtn(for: btn3)
        setupShadowbtn(for: btn4)
        setupShadowbtn(for: btn5)
        setupShadowbtn(for: btn6)
        setupShadowbtn(for: save)
        
        

    }
    func setupShadowbtn(for view: UIButton ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupRadioButtons() {
        let radioButtons = [btn1, btn2, btn3, btn4, btn5, btn6]

        for radioButton in radioButtons {
            radioButton?.addTarget(self, action: #selector(radioButtonTapped), for: .touchUpInside)
        }
    }

    @objc func radioButtonTapped(sender: UIButton) {
        selectedRadioButton?.isSelected = false
        sender.isSelected = !sender.isSelected
        selectedRadioButton = sender
    }

    func calculate() {
        if btn1.isSelected {
            times = 1
        } else if btn2.isSelected {
            times = 3
        } else if btn3.isSelected {
            times = 5
        } else if btn4.isSelected {
            times = 7
        } else if btn5.isSelected {
            times = 10
        } else if btn6.isSelected {
            times = 14
        } else {
            times = 0
        }
    }

    @IBAction func save(sender: UIButton) {
        calculate()
        sendDataToBackend()
//        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "appointmentviewViewController") as! appointmentviewViewController
//        nextVC.pat_id = AppointmentData.pat_id
//
        self.navigationController?.popViewController( animated: true)

    }

    func sendDataToBackend() {
        guard let url = URL(string: ServiceAPI.appointment) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"

        let formattedDate: String
        if let dateselected = AppointmentData.dateselected {
            formattedDate = dateFormatter.string(from: dateselected)
        } else {
            formattedDate = dateFormatter.string(from: Date())
        }

        let postString = "pat_id=\(AppointmentData.pat_id)&doc_id=\(AppointmentData.doc_id)&dateselected=\(formattedDate)&times=\(times)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error sending data to backend: \(error)")
                return
            }

            print("Data sent successfully to backend")
            print(AppointmentData.pat_id)
            print(formattedDate)
        }.resume()
    }
}
