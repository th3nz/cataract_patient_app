//
//  tablecollapseViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 16/11/23.
//

/*import UIKit

class tablecollapseViewController: UIViewController {


   
    var imageArr = ["image1","image2", "image3", "image4", "image5","image6"]
    var nameArr = ["Image 1", "Image 2","Image 3", "Image 4","Image 5","Image 6"]
    var SelectedIndex = -1
    var isCollapce = false
    override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    tblTableView.estimatedRowHeight = 243
    tblTableView.rowHeight = UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if self.SelectedIndex == indexPath.row && isCollapce == true
    {
    return 243
    }else
    {
    return 50
    }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return nameArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "tablecollapseViewController") as! tablecollapseViewController
    cell.lblName.text! = nameArr[indexPath.row]
    cell.imgImage.image = UIImage (named: "\(imageArr[indexPath.row])")
        return cell
        }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
    if SelectedIndex == indexPath.row
    {
    if self.isCollapce == false
    {
    self.isCollapce = true
    }else
    {
    self.isCollapce = false
    }
    }else
    {
    self.isCollapce = true
    }
    self.SelectedIndex = indexPath.row
    tableView.reloadRows (at: [indexPath], with: .automatic)
    }
    }

        
        

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
*/
