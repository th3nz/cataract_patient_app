import UIKit

class TabbarViewController: UITabBarController, UITabBarControllerDelegate {

    var doc_id = 0
    var pat_id = 0
    var image = ""
    var name = ""
      
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self

        // Pass values to each view controller in the tab bar
        if let viewControllers = self.viewControllers {
            for viewController in viewControllers {
                if let destinationVC = viewController as? PatientViewController {
                    // Replace YourViewControllerType with the actual type of your view controller
                    destinationVC.doc_id = doc_id
                    destinationVC.pat_id = pat_id
                    destinationVC.pat_imagev = ServiceAPI.doc_profile_fetch_image + image
                    destinationVC.pat_namev = name
                }
            }
        }
        if let viewControllers = self.viewControllers {
            for viewController in viewControllers {
                if let destinationVC = viewController as? reviewpatViewController {
                    // Replace YourViewControllerType with the actual type of your view controller
                    destinationVC.doc_id = doc_id
                    destinationVC.pat_id = pat_id
                }
            }
        }
        if let viewControllers = self.viewControllers {
            for viewController in viewControllers {
                if let destinationVC = viewController as? documentsViewController {
                    // Replace YourViewControllerType with the actual type of your view controller
                    destinationVC.doc_id = doc_id
                    destinationVC.pat_id = pat_id
                }
            }
        }
    }

    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        // You can also handle additional actions when a tab is selected
    }
}
