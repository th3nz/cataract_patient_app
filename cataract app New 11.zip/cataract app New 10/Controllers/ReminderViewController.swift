import UIKit
import UserNotifications

struct NotificationTime {
    let hour: Int
    let minute: Int
    let day: String

    var description: String {
        return String(format: "%02d:%02d %@", hour, minute, day)
    }
}

protocol ReminderViewControllerDelegate: AnyObject {
    func remindersFetched(notificationTimes: [NotificationTime])
}

class ReminderViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UNUserNotificationCenterDelegate {

    @IBOutlet weak var tableView: UITableView!

    var reminders = [NotificationElement]()
    var medicationNamesByTimeSlot = [String: [String]]()
    var medicationSections: [MedicationSection] = []
    var pat_id = 0
    var notificationTimes: [NotificationTime] = []
    var overAllTime = [SendNotification]()
//    var notificationClickCountKey = "NotificationClickCount"
    var lastResetDateKey = "LastResetDate"
    weak var delegate: ReminderViewControllerDelegate?

    override func viewDidLoad() {
        
        super.viewDidLoad()
        

        tableView.dataSource = self
        tableView.delegate = self
        pat_id = DataManager.shared.patientId // Example patient ID
        print(pat_id, "uahau ")

        let cellNib = UINib(nibName: "ReminderCell", bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: "ReminderCell")

        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] (granted, error) in
            guard let self = self else { return }
            if granted {
                print("Notification authorization granted")
                UNUserNotificationCenter.current().delegate = self
                self.fetchReminders()
            } else {
                print("Notification authorization denied")
            }
        }
    }

    func fetchReminders() {
        guard let url = URL(string: ServiceAPI.notification + "pat_id=\(pat_id)") else {
            print("Invalid URL")
            return
        }

        let apiUrlString = ServiceAPI.notification + "pat_id=\(pat_id)"
        let formData = ["pat_id": "\(pat_id)"]

        APIHandler().postAPIValues(type: [NotificationElement].self, apiUrl: apiUrlString, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }

            switch result {
            case .success(let reminders):
                self.reminders = reminders
                self.populateMedicationNamesByTimeSlot()

                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print("Error fetching reminders:", error)
            }
        }
    }


    func populateMedicationNamesByTimeSlot() {
        medicationNamesByTimeSlot.removeAll()

        for reminder in reminders {
//            let timeSlots = [reminder.the8, reminder.the9, reminder.the10, reminder.the11, reminder.the12,
//                             reminder.the13, reminder.the14, reminder.the15, reminder.the16, reminder.the17,
//                             reminder.the18, reminder.the19]
            let timeSlots = [reminder.eight, reminder.nine, reminder.ten, reminder.eleven, reminder.twelve,
                             reminder.thirteen, reminder.fourteen, reminder.fifteen, reminder.sixteen, reminder.seventeen,
                             reminder.eighteen, reminder.nineteen]
            for (index, timeSlot) in timeSlots.enumerated() {
                if timeSlot == "1" {

                    var hour = index + 8
                    let minute = 0 // Adjust the minute value as needed
                    var day = "AM"

                    if hour >= 12 {
                        day = "PM"
                        if hour > 12 {
                            hour -= 12
                        }
                    }
                    let notificationTime = NotificationTime(hour: hour, minute: minute, day: day)
                    notificationTimes.append(notificationTime)

                    let time = String(format: "%02d:%02d %@", hour, minute, day)
                    if var medicationNames = medicationNamesByTimeSlot[time] {
                        medicationNames.append(reminder.medicationName)
                        medicationNamesByTimeSlot[time] = medicationNames
                    } else {
                        medicationNamesByTimeSlot[time] = [reminder.medicationName]
                    }
                }
            }
        }

        medicationSections = medicationNamesByTimeSlot.map { MedicationSection(timeSlot: $0.key, medicationNames: $0.value) }
        medicationSections.sort { (section1, section2) -> Bool in
            if section1.timeSlot.contains("AM") && section2.timeSlot.contains("PM") {
                return true
            } else if section1.timeSlot.contains("PM") && section2.timeSlot.contains("AM") {
                return false
            } else {
                return section1.timeSlot < section2.timeSlot
            }
        }
        self.scheduleNotifications()
    }


    func scheduleNotifications() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"

        // Get all pending notification requests
        UNUserNotificationCenter.current().getPendingNotificationRequests { [weak self] requests in
            guard let self = self else { return }

            // Extract the identifiers of pending requests for the times available in the database
            let validIdentifiers = self.medicationNamesByTimeSlot.keys.map { time in
                return requests.filter { request in
                    guard let trigger = request.trigger as? UNCalendarNotificationTrigger else {
                        return false
                    }
                    let dateComponents = trigger.dateComponents
                    let requestTime = String(format: "%02d:%02d %@", dateComponents.hour ?? 0, dateComponents.minute ?? 0, dateComponents.hour ?? 0 >= 12 ? "PM" : "AM")

                    return requestTime == time
                }.compactMap { $0.identifier }
            }.flatMap { $0 }

            // Remove pending requests for times that are no longer available in the database
            let invalidIdentifiers = requests.map { $0.identifier }.filter { !validIdentifiers.contains($0) }
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: invalidIdentifiers)

            // Schedule notifications for the times available in the database
            for (time, medicationNames) in self.medicationNamesByTimeSlot {
                guard let fireDate = dateFormatter.date(from: time) else {
                    print("Invalid time format for \(time)")
                    continue
                }

                let content = UNMutableNotificationContent()
                content.title = "Take Your Medications"
                content.body = medicationNames.joined(separator: ", ")
                content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "speech.mp3"))

                let calendar = Calendar.current
                let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
                let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)

                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

                UNUserNotificationCenter.current().add(request) { (error) in
                    if let error = error {
                        print("Error scheduling notification: \(error.localizedDescription)")
                    } else {
                        print("Notification scheduled successfully for \(time)")
                    }
                }
            }
        }
    }


    // MARK: - UITableViewDataSource

    func numberOfSections(in tableView: UITableView) -> Int {
        return medicationSections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return medicationSections[section].medicationNames.count
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return medicationSections[section].timeSlot
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell", for: indexPath) as! ReminderCell

        let medicationNames = medicationSections[indexPath.section].medicationNames
        let medicationName = medicationNames[indexPath.row]
        cell.medicatioName.text = medicationName
        
//        cell.contentView.layer.cornerRadius = 2
//            cell.contentView.layer.masksToBounds = false
//            cell.contentView.layer.shadowColor = UIColor.black.cgColor
//            cell.contentView.layer.shadowOpacity = 0.1
//        cell.contentView.layer.shadowOffset = CGSize(width: 0, height: 0.1)
//        cell.contentView.layer.shadowRadius = 0.1
//            cell.contentView.layer.shadowPath = UIBezierPath(roundedRect: cell.contentView.bounds, cornerRadius: 2).cgPath


        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }

    // MARK: - UNUserNotificationCenterDelegate

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Display an alert when a notification is about to be presented
        let alertController = UIAlertController(title: notification.request.content.title, message: notification.request.content.body, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        
        // Present the alert
        self.present(alertController, animated: true, completion: nil)
        
        // Call the completion handler to indicate how the notification should be presented
        completionHandler([.alert, .sound])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        // Increment the notification click count if the user clicked on the notification
//        if response.actionIdentifier == UNNotificationDefaultActionIdentifier {
//            incrementNotificationClickCount()
//        }
        
        completionHandler()
    }

    // Increment the notification click count
//    private func incrementNotificationClickCount() {
//        let today = Date()
//        let calendar = Calendar.current
//        
//        if let lastResetDate = UserDefaults.standard.object(forKey: lastResetDateKey) as? Date,
//           calendar.isDateInToday(lastResetDate) {
//            // If the last reset date is today, increment the click count
//            var clickCount = UserDefaults.standard.integer(forKey: notificationClickCountKey)
//            clickCount += 1
//            print(clickCount, "dulu")
//            UserDefaults.standard.set(clickCount, forKey: notificationClickCountKey)
//        } else {
//            // If the last reset date is not today, reset the click count and update the last reset date
//            UserDefaults.standard.set(1, forKey: notificationClickCountKey)
//            UserDefaults.standard.set(today, forKey: lastResetDateKey)
//        }
//    }
}

struct SendNotification {
    let time: String
    let name: String
}

struct MedicationSection {
    let timeSlot: String
    let medicationNames: [String]
}
