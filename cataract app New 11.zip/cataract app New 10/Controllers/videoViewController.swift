import UIKit
import AVKit
import AVFoundation

class CustomAVPlayerViewController: AVPlayerViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add custom controls or modify existing controls here
        // For example, to add a close button, you can create a UIBarButtonItem
        let closeButton = UIBarButtonItem(barButtonSystemItem: .stop, target: self, action: #selector(closePlayer))
        navigationItem.rightBarButtonItem = closeButton
    }
    
    @objc func closePlayer() {
        dismiss(animated: true, completion: nil)
    }
}

class videoViewController: UIViewController {
    @IBOutlet weak var vie1: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        

        setupShadowbtn(for: vie1)

        
    }
    func setupShadowbtn(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    
    @IBAction func btn(_ sender: Any) {
        let player = AVPlayer(url: URL(fileURLWithPath: Bundle.main.path(forResource: "videoFileName", ofType: "mp4")!))
        let vc = CustomAVPlayerViewController() // Use CustomAVPlayerViewController instead of AVPlayerViewController
        vc.player = player
        present(vc, animated: true)
    }
}
