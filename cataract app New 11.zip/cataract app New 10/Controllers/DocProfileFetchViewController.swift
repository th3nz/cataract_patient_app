import UIKit

class DocProfileFetchViewController: UIViewController {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var qualification: UILabel!
    @IBOutlet weak var speciality: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var doc_photo: UIImageView!
    
    var doc_id = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchDataFromBackend()
    }
    
    func fetchDataFromBackend() {
        // Replace "YourAPIEndpoint" with your actual API endpoint
        let apiURL = ServiceAPI.doc_profile_fetch
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create the form data
        var formData = Data()
        
        // Add the doc_id parameter to the form data
        let docIDFormData = "doc_id=\(doc_id)"
        formData.append(docIDFormData.data(using: .utf8)!)
        
        // Set the form data as the request body
        request.httpBody = formData
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                // Parse JSON data into docloginmodel
                let decoder = JSONDecoder()
                let docModel = try decoder.decode(docloginmodel.self, from: data)
                
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.updateUI(with: docModel.data)
                }
            } catch {
                print("Error decoding JSON:", error)
            }
        }
        task.resume()
    }

    func updateUI(with data: DataClass) {
        // Update labels with fetched data
        name.text = data.username
        email.text = data.email
        gender.text = data.gender
        qualification.text = data.qualification
        speciality.text = data.speciality
        
        // Fetch image from URL
        if let imageURL = URL(string: ServiceAPI.doc_profile_fetch_image + data.image) {
            print(imageURL)
            URLSession.shared.dataTask(with: imageURL) { data, response, error in
                    guard let data = data, error == nil else { return }
                    DispatchQueue.main.async() {
                        self.doc_photo.image = UIImage(data: data)
                    }
                }.resume()
            }
        }
    
    @IBAction func edit(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DocProfileViewController") as! DocProfileViewController
        vc.doc_id = doc_id
        navigationController?.pushViewController(vc, animated: true)
    }
}
