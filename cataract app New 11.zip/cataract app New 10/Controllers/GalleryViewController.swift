import UIKit

class GalleryViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    var pics: [Pictures] = []
    var pat_id = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchPicturesFromServer()
    }
    
    func fetchPicturesFromServer() {
        let parameters: [String: String] = [
            "pat_id": "\(pat_id)",
            "url": ServiceAPI.galleryurl // Assuming this is the correct URL
        ]
        
        APIHandler().postAPIValues(type: Pictures.self, apiUrl: ServiceAPI.galleryfetch, method: "POST", formData: parameters) { [weak self] result in
            switch result {
            case .success(let data):
                self?.updateCollectionView(with: data.images)
            case .failure(let error):
                print("Error fetching pictures: \(error)")
            }
        }
    }

    private func updateCollectionView(with newImages: [String]) {
        // Assuming your Pictures struct has only an array of image URLs
        self.pics = newImages.map { Pictures(status: "success", images: [$0]) }
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
}

extension GalleryViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return pics.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! galleryCollectionViewCell

        let imageURLs = pics[indexPath.row].images

        // Load image asynchronously
        if let imageURL = URL(string: imageURLs.first ?? "") {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: imageURL),
                   let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        cell.image.image = image
                    }
                }
            }
        }

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imageURL = pics[indexPath.row].images.first ?? ""
        navigateToNextViewController(with: imageURL)
    }
    
    func navigateToNextViewController(with imageURL: String) {
        guard let nextViewController = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as? NextViewController else {
            return
        }
        nextViewController.imageURL = imageURL
        navigationController?.pushViewController(nextViewController, animated: true)
    }
}

class NextViewController: UIViewController {
    var imageURL: String = ""
    
    @IBOutlet weak var imageview: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(imageURL)
        // Load image from the provided URL asynchronously
        if let url = URL(string: imageURL) {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url),
                   let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.imageview.image = image
                    }
                }
            }
        }
    }
}
