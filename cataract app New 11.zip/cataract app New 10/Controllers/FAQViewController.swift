//
//  FAQViewController.swift
//  cataract app
//
//  Created by SAIL on 26/10/23.
//

import UIKit

class FAQViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var segmented1: UISegmentedControl!
    @IBOutlet weak var table1: UITableView!
    
    let cars = ["If you have any symptoms, report to the Doctor .","Use the Protective shield for 15 days during sleep.","Lie on the side that wasn't operated on for 15 days.","Use only the prescribed drugs and follow the instructions.","Use protective dark glasses and avoid bright light.","Visit the doctor as advised."]
    var carsimage: [String] = [ "WhatsApp Image 2023-11-16 at 10.59.54 AM-2", "WhatsApp Image 2023-11-16 at 10.59.55 AM","napping_with_eye_shield_after_cataract_surgery-1372174781 1","AskDoctorAboutPrescription 2 (1)","Cataracts", "WhatsApp Image 2023-11-16 at 10.59.54 AM-3"]
    let fruits = [ "Do not wash your head."," Do not use any other drugs.", " Do not strain to pass motion. If constipated, consult doctor." , "Do not use snuff & pan." ]
    var fruitsimage: [String] = ["WhatsApp Image 2023-11-16 at 10.59.54 AM", "download (6) 1", "old-man-feel-stomach-abdominal-pain_38747-893_(1)-transformed 2" ,"stock-vector-stop-eating-tobacco-quotation-poster-sketch-drawing-stop-eating-gutka-and-chewing-tobacco-line-2200918341-transformed 1"]
    
    let cellSpacingHeight : CGFloat = 0
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //table1.rowHeight = 150
        
        
        table1.delegate = self
        table1.dataSource = self
        table1.reloadData()
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segmented1.selectedSegmentIndex{
        case 0 :
            return cars.count 
        case 1 :
            return fruits.count
            
        default:
            break
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }
    
    // Make the background color show through
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table1.dequeueReusableCell(withIdentifier: "cell" , for : indexPath) as! FAQTableViewCell
//        cell.label.text = cars[indexPath.row]
        switch segmented1.selectedSegmentIndex{
        case 0:
            cell.label.text = cars [indexPath .row]
            cell.imageview1.image=UIImage(named : carsimage [indexPath.row])
            cell.Myview.backgroundColor = UIColor(red: 30/255, green: 164/255, blue: 30/255, alpha: 0.2)
        case 1:
            cell.label.text = fruits [ indexPath.row]
            cell.imageview1.image=UIImage(named : fruitsimage [indexPath.row])
            cell.Myview.backgroundColor = UIColor(red: 241/255, green: 70/255, blue: 70/255, alpha: 0.2)
        
        default:
            break
        }
        return cell
    }
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        return cellspace
//    }
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let headerView = UIView ()
//        headerView.backgroundColor = UIColor.black
//        return headerView
//}
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 150.0
//    }
    
    
    @IBAction func segmentedchange(_ sender: Any) {
        switch segmented1.selectedSegmentIndex{
        case 0:
            print("FirstSegment")
            self.table1.reloadData()
        case 1:
            print("SecondSegment")
            self.table1.reloadData()
        default:
            break
        }
    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
