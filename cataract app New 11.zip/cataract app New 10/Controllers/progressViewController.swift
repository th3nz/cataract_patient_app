import UIKit

class progressViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var pat_id = 11
    var progressData: [ProgressviewElement] = [] // Store fetched progress data

    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchProgressData() // Fetch progress data when the view loads
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 30, right: 0)
    }
    
    // MARK: - Table View Data Source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return progressData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProgressCell", for: indexPath) as! ProgressCell
        let progress = progressData[indexPath.row]
        // Configure the cell with progress data
        cell.configure(with: progress)
        return cell
    }
    
    // MARK: - Fetch Progress Data
    
    func fetchProgressData() {
        let formData: [String: String] = ["pat_id": "\(pat_id)"]
        APIHandler().postAPIValues(type: Progressview.self, apiUrl: ServiceAPI.progressview, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let progressData):
                self.progressData = progressData
                DispatchQueue.main.async {
                    self.tableView.reloadData() // Reload table view with fetched data
                }
            case .failure(let error):
                print("Failed to fetch progress data:", error.localizedDescription)
            }
        }
    }
}

class ProgressCell: UITableViewCell {
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var predforte: UILabel!
    
    @IBOutlet weak var para: UILabel!
    @IBOutlet weak var cipro: UILabel!
    @IBOutlet weak var dia: UILabel!
    @IBOutlet weak var pan: UILabel!
    @IBOutlet weak var nev: UILabel!
    @IBOutlet weak var ointment: UILabel!
    @IBOutlet weak var hypersol: UILabel!
    @IBOutlet weak var viga: UILabel!
    func configure(with progress: ProgressviewElement) {
        date.text = progress.date
        // Customize progress display as needed

        predforte.text = "\(progress.predforteEyedrops)" + "%"
        viga.text = "\(progress.vigamoxEyedrops)" + "%"
        hypersol.text = "\(progress.hypersolEyedrops)" + "%"
        ointment.text = "\(progress.hypersolOintment)" + "%"
        nev.text = "\(progress.nevenacEyedrops)" + "%"
        pan.text = "\(progress.pan40Mg)" + "%"
        dia.text = "\(progress.diamox250Mg)" + "%"
        cipro.text = "\(progress.cipro500Mg)" + "%"
        para.text = "\(progress.para500Mg)" + "%"
    }
}
