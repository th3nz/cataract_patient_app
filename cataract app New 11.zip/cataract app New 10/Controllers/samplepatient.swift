////
////  PatientViewController.swift
////  cataract app
////
////  Created by SAIL L1 on 14/10/23.
////
//
//
//import UIKit
//import Charts
//
//class PatientViewController: UIViewController, ChartViewDelegate {
//    var doc_id = 0
//    var pat_id = 0
//    var score = 0
//    var ph = ""
//    var val = 10
//    
//    
//    
//    var pat_namev = ""
//    var pat_imagev = ""
//    var prog1: CGFloat = 0.0
//    var prog2: CGFloat = 0.0
//    var color : UIColor  = UIColor.cyan
//
//    // Declare prog2 as a Float
//    
//    
//    @IBOutlet weak var pat_image: UIImageView!
//    @IBOutlet weak var name: UILabel!
//    @IBOutlet weak var doc_photo: UIImageView!
//    
//    @IBOutlet weak var pat_name: UILabel!
//    @IBOutlet weak var chart1: UIView!
//    @IBOutlet weak var progressView2: UIView!
//    @IBOutlet weak var progressView: UIView!
//    var reminderViewController: ReminderViewController?
//    
//    var Predforte_eyedrops = 0
//    var Vigamox_eyedrops = 0
//    var Hypersol_eyedrops = 0
//    var Hypersol_ointment = 0
//    var Nevenac_eyedrops = 0
//    var Pan_40Mg = 0
//    var Diamox_250Mg = 0
//    var Cipro_500Mg = 0
//    var Para_500Mg = 0
//    
//    
//    
//    
//    
//    
// 
//   
//    @IBOutlet weak var predforteprog: UIProgressView!
//    
//    @IBOutlet weak var vigamoxprog: UIProgressView!
//    
//    @IBOutlet weak var hypersol_drop: UIProgressView!
//    
//    
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
////        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
////        progressView.addGestureRecognizer(tapGesture)
////        progressView.isUserInteractionEnabled = true
////        print(doc_id)
////        print(pat_id)
////        DataManager.shared.patientId = pat_id
////        // Create an instance of PercentageProgressBarView
////        let progressBarView = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
////        let progressBarView2 = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
////
////        // Customize progressBarView if needed
////        progressBarView.progressBarColor = UIColor.cyan
////        progressBarView2.progressBarColor = UIColor.cyan
////
////        // Set the percentage and custom text
////        progressBarView.setPercentage(CGFloat(self.prog1), customText: "Symptoms")
////        progressBarView2.setPercentage(self.prog2, customText: "Medication")
////        print(prog2, prog1, "koii" )
////
////        // Add progressBarView as a subview to yourContainerView
////        progressView.addSubview(progressBarView)
////        progressView2.addSubview(progressBarView2)
////
////        // Set constraints to position progressBarView within yourContainerView if needed
////        progressBarView.translatesAutoresizingMaskIntoConstraints = false
////        NSLayoutConstraint.activate([
////            progressBarView.centerXAnchor.constraint(equalTo: progressView.centerXAnchor),
////            progressBarView.centerYAnchor.constraint(equalTo: progressView.centerYAnchor),
////            progressBarView.widthAnchor.constraint(equalToConstant: 100),
////            progressBarView.heightAnchor.constraint(equalToConstant: 100)
////        ])
////
////        progressBarView2.translatesAutoresizingMaskIntoConstraints = false
////        NSLayoutConstraint.activate([
////            progressBarView2.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
////            progressBarView2.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
////            progressBarView2.widthAnchor.constraint(equalToConstant: 100),
////            progressBarView2.heightAnchor.constraint(equalToConstant: 100)
////        ])
//
//        
//    }
//    let obj = ReminderViewController()
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Change "Main" to your storyboard name
//              reminderViewController = storyboard.instantiateViewController(withIdentifier: "ReminderViewController") as? ReminderViewController
//        fetchDataFromBackend()
//        fetchval()
//        date()
//        updateUI2()
////        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "ReminderViewController") as! ReminderViewController
////        destinationVC.pat_id = pat_id
////        obj.fetchReminders()
//        self.navigationController?.setNavigationBarHidden(true, animated: false)
//        fetchdrugsFromBackend()
//        
//    }
//    func setupProgressViewWithPieChart() {
//        // Ensure the container is clear
//        progressView.subviews.forEach { $0.removeFromSuperview() }
//
//        // Initialize the pie chart view
//        let pieChart = PieChartView()
//        progressView.addSubview(pieChart)
//        
//        // Optionally, disable the legend and entry labels
//        pieChart.legend.enabled = false
//        pieChart.drawEntryLabelsEnabled = false
//
//        // Setup Pie Chart with 12 equal segments
//        let entries = (1...12).map { _ in PieChartDataEntry(value: 1) }
//        let dataSet = PieChartDataSet(entries: entries)
//        dataSet.colors = ChartColorTemplates.vordiplom() // Customize colors as needed
//        dataSet.drawValuesEnabled = false // Hide values on slices
//        
//        let data = PieChartData(dataSet: dataSet)
//        pieChart.data = data
//        
//        // Custom Progress Bar (a simple UIView for demonstration)
//        let progressBar = UIView()
//        progressBar.backgroundColor = .clear // Make the background transparent
//        progressView.addSubview(progressBar)
//        
//        // Circular Progress Bar Layer
//       
//        
//        // Layout
//        pieChart.translatesAutoresizingMaskIntoConstraints = false
//        progressBar.translatesAutoresizingMaskIntoConstraints = false
//        
//        NSLayoutConstraint.activate([
//            pieChart.topAnchor.constraint(equalTo: progressView.topAnchor),
//            pieChart.bottomAnchor.constraint(equalTo: progressView.bottomAnchor),
//            pieChart.leadingAnchor.constraint(equalTo: progressView.leadingAnchor),
//            pieChart.trailingAnchor.constraint(equalTo: progressView.trailingAnchor),
//            
//            progressBar.topAnchor.constraint(equalTo: progressView.topAnchor),
//            progressBar.bottomAnchor.constraint(equalTo: progressView.bottomAnchor),
//            progressBar.leadingAnchor.constraint(equalTo: progressView.leadingAnchor),
//            progressBar.trailingAnchor.constraint(equalTo: progressView.trailingAnchor),
//        ])
//        
//        // After layout is done, configure the circle path
//        
//    }
//
////    func setupProgressAndPieChart() {
////        // Clean up any existing subviews
////        progressView2.subviews.forEach { $0.removeFromSuperview() }
////
////        // Set up tap gesture if needed
////        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
////        progressView2.addGestureRecognizer(tapGesture)
////        progressView2.isUserInteractionEnabled = true
////        DataManager.shared.patientId = pat_id
////        DataManager.shared.doc_id =  doc_id
////        // Initialize and configure the pie chart
////        let pieChart = PieChartView()
////        pieChart.delegate = self
////        pieChart.drawEntryLabelsEnabled = false
////        pieChart.legend.enabled = false
////        // Add pieChart to progressView
////        progressView2.addSubview(pieChart)
////
////        // Configure the pie chart data
////        var entries = [ChartDataEntry]()
////        let equalValue = 1.0 // Equal value for equal segments
////        for x in 0..<12 {
////            entries.append(ChartDataEntry(x: Double(x), y: equalValue))
////        }
////        let dataSet = PieChartDataSet(entries: entries)
////        dataSet.colors = ChartColorTemplates.colorful() // Or any other color configuration
////        dataSet.drawValuesEnabled = false // Hide values on pie chart
////        let data = PieChartData(dataSet: dataSet)
////        pieChart.data = data
////
////        // Layout pie chart to fit within the progress bar
////        pieChart.translatesAutoresizingMaskIntoConstraints = false
////        NSLayoutConstraint.activate([
////            pieChart.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
////            pieChart.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
////            // Adjust the size of the pie chart to be slightly smaller than the progress bar
////            pieChart.widthAnchor.constraint(equalTo: progressView2.widthAnchor, multiplier: 0.8),
////            pieChart.heightAnchor.constraint(equalTo: progressView2.heightAnchor, multiplier: 0.8),
////        ])
////
////        // Initialize, configure, and add the progress bar
////        let progressBarView2 = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
////        progressView2.addSubview(progressBarView2)
////
////        // Customize progressBarView
////        progressBarView2.progressBarColor = color
////
////        // Set the percentage and custom text
////        progressBarView2.setPercentage(self.prog1, customText: "Medication")
////
////        // Position progressBarView within progressView
////        progressBarView2.translatesAutoresizingMaskIntoConstraints = false
////        NSLayoutConstraint.activate([
////            progressBarView2.centerXAnchor.constraint(equalTo: progressView2.centerXAnchor),
////            progressBarView2.centerYAnchor.constraint(equalTo: progressView2.centerYAnchor),
////            progressBarView2.widthAnchor.constraint(equalToConstant: 100),
////            progressBarView2.heightAnchor.constraint(equalToConstant: 100)
////        ])
////    }
////
////
////
////
////
////
////    // Ensure to implement the delegate methods for PieChartView if you're using any
////
////    func progressbars(){
////        progressView.subviews.forEach { $0.removeFromSuperview() }
////            progressView2.subviews.forEach { $0.removeFromSuperview() }
////        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
////        progressView.addGestureRecognizer(tapGesture)
////        progressView.isUserInteractionEnabled = true
////        print(doc_id)
////        print(pat_id)
////        DataManager.shared.patientId = pat_id
////        DataManager.shared.doc_id =  doc_id
////        // Create an instance of PercentageProgressBarView
////        let progressBarView = PercentageProgressBarView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
////
////
////        // Customize progressBarView if needed
////        progressBarView.progressBarColor = color
////
////        // Set the percentage and custom text
////        progressBarView.setPercentage(self.prog1, customText: "Symptoms")
////
////
////
////        // Add progressBarView as a subview to yourContainerView
////        progressView.addSubview(progressBarView)
////
////
////        // Set constraints to position progressBarView within yourContainerView if needed
////        progressBarView.translatesAutoresizingMaskIntoConstraints = false
////        NSLayoutConstraint.activate([
////            progressBarView.centerXAnchor.constraint(equalTo: progressView.centerXAnchor),
////            progressBarView.centerYAnchor.constraint(equalTo: progressView.centerYAnchor),
////            progressBarView.widthAnchor.constraint(equalToConstant: 100),
////            progressBarView.heightAnchor.constraint(equalToConstant: 100)
////        ])
////
////
////    }
//    func fetchDataFromBackend() {
//        // Replace "YourAPIEndpoint" with your actual API endpoint
//        let apiURL = ServiceAPI.doc_profile_fetch
//        
//        guard let url = URL(string: apiURL) else {
//            print("Invalid URL")
//            return
//        }
//        
//        // Create the request
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        
//        // Create the form data
//        var formData = Data()
//        
//        // Add the doc_id parameter to the form data
//        let docIDFormData = "doc_id=\(doc_id)"
//        formData.append(docIDFormData.data(using: .utf8)!)
//        
//        // Set the form data as the request body
//        request.httpBody = formData
//        
//        // Create and start the URLSession task
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error:", error)
//                return
//            }
//            
//            guard let data = data else {
//                print("No data received")
//                return
//            }
//            
//            do {
//                // Parse JSON data into docloginmodel
//                let decoder = JSONDecoder()
//                let docModel = try decoder.decode(docloginmodel.self, from: data)
//                
//                // Update UI on the main thread
//                DispatchQueue.main.async {
//                    self.updateUI(with: docModel.data)
//                }
//            } catch {
//                print("Error decoding JSON:", error)
//            }
//        }
//        task.resume()
//    }
//    
//    func date() {
//        // Replace "YourAPIEndpoint" with your actual API endpoint
//        let apiURL = ServiceAPI.notificationdate
//        
//        guard let url = URL(string: apiURL) else {
//            print("Invalid URL")
//            return
//        }
//        
//        // Create the request
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        
//        // Create the form data
//        var formData = Data()
//        
//        // Add the doc_id parameter to the form data
//      
//      
//        // Set the form data as the request body
//        request.httpBody = formData
//        
//        // Create and start the URLSession task
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error:", error)
//                return
//            }
//            
//            guard let data = data else {
//                print("No data received")
//                return
//            }
//            
//            do {
//                // Parse JSON data into docloginmodel
//                let decoder = JSONDecoder()
//                
//            } catch {
//                print("Error decoding JSON:", error)
//            }
//        }
//        task.resume()
//    }
//    
//
//    func updateUI(with data: DataClass) {
//        // Update labels with fetched data
//        name.text = "Dr."+data.username
//        ph = data.qualification
//        
//        
//        // Fetch image from URL
////        if let imageURL = URL(string: ServiceAPI.doc_profile_fetch_image + data.image) {
////            print(imageURL)
////            URLSession.shared.dataTask(with: imageURL) { data, response, error in
////                    guard let data = data, error == nil else { return }
////                    DispatchQueue.main.async() {
////                        self.doc_photo.image = UIImage(data: data)
////                    }
////                }.resume()
////            }
//        }
//    
//    func updateUI2() {
//        // Update labels with fetched data
//        pat_name.text = "Hi, " + pat_namev
//        
//        
//        
//        // Fetch image from URL
//        if let imageURL = URL(string: pat_imagev) {
//            print(imageURL)
//            URLSession.shared.dataTask(with: imageURL) { data, response, error in
//                    guard let data = data, error == nil else { return }
//                    DispatchQueue.main.async() {
//                        self.pat_image.image = UIImage(data: data)
//                    }
//                }.resume()
//            }
//        }
//    @IBAction func prefortep(_ sender: Any) {
//        Predforte_eyedrops += 1
//        
//        
//        
//    }
//    @IBAction func predfortem(_ sender: Any) {
//        Predforte_eyedrops -= 1
//    }
//    @IBAction func vigamoxp(_ sender: Any) {
//        Vigamox_eyedrops += 1
//    }
//    @IBAction func vigamoxm(_ sender: Any) {
//        Vigamox_eyedrops -= 1
//    }
//    @IBAction func logout(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
//
//    }
//    @IBAction func appointment(_ sender: UIButton) {
//        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "appointmentviewViewController") as! appointmentviewViewController
//        destinationVC.doc_id = doc_id
//        destinationVC.pat_id = pat_id
//        self.navigationController?.pushViewController(destinationVC, animated: true)
//    }
//    
//    @objc func viewTapped() {
//        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "NewsymptomsVc") as! NewsymptomsVc
//        destinationVC.pat_id = pat_id
//        self.navigationController?.pushViewController(destinationVC, animated: true)
//    }
//    
//    @IBAction func video(_ sender: Any) {
//        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "videoViewController") as! videoViewController
//        self.navigationController?.pushViewController(destinationVC, animated: true)
//    }
//    
//    @IBAction func profile(_ sender: Any) {
//        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "PatProfileViewViewController") as! PatProfileViewViewController
//        destinationVC.pat_id = pat_id
//        self.navigationController?.pushViewController(destinationVC, animated: true)
//    }
//    
//    @IBAction func symptomsprog(_ sender: UIButton) {
//        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "NewsymptomsVc") as! NewsymptomsVc
//        destinationVC.pat_id = pat_id
//        self.navigationController?.pushViewController(destinationVC, animated: true)
//    }
//    
//    func fetchval() {
//        // Replace "YourAPIEndpoint" with your actual API endpoint
//        let apiURL = ServiceAPI.symptomsprog
//        
//        guard let url = URL(string: apiURL) else {
//            print("Invalid URL")
//            return
//        }
//        
//        // Create the request
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        
//        // Create the form data
//        var formData = Data()
//        
//        // Add the doc_id parameter to the form data
//        let docIDFormData = "pat_id=\(pat_id)"
//        formData.append(docIDFormData.data(using: .utf8)!)
//        
//        // Set the form data as the request body
//        request.httpBody = formData
//        
//        // Create and start the URLSession task
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error:", error)
//                return
//            }
//            
//            guard let data = data else {
//                print("No data received")
//                return
//            }
//            
//            do {
//                // Parse JSON data into docloginmodel
//                let decoder = JSONDecoder()
//                let docModel = try decoder.decode(Symptomsprog.self, from: data)
//                
//                // Update UI on the main thread
//                DispatchQueue.main.async {
//                    self.updateUI1(with: docModel.data)
//                }
//            } catch {
//                print("Error decoding JSON:", error)
//            }
//        }
//        task.resume()
//    }
//
//    func updateUI1(with data: DataClass4) {
//        print(data.val, "hi")
//        val = data.val
//        if (data.val != 10){
//            prog1 = (CGFloat(data.val) / 7.0) * 100.0
//        }
//        print(prog1)
//        
//        // Update the progress bar with the new value of prog2
//        if data.val == 10  {
//           
//            color = UIColor.cyan
//            prog1 =  5
//        }
//        else if data.val == 7  {
//           
//            color = UIColor.red
//            
//        }
//        else if data.val > 5 {
//           
//            color =  UIColor.red
//        }
//        else if data.val > 2{
//            color =  UIColor.orange
//            
//        }
//        else if data.val > 1 {
//            color = UIColor.yellow
//        }
//        else if data.val > 0 {
//            color = UIColor.green
//        
//        }
//
//        else {
//            prog1 = 100
//            color = UIColor.black
//        }
////        progressbars()
////        setupProgressAndPieChart()
////        setupProgressViewWithPieChart()
//    }
//    func updateUI2(with data: Clicks) {
//        prog2 = CGFloat(data.clicksToMaxTotalRatio)
//        prog2 = prog2*100
//        
//        // Update the progress bar with the new value of prog2
//        if prog2 > 100  {
//           
//            color = UIColor.green
//           
//        }
//        else if prog2 > 70  {
//           
//            color = UIColor.cyan
//            
//        }
//        else if prog2 > 50 {
//           
//            color =  UIColor.yellow
//        }
//        else if prog2 > 20{
//            color =  UIColor.orange
//            
//        }
//        else if prog2 > 10 {
//            color = UIColor.orange
//        }
//        else if prog2 > 0 {
//            color = UIColor.red
//        
//        }
//
//        else {
//            prog1 = 100
//            color = UIColor.black
//        }
////        progressbars()
////        setupProgressAndPieChart()
////        setupProgressViewWithPieChart()
//    }
//    func fetchdrugsFromBackend() {
//        let apiURL = ServiceAPI.drugshome
//        
//        guard let url = URL(string: apiURL) else {
//            print("Invalid URL")
//            return
//        }
//        
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        
//        var formData = Data()
//        let patIDFormData = "pat_id=\(pat_id)&Predforte-eyedrops=\(Predforte_eyedrops)"
//        formData.append(patIDFormData.data(using: .utf8)!)
//        
//        request.httpBody = formData
//        
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error:", error)
//                return
//            }
//            
//            guard let data = data else {
//                print("No data received")
//                return
//            }
//            
//            do {
//                let decoder = JSONDecoder()
//                let drugs = try decoder.decode([DrugshomeElement].self, from: data)
//                
//                // Update UI on the main thread
//                DispatchQueue.main.async {
//                    // Use the retrieved values to update UI components
//                    // For example, update the progress bar
//                    if let firstDrug = drugs.first {
//                        if let total = Int(firstDrug.predforteEyedrops) {
//                            self.predforteprog.setProgress(Float(total) / 100.0, animated: true) // Assuming max value is 100
//                        }
//                    }
//                }
//            } catch {
//                print("Error decoding JSON:", error)
//            }
//        }
//        task.resume()
//    }
//
//    func fetchdrugsTotalFromBackend() {
//        let apiURL = ServiceAPI.drugstotal
//        
//        guard let url = URL(string: apiURL) else {
//            print("Invalid URL")
//            return
//        }
//        
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        
//        var formData = Data()
//        let patIDFormData = "pat_id=\(pat_id)&Predforte-eyedrops=\(Predforte_eyedrops)"
//        formData.append(patIDFormData.data(using: .utf8)!)
//        
//        request.httpBody = formData
//        
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error:", error)
//                return
//            }
//            
//            guard let data = data else {
//                print("No data received")
//                return
//            }
//            
//            do {
//                let decoder = JSONDecoder()
//                let drugsTotal = try decoder.decode(Drugstotal.self, from: data)
//                
//                // Update UI on the main thread
//                DispatchQueue.main.async {
//                    // Use the retrieved values to update UI components
//                    // For example, update the progress bar
//                    if let total = Int(drugsTotal.predforteEyedropsTotal) {
//                        self.predforteprog.setProgress(Float(total) / 100.0, animated: true) // Assuming max value is 100
//                    }
//                }
//            } catch {
//                print("Error decoding JSON:", error)
//            }
//        }
//        task.resume()
//    }
//
//    @IBAction func whatsp(_ sender: UIButton) {
//        let phoneNumber = ph
//        
//        if let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(phoneNumber)") {
//            if UIApplication.shared.canOpenURL(whatsappURL) {
//                UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
//            } else {
//                let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
//                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//                alertController.addAction(okAction)
//                present(alertController, animated: true, completion: nil)
//            }
//        }
//    }
//}
