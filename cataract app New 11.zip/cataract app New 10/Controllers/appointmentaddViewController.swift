//
//  appointmentaddViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 22/12/23.
//
// Create a struct to hold data
struct AppointmentData: Codable {
    static var pat_id = 0
    static var doc_id = 0
    static var dateselected: Date?

    // Function to set values
    static func setValues(pat_id: Int, doc_id: Int, dateselected: Date?) {
        AppointmentData.pat_id = pat_id
        AppointmentData.doc_id = doc_id
        AppointmentData.dateselected = dateselected
    }
}

import UIKit

class appointmentaddViewController: UIViewController {
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var datepicker: UIDatePicker!
    @IBOutlet weak var morning: UIView!
    @IBOutlet weak var noon: UIView!
    @IBOutlet weak var evening: UIView!
    var pat_id = 0
    var doc_id = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setUp()
        setupDatePicker()
        setupShadowdate(for: datepicker)
        setupShadowview(for: view1)
        setupShadowview(for: view2)
        setupShadowview(for: view3)
    

 
        
    }
    func setupShadowview(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    func setupShadowdate(for view: UIDatePicker ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    
    func setUp() {
        evening.isHidden = true
    noon.isHidden = true
    morning.isHidden = true
    }
    func passValuesToStruct() {
        AppointmentData.setValues(pat_id: pat_id, doc_id: doc_id, dateselected: datepicker.date)
    }
    func setupDatePicker() {
        datepicker.minimumDate = Date()
        datepicker.datePickerMode = .date
        datepicker.timeZone = .current
    }
    @IBAction func morning( sender: UIButton) {
        passValuesToStruct()


            
 
        
    evening.isHidden = true
    noon.isHidden = true
    morning.isHidden = false
    
    }
    @IBAction func noon ( sender: UIButton) {

        passValuesToStruct()

    evening.isHidden = true
    noon.isHidden = false
    morning.isHidden = true
    
    }
    @IBAction func evening ( sender: UIButton) {
        passValuesToStruct()
    evening.isHidden = false
    noon.isHidden = true
    morning.isHidden = true
    
    }

 

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

