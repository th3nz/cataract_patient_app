//
//  appointmentdocViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 29/12/23.
//


import UIKit

class appointmentdocViewController: UIViewController {

    @IBOutlet weak var segmentoutlet: UISegmentedControl!
    @IBOutlet weak var pending: UIView!
    @IBOutlet weak var accepted: UIView!
    

    var doc_id = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        segmentoutlet.selectedSegmentIndex = 0
        self.view.bringSubviewToFront(pending)
        pending.isHidden = false
        accepted.isHidden = true
    
        print(doc_id)
        // Do any additional setup after loading the view.
    }
    

  
    @IBAction func segment(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex{
        case 0:
            self.view.bringSubviewToFront(pending)
            pending.isHidden = false
            accepted.isHidden = true
            loadPendingData()
        case 1:
            self.view.bringSubviewToFront(accepted)
            pending.isHidden = true
            accepted.isHidden = false
            loadAcceptedData()
            
        default:
            break
        }
    }
    // Method to fetch and reload data for the pending container
       func loadPendingData() {
           // Fetch data for pending container and reload the table view
           // Example:
           if let pendingVC = self.children.first(where: { $0 is pendingViewController }) as? pendingViewController {
               pendingVC.fetchDataFromBackend()
           }
       }

       // Method to fetch and reload data for the accepted container
       func loadAcceptedData() {
           // Fetch data for accepted container and reload the table view
           // Example:
           if let acceptedVC = self.children.first(where: { $0 is acceptedViewController }) as? acceptedViewController {
               acceptedVC.fetchDatesFromBackend()
               acceptedVC.fetchimprovements()
           }
       }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
