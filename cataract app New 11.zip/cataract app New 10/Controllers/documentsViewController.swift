import UIKit

class documentsViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    var pat_id = 0
    var doc_id = 0
    var selectedImages: [UIImage] = []
    var body = Data()
    let imagePicker = UIImagePickerController()
    
    @IBOutlet weak var scan: UIButton!


    @IBOutlet weak var caretakerImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.navigationController?.isNavigationBarHidden = true
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
    }
    @IBAction func scanButtonTapped(_ sender: UIButton) {
        DispatchQueue.main.async {
            self.showImagePicker()
        }
        
    }
    @IBAction func onsave(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabbarViewController") as! TabbarViewController
        nextVC.pat_id = self.pat_id
        self.navigationController?.pushViewController(nextVC, animated: true)
        

            
        ADDUser()
        
    }
    func showImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            DispatchQueue.main.async {
                self.openCamera()
            }
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    // MARK: - UIImagePickerControllerDelegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
              selectedImages.append(pickedImage)
              
              // Update the UIImageView with the selected image
              caretakerImageView.image = pickedImage
          }
          
          picker.dismiss(animated: true, completion: nil)
      }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func ADDUser() {
        guard
            !selectedImages.isEmpty else {
                print("All fields are mandatory.")
                return
            }
        let apiURL = ServiceAPI.gallery
        print("API URL:", apiURL)
        
        // Generate a boundary identifier
        let boundary = UUID().uuidString
        
        // Create the request
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        // Create the form data
        var body = Data()
        
        // Add text fields to the form data
        let formData: [String: String] = [
            "pat_id": "\(pat_id)"
            
        ]
        
        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        
        // Add images to the form data
        for (index, image) in selectedImages.enumerated() {
                  
                   let fieldName = "images"
                    let fileName = "image\(index).jpg"
                    let imageData = image.jpegData(compressionQuality: 0.8)!
                    body.append("--\(boundary)\r\n".data(using: .utf8)!)
                    body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
                  body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                    body.append(imageData)
                    body.append("\r\n".data(using: .utf8)!)
                }
        
             
             let fieldNames = ["images"]

             for (index, image) in selectedImages.enumerated() {
                 let fieldName = fieldNames[index]
                 
                 let imageData = image.jpegData(compressionQuality: 0.8)!
                 body.append(contentsOf: "--\(boundary)\r\n".utf8)
                 body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
                 body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
                 body.append(contentsOf: imageData)
                 body.append(contentsOf: "\r\n".utf8)
             

             }
        
        // Add closing boundary
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        // Set the request body
        request.httpBody = body
        
        // Create and start the URLSession task
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Handle the response
            if let data = data {
                // Parse the response data if needed
                print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                
                // You can perform further processing here
            }
        }
        task.resume()
    }
}
