

struct AppointmentDatadoc {
 
    static var doc_id = 0
    

    // Function to set values
    static func setValues(doc_id: Int) {
 
        AppointmentDatadoc.doc_id = doc_id
        
    }
}


import UIKit

class PatientList: UIViewController, UISearchBarDelegate , DropdownViewDelegate{

    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var addpatient: UIButton!
    @IBOutlet weak var search: UISearchBar!
    @IBOutlet weak var dropdownTextField: UITextField!
    @IBOutlet weak var severityview: UIView!
    private var dropdownView: DropdownView!
    var dropdownvalue: String = "Last 45 Days"
    var patients: [Patient] = []
    var doctor_id = 0

    var doc_name = ""
    var details: Patients!
    var urls = ServiceAPI.last_45_days

    override func viewDidLoad() {
        
        
        
        let layout = CustomHorizontalFlowLayout()
           collectionview.collectionViewLayout = layout

        
        let dropdownData = ["Last 45 Days", "Last 60 Days", "Last 6 Months", "Last 1 Year", "All"]

        // Create an instance of DropdownView
        dropdownView = DropdownView(data: dropdownData)
        dropdownView.dropdownDelegate = self

        // Set the input view of the text field to the dropdown view
        dropdownTextField.inputView = dropdownView
        dropdownTextField.text = dropdownvalue
        
        super.viewDidLoad()
        collectionview.dataSource = self
        search.delegate = self  // Set the search bar delegate
       
        passValuesToStruct()
        setupShadow(for: collectionview)

        
    }
    func setupShadow(for view: UICollectionView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.01
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchPatientsFromServer()
    }
    
    func didSelectItem(_ item: String) {
        // Handle the selected item
        dropdownTextField.text = item
        dropdownvalue = item
        dropdownTextField.resignFirstResponder()
        // Dismiss the dropdown
        if dropdownvalue == "Last 45 Days" {
            urls = ServiceAPI.last_45_days
            fetchPatientsFromServer()
        }
        else if dropdownvalue == "Last 60 Days" {
            urls = ServiceAPI.last_60_days
            fetchPatientsFromServer()
        } else if dropdownvalue == "Last 6 Months" {
            urls = ServiceAPI.last_6_month
            fetchPatientsFromServer()
        }
        else if dropdownvalue == "Last 1 Year" {
            urls = ServiceAPI.last_1_year
            fetchPatientsFromServer()
        }

        else{
            urls = ServiceAPI.patientsURL
            fetchPatientsFromServer()
        }
    }
    func passValuesToStruct() {
        AppointmentDatadoc.setValues(doc_id: doctor_id)
    }

    @IBAction func addpatientaction(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "AddPatientViewController") as! AddPatientViewController
        vc.doctor_id = doctor_id
        self.navigationController?.pushViewController(vc, animated: true)
    }
    let imagePrefix = ServiceAPI.galleryurl
    func fetchPatientsFromServer() {
        guard let url = URL(string: urls) else {
            print(urls)
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "doctor_id=\(doctor_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { [self] data, _, error in
            if let error = error {
                print("Error fetching patients: \(error.localizedDescription)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    var fetchedPatients = try jsonDecoder.decode([Patient].self, from: data)

                    // Add prefix to each image URL
                    fetchedPatients.indices.forEach { index in
                        if let imageURL = URL(string: "\(self.imagePrefix)\(fetchedPatients[index].image)") {
                            fetchedPatients[index].imageURL = imageURL // Set imageURL for each patient
                        }
                    }

                    DispatchQueue.main.async {
                        self.patients = fetchedPatients
                        self.collectionview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error.localizedDescription)")
                }
            }
        }.resume()
    }


    @IBAction func profile(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DocProfileFetchViewController") as! DocProfileFetchViewController
        vc.doc_id = doctor_id
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func appointment(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "appointmentdocViewController") as! appointmentdocViewController
        vc.doc_id = doctor_id
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension PatientList: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return patients.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionPatient

        cell.PatientName.text = patients[indexPath.row].name

        // Fetch the severity for the current patient
        let severity = patients[indexPath.row].severity

        // Update the background color of severityview based on severity
        switch severity {
        case ..<1:
            cell.severityview.backgroundColor = UIColor.green
//        case ..<2:
//            cell.severityview.backgroundColor = UIColor.yellow
//        case ..<6:
//            cell.severityview.backgroundColor = UIColor.orange
        default:
            cell.severityview.backgroundColor = UIColor.red
        }
        cell.PatientImage.layer.cornerRadius = 60
        
       
        
        cell.layer.shadowColor = UIColor(named: "shadowColor")?.cgColor
        cell.layer.shadowOpacity = 0.5
        cell.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.layer.shadowRadius = 4
        cell.layer.masksToBounds = false
        if let imageURL = patients[indexPath.row].imageURL {
            print(imageURL)
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: imageURL),
                   let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        cell.PatientImage.image = image
                    }
                }
            }
        }

        let padding: CGFloat = 10

        cell.contentView.frame = cell.contentView.frame.inset(by: UIEdgeInsets(top: padding, left: padding, bottom: padding, right: padding))

        return cell
    }


    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "patient1") as! patient1
        vc.name = patients[indexPath.row].name
        vc.images = patients[indexPath.row].image
        print(patients[indexPath.row].image)
        vc.pat_id = patients[indexPath.row].patID

        self.navigationController?.pushViewController(vc, animated: true)
    }

    // Add UISearchBarDelegate methods for search functionality
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let filteredPatients = patients.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        updateCollectionView(with: filteredPatients)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        updateCollectionView(with: patients)  // Reload with the original data
        searchBar.setShowsCancelButton(false, animated: true)  // Hide the cancel button
    }

    private func updateCollectionView(with newPatients: [Patient]) {
        patients = newPatients
        collectionview.reloadData()
    }
}


class CustomHorizontalFlowLayout: UICollectionViewFlowLayout {
    override func prepare() {
        super.prepare()
        guard let collectionView = collectionView else { return }

        minimumLineSpacing = 10.0
        minimumInteritemSpacing = 10.0
        
        let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
        let cellWidth = (availableWidth - minimumInteritemSpacing) / 2.0
        itemSize = CGSize(width: cellWidth, height: 230.0)
    }
}


