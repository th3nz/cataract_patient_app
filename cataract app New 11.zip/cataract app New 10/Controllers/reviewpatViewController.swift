
import UIKit

class reviewpatViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    var doc_id = 0
    var pat_id = 0
    var dates: [String] = []
    var fetchImprovements: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDatesFromBackend()
        fetchimprovements()
    }

    func fetchDatesFromBackend() {
        guard let url = URL(string: ServiceAPI.fetchdates) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.dates = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched dates count: \(self.dates.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

    
    func fetchimprovements() {
        guard let url = URL(string: ServiceAPI.fetchimprovement) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching improvement data from backend: \(error)")
                return
            }

            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    self.fetchImprovements = try jsonDecoder.decode([String].self, from: data)

                    print("Fetched improvements count: \(self.fetchImprovements.count)")

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
        }.resume()
    }

}

extension reviewpatViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return max(dates.count, fetchImprovements.count)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 50.0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! reviewpatTableViewCell

        // Configure the cell with the fetched date
        if indexPath.row < dates.count {
            let date = dates[indexPath.row]
            cell.dates.text = date
        } else {
            cell.dates.text = "Date not available"
        }

        // Configure the cell with the fetched improvement
        if indexPath.row < fetchImprovements.count {
            let improvement = fetchImprovements[indexPath.row]
            cell.improvement.text = improvement
        } else {
            cell.improvement.text = "Improvement data not available"
        }

        return cell
    }
}
