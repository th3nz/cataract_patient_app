import UIKit

struct Symptom {
    var name: String
    var image: String
    var isSelected: Bool
}

class NewsymptomsVc: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    let cellSpacingHeight: CGFloat = 10
    var pat_id = 11
    
    var symptoms: [Symptom] = [
        Symptom(name: "Headache", image: "360_F_282129985_4pPu8qWD4C5eSeQNdrPVQAT4df9ZPGeJ-removebg-preview", isSelected: false),
        Symptom(name: "Redness", image: "cartoon-child-with-pink-eye-removebg-preview", isSelected: false),
        Symptom(name: "Eye Discharge", image: "illustration-of-watery-and-itchy-red-dry-eye-2BK74JE-transformed-removebg-preview", isSelected: false),
        Symptom(name: "Floaters", image: "png-transparent-human-eye-floater-iritis-uveitis-eye-people-symptom-human-eye-removebg-preview", isSelected: false),
        Symptom(name: "Flashes", image: "eyefloaterFlash-17-HHB-3519-770x553-removebg-preview", isSelected: false),
        Symptom(name: "Nausea", image: "images", isSelected: false),
        Symptom(name: "Watering", image: "126263271-guy-in-tears-symptom-of-flu-or-cold-male-character-with-watery-eyes-sad-man-flat-vector-removebg-preview", isSelected: false)
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        print("hi", pat_id)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        
    }
    
    @IBAction func done(_ sender: UIButton) {
        makeNetworkRequest()

        
    }

    func makeNetworkRequest() {
        let parameters = convertSymptomsToParameters().mapValues { String($0) }
        print("Parameters:", parameters)
        
        // Construct the request URL
        let apiUrl = ServiceAPI.symptoms // Assuming the base URL is correct
        
        // Create the request body including pat_id
        var requestBody = parameters
        let pat_idString = String(pat_id)
        requestBody["pat_id"] = pat_idString // Add pat_id to the request body
        
        APIHandler().postAPIValues(type: Models.self, apiUrl: apiUrl, method: "POST", formData: requestBody) { result in
            switch result {
            case .success(let data):
                if data.error == false {
                    print("Response:", data.message)
                    // Handle success
                    
                    // Show alert for successful insertion on the main thread
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Success", message: "Data inserted successfully.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                            // Pop the view controller when OK button is clicked
                            self.navigationController?.popViewController(animated: true)
                        })
                        self.present(alert, animated: true, completion: nil)
                    }
                } else {
                    print("Error:", data.message)
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error", message: data.message , preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                            // Pop the view controller when OK button is clicked
                            self.navigationController?.popViewController(animated: true)
                        })
                        self.present(alert, animated: true, completion: nil)
                    }
                    // Handle failure
                }
            case .failure(let error):
                print("Network Error:", error)
                let errorString = String(describing: error) // Convert error to string
                
                // Show alert for network error on the main thread
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: errorString, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                        // Pop the view controller when OK button is clicked
                        self.navigationController?.popViewController(animated: true)
                    })
                    self.present(alert, animated: true, completion: nil)
                }
                // Handle network error
            }
        }
    }



    
    func convertSymptomsToParameters() -> [String: Int] {
        return Dictionary(uniqueKeysWithValues: symptoms.map { ($0.name.lowercased(), $0.isSelected ? 1 : 0) })
    }
}

extension NewsymptomsVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return symptoms.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SymptomsTableViewCell
        cell.backgroundColor = .clear

        let symptom = symptoms[indexPath.row]

        cell.profileImahe.image = UIImage(named: symptom.image)
        cell.label.text = symptom.name
        cell.checkboxBtn.isSelected = symptom.isSelected
        cell.selectionStyle = .none

        cell.checkboxBtn.tag = indexPath.row
        cell.checkboxAction = {
            self.symptoms[indexPath.row].isSelected.toggle()
            cell.checkboxBtn.isSelected = self.symptoms[indexPath.row].isSelected
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
}
