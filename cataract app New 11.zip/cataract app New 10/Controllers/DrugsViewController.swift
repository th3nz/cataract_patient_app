import UIKit

class DrugsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var segmentedviewcontrol: UISegmentedControl!
    @IBOutlet weak var tableview: UITableView!

    var drugsView: Drugsview?
    var pat_id = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        // Fetch data from the API and populate the drugsView property
        fetchDataFromAPI()
    }

    func fetchDataFromAPI() {
        guard let url = URL(string: ServiceAPI.drugsview) else {
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "pat_id=\(pat_id)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching patients: \(error.localizedDescription)")
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                print("Unexpected response status code")
                return
            }

            if let data = data {
                print(String(data: data, encoding: .utf8) ?? "")
                do {
                    let jsonDecoder = JSONDecoder()
                    self.drugsView = try jsonDecoder.decode(Drugsview.self, from: data)

                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                } catch let decodingError as DecodingError {
                    print("DecodingError: \(decodingError)")
                } catch {
                    print("Error decoding JSON: \(error.localizedDescription)")
                }
            }
        }.resume()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segmentedviewcontrol.selectedSegmentIndex {
        case 0:
            return drugsView?.topicals.count ?? 0
        case 1:
            return drugsView?.tablets.count ?? 0
        default:
            return 0
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! DrugsTableViewCell

        switch segmentedviewcontrol.selectedSegmentIndex {
        case 0:
            if let topical = drugsView?.topicals[indexPath.row] {
                configureCell(cell, with: topical)
            }
        case 1:
            if let tablet = drugsView?.tablets[indexPath.row] {
                configureCell(cell, with: tablet)
            }
        default:
            break
        }

        return cell
    }

    func configureCell(_ cell: DrugsTableViewCell, with model: Tablet) {
        let  daysstr = String(model.days)
        cell.label.text = model.medicationName
        cell.duration.text = daysstr
        cell.eye.text = model.eye
        cell.interval.text = model.intervals

        if model.type == "topicals" {
            cell.images.image = UIImage(named: "3020810-removebg-preview 1")
        } else {
            cell.images.image = UIImage(named: "drugs 1 (Traced)")
        }
    }

    @IBAction func add(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DrugsAddViewController") as! DrugsAddViewController
        // Pass pat_id to the next view controller
        vc.pat_id = pat_id
        self.navigationController?.pushViewController(vc, animated: true)
    }

    @IBAction func segmentedchange(_ sender: Any) {
        self.tableview.reloadData()
    }
}
