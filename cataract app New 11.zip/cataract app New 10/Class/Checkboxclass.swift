import UIKit

class Checkbox: UIButton {
    // This will handle the state of Checkbox
    var isChecked: Bool = false {
        didSet {
            if isChecked {
                self.setImage(UIImage(named: "img-check"), for: .normal)
            } else {
                self.setImage(UIImage(named: "img-uncheck"), for: .normal)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.tintColor = UIColor.blue //TODO:
        self.isChecked = false
        self.addTarget(self, action:#selector(buttonClicked(sender:)), for: UIControl.Event.touchUpInside)
    }

    @objc func buttonClicked(sender: UIButton) {
       if sender == self { isChecked = !isChecked }
    }
}
