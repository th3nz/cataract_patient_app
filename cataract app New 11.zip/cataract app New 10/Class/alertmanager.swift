import UIKit

class AlertManager {
    
    static let shared = AlertManager() // Singleton instance
    
    private init() {} // Private initializer to prevent external instantiation
    
    // Timer to manage alert presentation
    var showTimer: Timer?
    
    func scheduleAlert(notificationTimes: [NotificationTime]) {
        // Loop through the notification times
        for time in notificationTimes {
            // Schedule the timer to display the alert at each notification time
            scheduleAlert(for: time)
        }
    }
    
    private func scheduleAlert(for notificationTime: NotificationTime) {
        // Get the current calendar and current date
        let calendar = Calendar.current
        let currentDate = Date()
        
        // Create the date components for the notification time
        var dateComponents = DateComponents()
        dateComponents.hour = notificationTime.hour
        dateComponents.minute = notificationTime.minute
        dateComponents.second = 0
        
        // Get the next occurrence of the notification time
        if let nextShowDate = calendar.nextDate(after: currentDate, matching: dateComponents, matchingPolicy: .nextTime) {
            // Calculate the time interval until the next show time
            let timeInterval = nextShowDate.timeIntervalSince(currentDate)
            
            // Schedule the timer to display the alert at the next show time
            showTimer = Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: false) { [weak self] timer in
                guard let self = self else { return }
                // Show the alert
                self.showAlert()
            }
        }
    }
    
    func showAlert() {
        // Create and present the alert
        let alertController = UIAlertController(title: "Alert", message: "It's time!", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        
        // Get the topmost view controller to present the alert
        if let topViewController = UIApplication.shared.topViewController() {
            topViewController.present(alertController, animated: true, completion: nil)
        }
    }
}

extension UIApplication {
    func topViewController(base: UIViewController? = UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        return base
    }
}
