//
//  DataManager.swift
//  cataract app
//
//  Created by SAIL L1 on 31/01/24.
//

import UIKit



class DataManager {
    
    
    
    static let shared = DataManager()
    
    private init() {
        
    }
    
    var patientId = Int()
    var doc_id = Int()
 
   
    func sendMessage(title:String,message:String,navigation:UINavigationController) {
    
   
    let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
    alertController.addAction(cancelAction)
    navigation.present(alertController, animated: false, completion: nil)
}
    
}
