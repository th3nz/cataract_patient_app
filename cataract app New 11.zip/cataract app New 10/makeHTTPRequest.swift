import Foundation

func makeHTTPRequest() {
    // Replace "YOUR_PHP_SCRIPT_URL" with the actual URL of your PHP script
    guard let url = URL(string: ServiceAPI.isselect) else {
        print("Invalid URL")
        return
    }

    var request = URLRequest(url: url)
    request.httpMethod = "GET"  // Use GET or POST based on your server-side handling

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("Error: \(error.localizedDescription)")
            return
        }

        if let data = data {
            let responseString = String(data: data, encoding: .utf8)
            print("Response: \(responseString ?? "Empty response")")
        }
    }

    task.resume()
}
