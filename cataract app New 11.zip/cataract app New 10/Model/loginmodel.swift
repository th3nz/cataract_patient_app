//
//  loginmodel.swift
//  cataract app
//
//  Created by SAIL L1 on 18/11/23.
//


import Foundation

// MARK: - Welcome
struct loginmodel: Codable {
    let error: Bool
    let message: String
}
