//
//  drugscount.swift
//  cataract app
//
//   let drugscount = try? JSONDecoder().decode(Drugscount.self, from: jsonData)

import Foundation

// MARK: - Drugscount
struct Drugscount: Codable {
    let status, message: String
}
