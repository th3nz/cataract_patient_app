// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let drugshome = try? JSONDecoder().decode(Drugshome.self, from: jsonData)

import Foundation

// MARK: - DrugshomeElement
struct DrugshomeElement: Codable {
    let id, patID, predforteEyedrops, vigamoxEyedrops: Int
    let hypersolEyedrops, hypersolOintment, nevenacEyedrops, pan40Mg: Int
    let diamox250Mg, cipro500Mg, para500Mg: Int
    let date: String

    enum CodingKeys: String, CodingKey {
        case id
        case patID = "pat_id"
        case predforteEyedrops = "Predforte-eyedrops"
        case vigamoxEyedrops = "Vigamox-eyedrops"
        case hypersolEyedrops = "Hypersol-eyedrops"
        case hypersolOintment = "Hypersol-ointment"
        case nevenacEyedrops = "Nevenac-eyedrops"
        case pan40Mg = "Pan-40Mg"
        case diamox250Mg = "Diamox-250Mg"
        case cipro500Mg = "Cipro-500Mg"
        case para500Mg = "Para-500Mg"
        case date = "Date"
    }
}

typealias Drugshome = [DrugshomeElement]
