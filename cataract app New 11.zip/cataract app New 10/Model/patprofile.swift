// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let patprofile = try? JSONDecoder().decode(Patprofile.self, from: jsonData)

import Foundation

// MARK: - Patprofile
struct Patprofile: Codable {
    let status: Bool
    let message: String
    let data: DataClassthree
}

// MARK: - DataClass
struct DataClassthree: Codable {
    let patID, doctorID: Int
    let firstname, lastname, password, email: String
    let image, gender, surgerydate: String
    let age: Int
    let eye, sxDetails, sxDetails1, sxDetails2: String
    let sxDetails3, sxDetails4, sxDetails5: String
    let contact1, contact2, severity: Int

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case doctorID = "doctor_id"
        case firstname, lastname, password, email, image, gender, surgerydate, age, eye
        case sxDetails = "sx_details"
        case sxDetails1 = "sx_details1"
        case sxDetails2 = "sx_details2"
        case sxDetails3 = "sx_details3"
        case sxDetails4 = "sx_details4"
        case sxDetails5 = "sx_details5"
        case contact1, contact2, severity
    }
}
