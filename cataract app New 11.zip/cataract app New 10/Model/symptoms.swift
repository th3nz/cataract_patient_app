//
//  symptoms.swift
//  cataract app
//
//  Created by SAIL on 12/03/24.
//
import Foundation

// MARK: - Symptoms
struct Symptoms: Codable {
    let symptoms: String
}
