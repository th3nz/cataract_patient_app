// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let notification = try? JSONDecoder().decode(Notification.self, from: jsonData)

import Foundation

// MARK: - NotificationElement
struct NotificationElement: Codable {
    let reminderID, medicationName, startDate, endDate: String
    let intervalMinutes, status, patID, eye: String
    let type, days, intervals, eight: String
    let nine, ten, eleven, twelve: String
    let thirteen, fourteen, fifteen, sixteen: String
    let seventeen, eighteen, nineteen, twenty: String
    let total: String

    enum CodingKeys: String, CodingKey {
        case reminderID = "reminder_id"
        case medicationName = "medication_name"
        case startDate = "start_date"
        case endDate = "end_date"
        case intervalMinutes = "interval_minutes"
        case status
        case patID = "pat_id"
        case eye, type, days, intervals, eight, nine, ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty, total
    }
}

typealias Notification = [NotificationElement]
