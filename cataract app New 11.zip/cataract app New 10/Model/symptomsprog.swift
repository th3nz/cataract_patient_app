
import Foundation

// MARK: - Symptomsprog
struct Symptomsprog: Codable {
    let data: DataClass4
}

// MARK: - DataClass
struct DataClass4: Codable {
    let val: Int
}
