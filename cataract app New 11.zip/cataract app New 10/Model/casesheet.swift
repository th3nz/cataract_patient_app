// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let casesheet = try? JSONDecoder().decode(Casesheet.self, from: jsonData)

import Foundation

// MARK: - Casesheet
struct Casesheet: Codable {
    let status: Bool
    let message: String
    let data: Casesheet1
}

// MARK: - DataClass
struct Casesheet1: Codable {
    let patID, doctorID: Int
    let firstname, lastname, password, email: String
    let gender, surgerydate: String
    let age: Int
    let eye, sxDetails, sxDetails1, sxDetails2: String
    let sxDetails3, sxDetails4, sxDetails5: String
    let contact1, contact2: Int

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case doctorID = "doctor_id"
        case firstname, lastname, password, email, gender, surgerydate, age, eye
        case sxDetails = "sx_details"
        case sxDetails1 = "sx_details1"
        case sxDetails2 = "sx_details2"
        case sxDetails3 = "sx_details3"
        case sxDetails4 = "sx_details4"
        case sxDetails5 = "sx_details5"
        case contact1, contact2
    }
}
