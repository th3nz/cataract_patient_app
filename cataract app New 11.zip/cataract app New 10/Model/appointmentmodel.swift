import Foundation

// MARK: - AppointmentElement
struct AppointmentElement: Codable {
    let id: Int
    let name, dateselected, currentDate, times: String
}

typealias Appointment = [AppointmentElement]
