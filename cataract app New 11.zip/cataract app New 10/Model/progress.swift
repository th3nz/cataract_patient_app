import Foundation

// MARK: - Progress
struct Progress: Codable {
    let success: Bool
    let message: String
}
