//
//  fetchimprovement.swift
//  cataract app
//
//  Created by SAIL L1 on 20/12/23.
//

import Foundation
// MARK: - Detail


typealias fetchimprovements = [String]
