//
//  patientlist.swift
//  cataract app
//
//  Created by SAIL L1 on 02/12/23.
//

import Foundation

// MARK: - Patient
struct Patient: Codable {
    
    let patID: Int
    let image, name: String
    let severity: Int
    var imageURL: URL?

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case image, name ,severity
    }
}
typealias Patients = [Patient]
