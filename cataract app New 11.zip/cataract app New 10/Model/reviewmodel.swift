//
//  reviewmodel.swift
//  cataract app
//
//  Created by SAIL L1 on 18/12/23.
//

import Foundation
typealias Reviewdates = [String]

