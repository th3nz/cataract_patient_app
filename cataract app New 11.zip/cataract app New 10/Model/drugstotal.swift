// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let drugstotal = try? JSONDecoder().decode(Drugstotal.self, from: jsonData)

import Foundation

// MARK: - Drugstotal
struct Drugstotal: Codable {
    let status: String
    let predforteEyedropsTotal, vigamoxEyedropsTotal, hypersolEyedropsTotal, hypersolOintmentTotal: Int
    let nevenacEyedropsTotal, pan40MgTotal, diamox250MgTotal, cipro500MgTotal: Int
    let para500MgTotal: Int

    enum CodingKeys: String, CodingKey {
        case status
        case predforteEyedropsTotal = "Predforte_eyedrops_total"
        case vigamoxEyedropsTotal = "Vigamox_eyedrops_total"
        case hypersolEyedropsTotal = "Hypersol_eyedrops_total"
        case hypersolOintmentTotal = "Hypersol_ointment_total"
        case nevenacEyedropsTotal = "Nevenac_eyedrops_total"
        case pan40MgTotal = "Pan_40Mg_total"
        case diamox250MgTotal = "Diamox_250Mg_total"
        case cipro500MgTotal = "Cipro_500Mg_total"
        case para500MgTotal = "Para_500Mg_total"
    }
}
