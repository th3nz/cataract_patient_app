import Foundation

// MARK: - Docloginmodel
struct docloginmodel: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let docID: Int
    let username, email, password, gender: String
    let qualification, speciality, image: String

    enum CodingKeys: String, CodingKey {
        case docID = "doc_id"
        case username, email, password, gender, qualification, speciality, image
    }
}
