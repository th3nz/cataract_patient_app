//
//  pictures.swift
//  cataract app
//
//  Created by SAIL L1 on 06/02/24.
//


import Foundation

// MARK: - Pictures
struct Pictures: Codable {
    let status: String
    let images: [String]
}
