
import Foundation

// MARK: - Drugsview
struct Patientlogin: Codable {
    let status: Bool
    let message: String
    let data: DataClassone
}

// MARK: - DataClass
struct DataClassone: Codable {
    let patID, doctorID: Int
    let firstname, lastname, password, email: String
    let image, gender, surgerydate: String
    let age: Int

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case doctorID = "doctor_id"
        case firstname, lastname, password, email, image, gender, surgerydate, age
    }
}
