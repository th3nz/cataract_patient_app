//
//  addpatient.swift
//  cataract app
//
//  Created by SAIL L1 on 22/11/23.
//

import Foundation

// MARK: - Welcome
struct addpatient: Codable {
    let error: Bool
    let message: String
}
