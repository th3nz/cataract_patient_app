// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let drugsview = try? JSONDecoder().decode(Drugsview.self, from: jsonData)

import Foundation

// MARK: - Drugsview
struct Drugsview: Codable {
    let topicals, tablets: [Tablet]
}

// MARK: - Tablet
struct Tablet: Codable {
    let eye, intervals :String
    let days : Int
    let medicationName: String
    let type: String
}
