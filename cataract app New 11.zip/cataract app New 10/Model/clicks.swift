//
//  clicks.swift
//  cataract app
//
//  Created by SAIL on 30/03/24.
//

import Foundation

// MARK: - Clicks
struct Clicks: Codable {
    let totalClicks, maxTotal: String
    let clicksToMaxTotalRatio: Int

    enum CodingKeys: String, CodingKey {
        case totalClicks = "total_clicks"
        case maxTotal = "max_total"
        case clicksToMaxTotalRatio = "clicks_to_max_total_ratio"
    }
}
