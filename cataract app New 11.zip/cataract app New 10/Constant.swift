
import Foundation
import UIKit


struct ServiceAPI {
        static let baseUrl="http://192.168.85.210/"

    
    static let signupUrl = baseUrl+"/cataract/v1/registerpatient.php?"
    
    
    
    static let drugshome = baseUrl+"/cataract/v1/drugshome.php?"
    
    static let progress = baseUrl+"/cataract/v1/progress.php?"
    
    static let progressview = baseUrl+"/cataract/v1/progressview.php?"
    
    static let drugstotal = baseUrl+"/cataract/v1/drugstotal.php?"
    
    static let drugscount = baseUrl+"/cataract/v1/drugscount.php?"
    
    static let last_45_days = baseUrl+"/cataract/v1/last_45_days.php?"
    static let last_60_days = baseUrl+"/cataract/v1/last_60_days.php?"
    static let last_6_month = baseUrl+"/cataract/v1/last_6_month.php?"
    static let last_1_year = baseUrl+"/cataract/v1/last_1_year.php?"
    
    static let notificationdate = baseUrl+"/cataract/v1/notificationdate.php?"
    
    static let symptomsfetch = baseUrl+"/cataract/v1/symptomsfetch.php?"
    
    static let notification = baseUrl+"/cataract/v1/notification.php?"
    
    
    static let casesheet = baseUrl+"cataract/v1/casesheet.php?"
    
    static let symptomsprog = baseUrl+"cataract/v1/symptomsprog.php?"

    
    static let isselect = baseUrl+"/cataract/v1/isselect.php?"
    
    static let doc_profile = baseUrl+"/cataract/v1/doc_profile.php?"
    static let pat_profile = baseUrl+"/cataract/v1/pat_profile.php?"
    
    static let doc_profile_fetch = baseUrl+"/cataract/v1/doc_profile_fetch.php?"
    static let doc_profile_fetch_image = baseUrl+"cataract/v1/"
    
    static let pat_profile_fetch = baseUrl+"/cataract/v1/patprofilefetch.php?"
    
    
    static let gallery = baseUrl+"/cataract/v1/gallery.php?"
    static let galleryfetch = baseUrl+"/cataract/v1/galleryfetch.php?"
    static let galleryurl = baseUrl+"cataract/v1/"
    
    
    
    static let loginURL = baseUrl+"cataract/v1/login.php?"
    static let patientlogin = baseUrl+"cataract/v1/patientlogin.php?"
    static let patientsURL = baseUrl+"cataract/v1/patientslist.php?"
    static let reminder = baseUrl+"cataract/v1/reminder.php?"
    static let drugsview = baseUrl+"cataract/v1/drugsview.php?"
    static let patientprofile = baseUrl+"cataract/v1/patientprofile.php?"
    static let addreview = baseUrl+"cataract/v1/addreview.php?"
    static let fetchdates = baseUrl+"cataract/v1/fetchdates.php?"
    static let addimprovement = baseUrl+"cataract/v1/addimprovement.php?"
    
    static let fetchimprovement = baseUrl+"cataract/v1/fetchimprovement.php?"
    static let fetchdateselected = baseUrl+"cataract/v1/fetchdateselected.php?"
    static let fetchstatus = baseUrl+"cataract/v1/fetchstatus.php?"
    static let appointmentdocfetch = baseUrl+"cataract/v1/appointmentdocfetch.php?"
    static let appointment = baseUrl+"cataract/v1/appointment.php?"
    static let updatestatus = baseUrl+"cataract/v1/updatestatus.php?"
    
    static let appointmentaccepteddates = baseUrl+"cataract/v1/appointmentaccepteddates.php?"
    
    
    static let appointmentacceptednames = baseUrl+"cataract/v1/appointmentacceptednames.php?"
    
    static let appointmentacceptedstatus = baseUrl+"cataract/v1/appointmentacceptedstatus.php?"
    static let symptoms = baseUrl+"cataract/v1/symptoms.php?"



}

extension UIViewController {
    
   
    class LoadingIndicator {

        static let shared = LoadingIndicator()

        private let activityIndicator: UIActivityIndicatorView = {
            let indicator = UIActivityIndicatorView(style: .large)
            indicator.color = .red
            indicator.hidesWhenStopped = true
            return indicator
        }()

        private init() {}

        func showLoading(on view: UIView) {
            DispatchQueue.main.async {
                self.activityIndicator.center = view.center
                view.addSubview(self.activityIndicator)
                self.activityIndicator.startAnimating()
            }
        }

        func hideLoading() {
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.activityIndicator.removeFromSuperview()
            }
        }
    }
  



}
