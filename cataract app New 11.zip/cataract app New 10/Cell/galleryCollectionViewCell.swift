//
//  galleryCollectionViewCell.swift
//  cataract app
//
//  Created by SAIL L1 on 06/02/24.
//

import UIKit

class galleryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
