import UIKit

class CollectionPatient: UICollectionViewCell {
    
    @IBOutlet weak var severityview: UIView!
    @IBOutlet weak var PatientName: UILabel!
    @IBOutlet weak var PatientImage: UIImageView!
    
    @IBOutlet weak var mainView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Make severityview round
        severityview.layer.cornerRadius = severityview.bounds.width / 2
        severityview.clipsToBounds = true
        setupShadow(for: mainView)

        
    }
    func setupShadow(for view: UIView ) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
}
