//
//  FAQTableViewCell.swift
//  cataract app
//
//  Created by SAIL on 26/10/23.
//

import UIKit

class FAQTableViewCell: UITableViewCell {

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


    @IBOutlet weak var Myview: UIView!
    @IBOutlet weak var imageview1: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
