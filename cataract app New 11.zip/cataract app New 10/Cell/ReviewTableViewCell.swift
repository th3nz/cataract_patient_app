//
//  ReviewTableViewCell.swift
//  cataract app
//
//  Created by SAIL L1 on 18/12/23.
//

import UIKit

class ReviewTableViewCell: UITableViewCell, DropdownViewDelegate {

    @IBOutlet weak var improvement: UITextField!

    private var dropdownView: DropdownView!
    var dropdownvalue: String = ""

    @IBOutlet weak var selectedimprovement: UILabel!
    @IBOutlet weak var dates: UILabel!

    func setImprovementText(_ text: String) {
        improvement.text = text
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        let dropdownData = [" ", "Abscent", "No Improvement", "6/6", "6/9", "6/18", "6/24", "6/36"]
        dropdownView = DropdownView(data: dropdownData)
        dropdownView.dropdownDelegate = self
        improvement.inputView = dropdownView
    }

    func didSelectItem(_ item: String) {
        improvement.text = item
        dropdownvalue = item
        improvement.resignFirstResponder()
        selectedimprovement.isHidden = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    @IBOutlet weak var improvementclick: UITextField!
}
