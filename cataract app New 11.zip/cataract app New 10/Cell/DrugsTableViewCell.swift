import UIKit

class DrugsTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var duration: UILabel!
    @IBOutlet weak var interval: UILabel!
    @IBOutlet weak var eye: UILabel!
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var selectionButton: UIButton! // Assume you have a UIButton in your cell for selection

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
//        if selected {
//            // Set the image for the selected state
//            selectionButton.setImage(UIImage(named: //"check_16"), for: .normal)
        }
//            else {
//            // Set the image for the unselected state
//            selectionButton.setImage(UIImage(named: ""), for: .normal)
//      }
    }
//}
