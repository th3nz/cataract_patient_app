import UIKit
protocol PendingTableViewCellDelegate: AnyObject {
    func reloadTableView()
}
class pendingTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var bookfor: UILabel!
    @IBOutlet weak var bookon: UILabel!
    
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var checkboxBtn: UIButton!
    
    var isCheck = false
    weak var tableView: UITableView? // Reference to the table view
    weak var delegate: PendingTableViewCellDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.white
        self.tintColor = UIColor.white
        updateImage()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    var checkboxAction: (() -> Void)?
    
    @IBAction func checkboxbtntapped(_ sender: UIButton) {
        checkboxAction?()
        isCheck.toggle()
        updateImage()
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Success", message: "Data inserted successfully.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                // Pop the view controller when OK button is clicked
                self.delegate?.reloadTableView() // Reload the table view
            })
            // Present the alert
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    
    func updateImage() {
        let imageName = isCheck ? "check_16" : "check_16"
        let image = UIImage(named: imageName)
        checkboxBtn.setImage(image, for: .normal)
    }
}
