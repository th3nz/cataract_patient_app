//
//  appointmentviewTableViewCell.swift
//  cataract app
//
//  Created by SAIL L1 on 22/12/23.
//

import UIKit

class appointmentviewTableViewCell: UITableViewCell {

        @IBOutlet weak var dates: UILabel!
        @IBOutlet weak var status: UILabel!
        override func awakeFromNib() {
            super.awakeFromNib()
            // Initialization code
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)

            // Configure the view for the selected state
        }

    }
