//
//  acceptedTableViewCell.swift
//  cataract app
//
//  Created by SAIL L1 on 29/12/23.
//

import UIKit

class acceptedTableViewCell: UITableViewCell {

    @IBOutlet weak var dates: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var names: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
