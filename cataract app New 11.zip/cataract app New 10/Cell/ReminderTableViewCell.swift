import UIKit

class ReminderTableViewCell: UITableViewCell {

    @IBOutlet weak var medicationNameLabel: UILabel!
    
    func configure(with reminder: NotificationElement, for timeSlot: String) {
        medicationNameLabel.text = reminder.medicationName
    }
}
