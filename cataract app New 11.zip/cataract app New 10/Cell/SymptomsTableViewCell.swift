//
//  SymptomsTableViewCell.swift
//  cataract app
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class SymptomsTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var profileImahe: UIImageView!
    
    
    @IBOutlet weak var checkboxBtn: UIButton!
    
    
  //  var checkboxAction: (() -> Void)?
  //  var checkboxAction:(() ->())?
    
    
    
    var checkboxAction: (() -> Void)?
    
    var isCheck = false
    
    
//     var isSelected: Bool = false  
    
    
    override func awakeFromNib() {
            super.awakeFromNib()
            self.backgroundColor = UIColor.white
            self.tintColor = UIColor.white
            
          //  updateImage()
        }
        

    
    
    
    

   

    
  override func layoutSubviews() {
    super.layoutSubviews()
   
      let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
      contentView.frame = contentView.frame.inset(by: margin)
      contentView.layer.cornerRadius = 20
  }
        
       /* override func prepareForReuse() {
            super.prepareForReuse()

            self.profileImahe.image = nil
            // updateImage()
        }*/
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
  

    @IBAction func checkboxbtntapped(_ sender: UIButton) {
        
        
       

       
        checkboxAction?()
//        isCheck.toggle()
    }
//    func updateImage() {
//            let imageName = isCheck ? "" : "check_16"
//            let image = UIImage(named: imageName)
//            checkboxBtn.setImage(image, for: .normal)
//        }
}
