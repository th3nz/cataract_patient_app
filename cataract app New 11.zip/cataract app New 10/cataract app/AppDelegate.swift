import UIKit

import UserNotifications

// Struct to store notification times

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var dailyTimer: Timer?
//    var notificationTimes: [NotificationTime] = [
//      
//        
//    ]
    let reminderViewController = ReminderViewController()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
//        notificationTimes = reminderViewController.notificationTimes
//        print(notificationTimes, " hellloo")
        // Override point for customization after application launch.

        // Set up local notifications
      //  requestNotificationAuthorization()

        // Schedule daily notifications
    

        // Schedule a daily timer
        scheduleDailyTimer()

        // Configure Firebase
    

        return true
    }

//    func scheduleDailyNotifications() {
//        for time in notificationTimes {
//            scheduleDailyNotification(hour: time.hour, minute: time.minute, soundName: "hi.aiff")
//        }
//    }

    func scheduleDailyTimer() {
        let timerFireTime = "13:35"

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        if let fireDate = dateFormatter.date(from: timerFireTime) {
            dailyTimer = Timer(fireAt: fireDate, interval: 24 * 60 * 60, target: self, selector: #selector(dailyTimerAction), userInfo: nil, repeats: true)

            if let timer = dailyTimer {
                RunLoop.current.add(timer, forMode: .default)
            }
        }
    }

    @objc func dailyTimerAction() {
        // Trigger the HTTP request when the timer fires
        makeHTTPRequest()
    }

    // MARK: Local Notifications

//    func requestNotificationAuthorization() {
//        let center = UNUserNotificationCenter.current()
//        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
//            // Handle the user's response to the notification request
//            if granted {
//                print("Notification authorization     granted")
//            } else {
//                print("Notification authorization denied")
//            }
//        }
//    }

//    func scheduleDailyNotification(hour: Int, minute: Int, soundName: String) {
//        let content = UNMutableNotificationContent()
//        content.title = "Reminder"
//        content.body = "It's time to open the app and record your symptoms."
//
//        // Set a custom sound file
//        content.sound = UNNotificationSound(named: UNNotificationSoundName(soundName))
//
//        var dateComponents = DateComponents()
//        dateComponents.hour = hour
//        dateComponents.minute = minute
//
//        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
//
//        let request = UNNotificationRequest(identifier: "dailyReminder", content: content, trigger: trigger)
//
//        let center = UNUserNotificationCenter.current()
//        center.add(request) { error in
//            if let error = error {
//                print("Error scheduling notification: \(error.localizedDescription)")
//            } else {
//                print("Notification scheduled successfully")
//            }
//        }
//    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }
}
