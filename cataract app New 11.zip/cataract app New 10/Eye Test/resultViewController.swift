import UIKit

class resultViewController: UIViewController {
    
    var score1 = 0
    var score = 0
    
    @IBOutlet weak var leftimg: UIImageView!
    @IBOutlet weak var rightimg: UIImageView!
    
    @IBOutlet weak var leftlbl: UILabel!
    @IBOutlet weak var rightlbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(score)
        print(score1)
        // Check the score and set the appropriate image in leftimg
        if score1 == 0  {
            leftimg.image = UIImage(named: "worried") // Replace "sadImage" with the name of your sad image asset
            leftlbl.text = "Very Bad"
            leftlbl.textColor = UIColor.red
        }else if score1 == 1 {
            leftimg.image = UIImage(named: "sad-face") // Replace "neutralImage" with the name of your neutral image asset
            leftlbl.text = "Bad"
            leftlbl.textColor = UIColor.orange
        }
        else if score1 == 2 {
            leftimg.image = UIImage(named: "neutral-face") // Replace "neutralImage" with the name of your neutral image asset
            leftlbl.text = "Good"
            leftlbl.textColor = UIColor.yellow
        } else if score1 == 3{
            leftimg.image = UIImage(named: "happy") // Replace "happyImage" with the name of your happy image asset
            leftlbl.text = "Excellent"
            leftlbl.textColor = UIColor.green
        }
        if score == 0  {
            rightimg.image = UIImage(named: "worried") // Replace "sadImage" with the name of your sad image asset
            rightlbl.text = "Very Bad"
            rightlbl.textColor = UIColor.red
        }else if score == 1 {
            rightimg.image = UIImage(named: "sad-face") // Replace "neutralImage" with the name of your neutral image asset
            rightlbl.text = "Bad"
            rightlbl.textColor = UIColor.orange
        }
        else if score == 2 {
            rightimg.image = UIImage(named: "neutral-face") // Replace "neutralImage" with the name of your neutral image asset
            rightlbl.text = "Good"
            rightlbl.textColor = UIColor.yellow
        } else if score == 3{
            rightimg.image = UIImage(named: "happy") // Replace "happyImage" with the name of your happy image asset
            rightlbl.text = "Excellent"
            rightlbl.textColor = UIColor.green
        }
        // You can customize the labels or other UI elements based on the score as well
//        leftlbl.text = "Left Label: \(score)"
//        rightlbl.text = "Right Label: \(score1)"
    }
   
    @IBAction func btn(_ sender: UIButton) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "TabbarViewController") as! TabbarViewController
        destinationVC.pat_id = DataManager.shared.patientId
        print(DataManager.shared.patientId)
        destinationVC.doc_id =  DataManager.shared.doc_id
//       destinationVC.letter = letter
//        destinationVC.score = score

       self.navigationController?.pushViewController(destinationVC, animated: true)
    }
}
