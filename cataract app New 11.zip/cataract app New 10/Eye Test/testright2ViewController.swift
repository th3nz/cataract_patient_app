import UIKit

class testright2ViewController: UIViewController {
    var letter: String = ""
    var score = 0
    
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        print("hi", letter)
        // Generate four random letters
        let randomLetters = generateRandomLetters()

        // Set the button titles with the random letters
        btn1.setTitle(randomLetters[0], for: .normal)
        btn2.setTitle(randomLetters[1], for: .normal)
        btn3.setTitle(randomLetters[2], for: .normal)
        btn4.setTitle(randomLetters[3], for: .normal)

        // Set one button title to be the same as the value from the 'letter' variable
        let randomIndex = Int(arc4random_uniform(UInt32(randomLetters.count)))
        let buttonWithSameLetter = [btn1, btn2, btn3, btn4][randomIndex]
        buttonWithSameLetter?.setTitle(letter, for: .normal)
    }

    // Function to generate four random letters
    func generateRandomLetters() -> [String] {
        var randomLetters: [String] = []
        for _ in 1...4 {
            randomLetters.append(String(generateRandomLetter()))
        }
        return randomLetters
    }

    // Function to generate a random letter
    func generateRandomLetter() -> Character {
        let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        let randomIndex = Int(arc4random_uniform(UInt32(letters.count)))
        let randomLetter = letters[letters.index(letters.startIndex, offsetBy: randomIndex)]
        return randomLetter
    }

    @IBAction func btn1Tapped(_ sender: UIButton) {
        handleButtonTapped(sender)
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "testright3ViewController") as! testright3ViewController
       destinationVC.score = score

       self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }

    @IBAction func btn2Tapped(_ sender: UIButton) {
        handleButtonTapped(sender)
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "testright3ViewController") as! testright3ViewController
       destinationVC.score = score

       self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }

    @IBAction func btn3Tapped(_ sender: UIButton) {
        handleButtonTapped(sender)
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "testright3ViewController") as! testright3ViewController
       destinationVC.score = score

       self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }

    @IBAction func btn4Tapped(_ sender: UIButton) {
        handleButtonTapped(sender)
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "testright3ViewController") as! testright3ViewController
       destinationVC.score = score

       self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }

    func handleButtonTapped(_ sender: UIButton) {
        // Check if the tapped button has the correct letter value
        if sender.title(for: .normal) == letter {
            // Increment the score
            score += 1
            print("Correct! Score: \(score)")
        } else {
            print("Incorrect! Score: \(score)")
        }

        // Generate new random letters and update the button titles
        let randomLetters = generateRandomLetters()
        btn1.setTitle(randomLetters[0], for: .normal)
        btn2.setTitle(randomLetters[1], for: .normal)
        btn3.setTitle(randomLetters[2], for: .normal)
        btn4.setTitle(randomLetters[3], for: .normal)

        // Set one button title to be the same as the value from the 'letter' variable
        let randomIndex = Int(arc4random_uniform(UInt32(randomLetters.count)))
        let buttonWithSameLetter = [btn1, btn2, btn3, btn4][randomIndex]
        buttonWithSameLetter?.setTitle(letter, for: .normal)
    }
}
