//
//  testleft4ViewController.swift
//  cataract app
//
//  Created by SAIL L1 on 09/01/24.
//

import UIKit

class testleft4ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var btn: UIButton!
    var letter: String = ""
    var score1 = 0
    var score = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Call the function to generate a random letter
        updateRandomLetter()
    }
    
    // Function to update the random letter
    func updateRandomLetter() {
        let randomLetter = generateRandomLetter()
        letter = String(randomLetter)
        label.text = "\(letter)"
    }

    // Function to generate a random letter
    func generateRandomLetter() -> Character {
        let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        let randomIndex = Int(arc4random_uniform(UInt32(letters.count)))
        let randomLetter = letters[letters.index(letters.startIndex, offsetBy: randomIndex)]
        return randomLetter
    }
    @IBAction func btn(_ sender: UIButton) {
        let destinationVC = storyboard?.instantiateViewController(withIdentifier: "testleft5ViewController") as! testleft5ViewController
       destinationVC.letter = letter
        destinationVC.score = score
        destinationVC.score1 = score1

       self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
